package com.tunex.app

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import androidx.core.graphics.ColorUtils
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.tunex.app.databinding.SheetTimeBinding

/**
 * Time chooser: a bottom sheet with scroll wheels (hour, minute, second, AM/PM), "Auto" and "Done".
 * Same sheet look as the other sheets of the app (link, clash, info).
 */
object TimeSheet {

    private val HOURS = (1..12).map { it.toString() }
    private val SIXTY = (0..59).map { String.format("%02d", it) }
    private val AMPM = listOf("AM", "PM")

    /**
     * @param autoLabel text of the left button; null hides it (Start time has no Auto).
     * @param onAuto runs when "Auto" is tapped (Stop time: no stop time, play by length).
     */
    fun show(
        ctx: Context,
        title: String,
        h: Int,
        m: Int,
        s: Int,
        autoLabel: String?,
        onAuto: (() -> Unit)?,
        onDone: (Int, Int, Int) -> Unit
    ) {
        val dp = ctx.resources.displayMetrics.density
        val dlg = BottomSheetDialog(ctx)
        val sb = SheetTimeBinding.inflate(LayoutInflater.from(ctx))
        dlg.setContentView(sb.root)
        (sb.root.parent as? View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)

        val ink = ThemeStore.attrColor(ctx, R.attr.txText, 0xFFF4F4FA.toInt())
        val acc = ThemeStore.attrColor(ctx, R.attr.txAccent, 0xFF7F5BFF.toInt())
        val acc2 = ThemeStore.attrColor(ctx, R.attr.txAccent2, 0xFFA78BFA.toInt())
        val itemH = (48 * dp).toInt()

        sb.timeTitle.text = title.uppercase()

        // chosen-row band
        val band = GradientDrawable()
        band.cornerRadius = 16 * dp
        band.setColor(ColorUtils.setAlphaComponent(ScheduleAdapter.base(ctx), 0x14))
        sb.wheelBand.background = band

        val wh = WheelView(ctx, HOURS, itemH, ink)
        val wm = WheelView(ctx, SIXTY, itemH, ink)
        val ws = WheelView(ctx, SIXTY, itemH, ink)
        val wa = WheelView(ctx, AMPM, itemH, ink)
        for (w in listOf(wh, wm, ws, wa)) {
            sb.wheelRow.addView(w, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        }
        wh.select(((h % 12).let { if (it == 0) 12 else it }) - 1)
        wm.select(m)
        ws.select(s)
        wa.select(if (h < 12) 0 else 1)

        // Done: purple gradient like the design
        val done = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(acc2, acc))
        done.cornerRadius = 20 * dp
        sb.timeDone.background = done
        sb.timeDone.setOnClickListener {
            val hh = (wh.index() + 1) % 12 + wa.index() * 12
            dlg.dismiss()
            onDone(hh, wm.index(), ws.index())
        }

        if (autoLabel == null) {
            sb.timeAuto.visibility = View.GONE
            (sb.timeDone.layoutParams as LinearLayout.LayoutParams).marginStart = 0
        } else {
            sb.timeAuto.text = autoLabel
            sb.timeAuto.setOnClickListener {
                dlg.dismiss()
                onAuto?.invoke()
            }
        }

        dlg.show()
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
    }
}
