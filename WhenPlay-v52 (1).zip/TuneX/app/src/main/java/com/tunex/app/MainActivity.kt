package com.tunex.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tunex.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private var ticks = 0
    private var userSeeking = false

    private val adapter = ScheduleAdapter(
        onToggle = { s, on -> onToggle(s, on) },
        onEdit = { s ->
            startActivity(Intent(this, EditActivity::class.java).putExtra("id", s.id))
        },
        onDelete = { s -> onDelete(s) }
    )

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            showBatteryPrompt()
        }

    private val tick = object : Runnable {
        override fun run() {
            refreshNow()
            ticks++
            if (ticks % 60 == 0) refreshList()
            handler.postDelayed(this, 500)
        }
    }

    private fun showThemes() {
        val dp = resources.displayMetrics.density
        val box = android.widget.LinearLayout(this)
        box.orientation = android.widget.LinearLayout.VERTICAL
        box.setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (4 * dp).toInt())
        val cur = ThemeStore.index(this)
        var dlg: androidx.appcompat.app.AlertDialog? = null
        val txt = ThemeStore.attrColor(this, R.attr.txText, 0xFFFFFFFF.toInt())
        val mut = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF999999.toInt())
        ThemeStore.all.forEachIndexed { i, t ->
            val row = android.widget.LinearLayout(this)
            row.orientation = android.widget.LinearLayout.HORIZONTAL
            row.gravity = android.view.Gravity.CENTER_VERTICAL
            row.setPadding((8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt())
            val sw = android.view.View(this)
            val gd = android.graphics.drawable.GradientDrawable()
            gd.shape = android.graphics.drawable.GradientDrawable.OVAL
            gd.orientation = android.graphics.drawable.GradientDrawable.Orientation.TL_BR
            gd.colors = intArrayOf(t.top, t.bg)
            gd.setStroke((3 * dp).toInt(), t.accent)
            sw.background = gd
            row.addView(sw, android.widget.LinearLayout.LayoutParams((30 * dp).toInt(), (30 * dp).toInt()))
            val name = android.widget.TextView(this)
            name.text = t.name
            name.textSize = 16f
            name.setTextColor(txt)
            name.setPadding((16 * dp).toInt(), 0, 0, 0)
            row.addView(name, android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val chk = android.widget.TextView(this)
            chk.text = if (i == cur) "\u2713" else ""
            chk.textSize = 18f
            chk.setTextColor(mut)
            row.addView(chk)
            row.setOnClickListener {
                dlg?.dismiss()
                if (i != cur) {
                    ThemeStore.set(this, i)
                    recreate()
                }
            }
            box.addView(row)
        }
        val scroll = android.widget.ScrollView(this)
        scroll.addView(box)
        dlg = com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Theme")
            .setView(scroll)
            .setNegativeButton("Close", null)
            .show()
    }

    /** Top-right three-dots menu: Theme and Layout. */
    private fun showMenu(anchor: View) {
        val pm = androidx.appcompat.widget.PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Theme")
        pm.menu.add(0, 2, 1, "Layout")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> showThemes()
                2 -> showLayouts()
            }
            true
        }
        pm.show()
    }

    private fun applyLayout() {
        val dp = resources.displayMetrics.density
        val bento = LayoutStore.isBento(this)
        if (bento) {
            val glm = GridLayoutManager(this, 2)
            glm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int = adapter.spanFor(position)
            }
            b.list.layoutManager = glm
            b.list.setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), (110 * dp).toInt())
        } else {
            b.list.layoutManager = LinearLayoutManager(this)
            b.list.setPadding(0, 0, 0, (110 * dp).toInt())
        }
        adapter.bento = bento
    }

    private fun showLayouts() {
        val dp = resources.displayMetrics.density
        val box = android.widget.LinearLayout(this)
        box.orientation = android.widget.LinearLayout.VERTICAL
        box.setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (4 * dp).toInt())
        val cur = LayoutStore.index(this)
        var dlg: androidx.appcompat.app.AlertDialog? = null
        val txt = ThemeStore.attrColor(this, R.attr.txText, 0xFFFFFFFF.toInt())
        val mut = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF999999.toInt())
        LayoutStore.names.forEachIndexed { i, n ->
            val row = android.widget.LinearLayout(this)
            row.orientation = android.widget.LinearLayout.HORIZONTAL
            row.gravity = android.view.Gravity.CENTER_VERTICAL
            row.setPadding((8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt())
            val col = android.widget.LinearLayout(this)
            col.orientation = android.widget.LinearLayout.VERTICAL
            val name = android.widget.TextView(this)
            name.text = n
            name.textSize = 16f
            name.setTextColor(txt)
            col.addView(name)
            val hint = android.widget.TextView(this)
            hint.text = LayoutStore.hints[i]
            hint.textSize = 12f
            hint.setTextColor(mut)
            col.addView(hint)
            row.addView(col, android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val chk = android.widget.TextView(this)
            chk.text = if (i == cur) "\u2713" else ""
            chk.textSize = 18f
            chk.setTextColor(mut)
            row.addView(chk)
            row.setOnClickListener {
                dlg?.dismiss()
                if (i != cur) {
                    LayoutStore.set(this, i)
                    applyLayout()
                    refreshList()
                    if (i == 1) Toast.makeText(this, "Long-press a tile to delete it", Toast.LENGTH_LONG).show()
                }
            }
            box.addView(row)
        }
        dlg = com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Layout")
            .setView(box)
            .setNegativeButton("Close", null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ThemeStore.styleBars(this)
        b.btnMenu.setOnClickListener { showMenu(it) }

        b.list.adapter = adapter
        applyLayout()

        b.fab.setOnClickListener {
            startActivity(Intent(this, EditActivity::class.java))
        }
        b.btnStop.setOnClickListener {
            startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_STOP))
        }
        b.btnPlay.setOnClickListener { PlayerService.instance?.togglePause() }
        b.btnPrev.setOnClickListener { PlayerService.instance?.prev() }
        b.btnNext.setOnClickListener { PlayerService.instance?.next() }
        b.btnBack.setOnClickListener { PlayerService.instance?.seekBy(-10000) }
        b.btnFwd.setOnClickListener { PlayerService.instance?.seekBy(10000) }
        b.nowSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) b.nowPos.text = fmtMs(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                PlayerService.instance?.seekTo(sb?.progress ?: 0)
                userSeeking = false
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            showBatteryPrompt()
        }

        // Make sure every enabled schedule is armed
        Scheduler.rescheduleAll(this)
    }

    private fun showBatteryPrompt() {
        val prefs = getSharedPreferences("tunex_ui", MODE_PRIVATE)
        if (prefs.getBoolean("asked", false)) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked", true).apply()
        MaterialAlertDialogBuilder(this)
            .setTitle("Make playback rock-solid")
            .setMessage("One time only: tap Allow on the next screen so Android never limits WhenPlay in the background.")
            .setPositiveButton("Continue") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            .setNegativeButton("Skip", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun refreshList() {
        val l = Store.all(this).sortedWith(compareBy({ it.hour }, { it.minute }))
        adapter.submit(l)
        b.empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun fmtMs(ms: Int): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }

    private fun refreshNow() {
        val svc = PlayerService.instance
        if (PlayerService.isPlaying && svc != null) {
            b.nowCard.visibility = View.VISIBLE
            b.nowLabel.text = PlayerService.nowTitle
            b.nowTrack.text = PlayerService.nowTrack.ifBlank { "Starting…" }
            val d = svc.duration()
            val p = svc.position()
            if (!userSeeking) {
                b.nowSeek.max = if (d > 0) d else 1
                b.nowSeek.progress = p
                b.nowPos.text = fmtMs(p)
            }
            b.nowDur.text = fmtMs(d)
            b.btnPlay.setImageResource(if (svc.isPaused()) R.drawable.ic_play_dark else R.drawable.ic_pause_dark)
        } else {
            b.nowCard.visibility = View.GONE
        }
    }

    private fun onToggle(s: Schedule, on: Boolean) {
        s.enabled = on
        if (on) {
            s.onceAt = 0L
            Scheduler.arm(this, s)
            Toast.makeText(
                this,
                "Starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Scheduler.cancel(this, s.id)
        }
        Store.upsert(this, s)
        handler.post { refreshList() }
    }

    private fun onDelete(s: Schedule) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete schedule?")
            .setMessage(s.title())
            .setPositiveButton("Delete") { _, _ ->
                Scheduler.cancel(this, s.id)
                Store.delete(this, s.id)
                refreshList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
