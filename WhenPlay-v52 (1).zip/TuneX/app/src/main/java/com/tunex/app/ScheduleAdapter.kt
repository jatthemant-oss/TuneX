package com.tunex.app

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.RecyclerView
import com.tunex.app.databinding.ItemScheduleBinding
import com.tunex.app.databinding.ItemScheduleHeroBinding
import com.tunex.app.databinding.ItemScheduleTileBinding

class ScheduleAdapter(
    private val onToggle: (Schedule, Boolean) -> Unit,
    private val onEdit: (Schedule) -> Unit,
    private val onDelete: (Schedule) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var raw: List<Schedule> = emptyList()
    private var items: List<Schedule> = emptyList()

    /** false = Cards layout, true = Bento layout (big next-up tile + colour tiles). */
    var bento = false
        set(v) {
            field = v
            rebuild()
        }

    fun submit(l: List<Schedule>) {
        raw = l
        rebuild()
    }

    private fun rebuild() {
        items = if (bento) {
            val next = raw.filter { it.enabled }.minByOrNull { Scheduler.nextTrigger(it) }
            if (next != null) listOf(next) + raw.filter { it.id != next.id } else raw
        } else raw
        notifyDataSetChanged()
    }

    private fun isHero(pos: Int) = bento && pos == 0 && items.isNotEmpty() && items[0].enabled

    /** Grid span for the Bento layout: the next-up tile is full width. */
    fun spanFor(pos: Int): Int = if (isHero(pos)) 2 else 1

    class CardVH(val b: ItemScheduleBinding) : RecyclerView.ViewHolder(b.root)
    class HeroVH(val b: ItemScheduleHeroBinding) : RecyclerView.ViewHolder(b.root)
    class TileVH(val b: ItemScheduleTileBinding) : RecyclerView.ViewHolder(b.root)

    override fun getItemViewType(position: Int): Int = when {
        !bento -> 0
        isHero(position) -> 1
        else -> 2
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (viewType) {
            1 -> HeroVH(ItemScheduleHeroBinding.inflate(inf, parent, false))
            2 -> TileVH(ItemScheduleTileBinding.inflate(inf, parent, false))
            else -> CardVH(ItemScheduleBinding.inflate(inf, parent, false))
        }
    }

    override fun getItemCount(): Int = items.size

    private class Src(val label: String, val color: Int, val icon: Int)

    private fun src(ctx: Context, s: Schedule): Src = when {
        s.extApp == Ext.SPOTIFY -> Src("SPOTIFY", 0xFF1DB954.toInt(), R.drawable.ic_src_spotify)
        s.extApp == Ext.JIO -> Src("JIOSAAVN", 0xFF2BC5B4.toInt(), R.drawable.ic_src_jiosaavn)
        s.extApp == Ext.INSTAGRAM -> Src("INSTAGRAM", 0xFFE1306C.toInt(), R.drawable.ic_src_instagram)
        s.ytId.isNotBlank() -> Src("YOUTUBE", 0xFFFF3D3D.toInt(), R.drawable.ic_src_youtube)
        Ext.hasVideo(ctx, s) -> Src("VIDEO", 0xFFF59E0B.toInt(), R.drawable.ic_src_phone)
        else -> Src("MUSIC", 0xFF7C5CFF.toInt(), R.drawable.ic_src_phone)
    }

    private fun info(ctx: Context, s: Schedule): String {
        val isExt = s.extApp.isNotBlank()
        val isYt = s.ytId.isNotBlank()
        val parts = mutableListOf(Scheduler.dayLabel(s.days))
        if (!isExt && !isYt) {
            val n = s.uris.size
            val vid = Ext.hasVideo(ctx, s)
            parts.add(n.toString() + (if (vid) (if (n == 1) " file" else " files") else (if (n == 1) " track" else " tracks")))
        }
        val dm = Scheduler.durationMin(ctx, s)
        parts.add(
            when {
                dm != null -> Scheduler.fmtDur(dm)
                s.loop && !isExt -> "Loops"
                else -> "Until stopped"
            }
        )
        return parts.joinToString(" \u00B7 ")
    }

    private fun until(s: Schedule): String = Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis())

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
        val s = items[position]
        when (h) {
            is CardVH -> bindCard(h, s)
            is HeroVH -> bindHero(h, s)
            is TileVH -> bindTile(h, s)
        }
    }

    private fun bindCard(h: CardVH, s: Schedule) {
        val ctx = h.b.root.context
        val (t, ap) = Scheduler.fmt12(s.hour, s.minute)
        h.b.time.text = t
        h.b.ampm.text = ap
        // The pill already says which source plays, so a name is shown only when somebody typed one.
        val shownName = s.customName()
        h.b.label.text = shownName
        h.b.label.visibility = if (shownName.isEmpty()) View.GONE else View.VISIBLE
        val sr = src(ctx, s)
        h.b.badge.text = sr.label
        h.b.srcIcon.setImageResource(sr.icon)
        val gd = GradientDrawable()
        gd.cornerRadius = 60f
        gd.setColor(
            if (ThemeStore.isMono(ctx)) ThemeStore.attrColor(ctx, R.attr.txChip, 0x22FFFFFF)
            else (sr.color and 0x00FFFFFF) or 0x26000000
        )
        h.b.pill.background = gd
        h.b.info.text = info(ctx, s)
        h.b.next.text = if (s.enabled) "Starts " + until(s) else "Off"
        h.b.root.alpha = if (s.enabled) 1f else 0.55f
        h.b.toggle.setOnCheckedChangeListener(null)
        h.b.toggle.isChecked = s.enabled
        h.b.toggle.setOnCheckedChangeListener { _, c -> onToggle(s, c) }
        h.b.root.setOnClickListener { onEdit(s) }
        h.b.delete.setOnClickListener { onDelete(s) }
    }

    private fun bindHero(h: HeroVH, s: Schedule) {
        val ctx = h.b.root.context
        val dp = ctx.resources.displayMetrics.density
        val (t, ap) = Scheduler.fmt12(s.hour, s.minute)
        h.b.time.text = t
        h.b.ampm.text = ap
        val shownName = s.customName()
        h.b.label.text = shownName
        h.b.label.visibility = if (shownName.isEmpty()) View.GONE else View.VISIBLE
        h.b.srcIcon.setImageResource(src(ctx, s).icon)
        h.b.info.text = info(ctx, s)
        h.b.next.text = "NEXT UP \u00B7 " + until(s).uppercase()
        val bg = GradientDrawable()
        bg.cornerRadius = 32 * dp
        bg.setColor(ThemeStore.attrColor(ctx, R.attr.txAccent, 0xFF7C5CFF.toInt()))
        h.b.root.background = bg
        h.b.toggle.setOnCheckedChangeListener(null)
        h.b.toggle.isChecked = s.enabled
        h.b.toggle.setOnCheckedChangeListener { _, c -> onToggle(s, c) }
        h.b.root.setOnClickListener { onEdit(s) }
        h.b.root.setOnLongClickListener { onDelete(s); true }
    }

    private fun bindTile(h: TileVH, s: Schedule) {
        val ctx = h.b.root.context
        val dp = ctx.resources.displayMetrics.density
        val (t, ap) = Scheduler.fmt12(s.hour, s.minute)
        h.b.time.text = t
        h.b.ampm.text = ap
        val shownName = s.customName()
        h.b.label.text = shownName
        h.b.label.visibility = if (shownName.isEmpty()) View.GONE else View.VISIBLE
        val sr = src(ctx, s)
        h.b.srcIcon.setImageResource(sr.icon)
        h.b.info.text = info(ctx, s)
        // Tile colour = the theme's card colour tinted with the source colour.
        val card = ThemeStore.attrColor(ctx, R.attr.txCard, 0xFF222222.toInt())
        val bg = GradientDrawable()
        bg.cornerRadius = 28 * dp
        if (ThemeStore.isMono(ctx)) {
            bg.setColor(card)
            bg.setStroke((1 * dp).toInt().coerceAtLeast(1), ThemeStore.attrColor(ctx, R.attr.txStroke, 0x66FFFFFF))
        } else {
            bg.setColor(ColorUtils.compositeColors((sr.color and 0x00FFFFFF) or 0x38000000, card))
        }
        h.b.root.background = bg
        h.b.root.alpha = if (s.enabled) 1f else 0.55f
        h.b.toggle.setOnCheckedChangeListener(null)
        h.b.toggle.isChecked = s.enabled
        h.b.toggle.setOnCheckedChangeListener { _, c -> onToggle(s, c) }
        h.b.root.setOnClickListener { onEdit(s) }
        h.b.root.setOnLongClickListener { onDelete(s); true }
    }
}
