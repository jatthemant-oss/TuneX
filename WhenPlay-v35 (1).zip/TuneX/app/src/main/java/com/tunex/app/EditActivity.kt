package com.tunex.app

import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.tunex.app.databinding.ActivityEditBinding
import java.util.Calendar

class EditActivity : AppCompatActivity() {

    private lateinit var b: ActivityEditBinding
    private var hour = 6
    private var minute = 0
    private var editId = -1
    private var ytId = ""
    private var ytUrl = ""
    private var extApp = ""
    private var extUrl = ""
    private var trackSec = 0
    private var clashOk = false
    private var stopEnabled = false
    private var stopHour = 7
    private var stopMinute = 0
    private val uris = mutableListOf<String>()
    private val names = mutableListOf<String>()
    private val dayOrder = intArrayOf(1, 2, 3, 4, 5, 6, 0)
    private val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    // System file picker: works with any folder, SD card, Downloads, WhatsApp, Drive, etc.
    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
            if (list.isNotEmpty()) {
                ytId = ""; ytUrl = ""; extApp = ""; extUrl = ""
            }
            for (u in list) {
                try {
                    contentResolver.takePersistableUriPermission(
                        u, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                val s = u.toString()
                if (s !in uris) {
                    uris.add(s)
                    names.add(displayName(u))
                }
            }
            renderSources()
        }

    private fun displayName(u: android.net.Uri): String {
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "Track"
        } catch (e: Exception) {
            "Track"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityEditBinding.inflate(layoutInflater)
        setContentView(b.root)
        ThemeStore.styleBars(this)

        val cal = Calendar.getInstance()
        hour = cal.get(Calendar.HOUR_OF_DAY)
        minute = cal.get(Calendar.MINUTE)
        stopHour = (hour + 1) % 24
        stopMinute = minute
        var days = 0
        var vol = 70
        var loop = false

        editId = intent.getIntExtra("id", -1)
        val existing = Store.get(this, editId)
        // a new schedule starts at the phone's current media volume
        if (existing == null) vol = sysVolPercent().coerceIn(10, 100)
        if (existing != null) {
            hour = existing.hour
            minute = existing.minute
            days = existing.days
            vol = existing.volume
            loop = existing.loop
            stopEnabled = existing.stopEnabled
            if (existing.stopEnabled) {
                stopHour = existing.stopHour
                stopMinute = existing.stopMinute
            }
            ytId = existing.ytId
            ytUrl = existing.ytUrl
            extApp = existing.extApp
            extUrl = existing.extUrl
            trackSec = existing.trackSec
            b.labelInput.setText(existing.label)
            uris.addAll(existing.uris)
            names.addAll(existing.names)
            b.screenTitle.text = "Edit schedule"
        }

        for (i in dayOrder) {
            val chip = layoutInflater.inflate(R.layout.chip_day, b.chipDays, false) as android.widget.TextView
            chip.text = dayNames[i]
            chip.tag = i
            chip.isSelected = ((days shr i) and 1) == 1
            chip.setOnClickListener { it.isSelected = !it.isSelected; clashOk = false }
            b.chipDays.addView(chip)
        }

        b.switchLoop.isChecked = loop
        b.switchLoop.setOnCheckedChangeListener { _, _ -> clashOk = false; renderDur() }
        b.switchStop.isChecked = stopEnabled
        b.switchStop.setOnCheckedChangeListener { _, c ->
            stopEnabled = c
            renderStop()
        }

        b.volSeek.progress = vol
        b.volText.text = "Volume $vol%"
        b.volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                b.volText.text = "Volume $p%"
                // moving the slider changes the phone's media volume too
                if (fromUser) setSysVolPercent(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        b.timeCard.setOnClickListener {
            pickTime("Start time", hour, minute) { h, m ->
                hour = h
                minute = m
                renderTime()
            }
        }
        b.stopRow.setOnClickListener {
            pickTime("Stop time", stopHour, stopMinute) { h, m ->
                stopHour = h
                stopMinute = m
                stopEnabled = true
                b.switchStop.isChecked = true
                renderStop()
            }
        }

        b.btnAddSongs.setOnClickListener {
            picker.launch(arrayOf("audio/*", "video/*", "application/ogg", "application/octet-stream"))
        }
        b.btnClearSongs.setOnClickListener {
            uris.clear()
            names.clear()
            renderSources()
        }

        b.btnYoutube.setOnClickListener {
            askLink("YouTube link", "https://youtu.be/...", { Yt.parseId(it) != null }) { txt ->
                ytId = Yt.parseId(txt) ?: ""
                ytUrl = txt
                uris.clear(); names.clear(); extApp = ""; extUrl = ""
                trackSec = 0
                renderSources()
                fetchSec("youtube", "https://www.youtube.com/watch?v=" + ytId)
            }
        }
        b.btnClearYt.setOnClickListener {
            ytId = ""; ytUrl = ""; trackSec = 0
            renderSources()
        }

        b.btnSpotify.setOnClickListener {
            askLink("Spotify link", "Paste Spotify link", { Ext.valid(Ext.SPOTIFY, it) }, true, "") { txt ->
                setExt(Ext.SPOTIFY, txt, 0)
                fetchSec(Ext.SPOTIFY, txt)
            }
        }
        b.btnJio.setOnClickListener {
            askLink("JioSaavn link", "Paste JioSaavn link", { Ext.valid(Ext.JIO, it) }, true, "") { txt ->
                setJio(txt)
                fetchSec(Ext.JIO, txt)
            }
        }
        b.btnInstagram.setOnClickListener {
            askLink("Instagram reel link", "Paste Instagram reel link", { Ext.valid(Ext.INSTAGRAM, it) }, true, "", "reel") { txt ->
                setExt(Ext.INSTAGRAM, txt, 0)
                fetchSec(Ext.INSTAGRAM, txt)
            }
        }
        b.btnClearExt.setOnClickListener {
            extApp = ""; extUrl = ""; trackSec = 0
            renderSources()
        }

        b.btnSave.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            if (uris.isNotEmpty() && trackSec <= 0) trackSec = Scheduler.localSec(this, uris.toList())
            // Stop time longer than the song needs Repeat, otherwise it could never reach that time.
            if (stopEnabled && trackSec > 0 && !b.switchLoop.isChecked &&
                Scheduler.span(hour, minute, stopHour, stopMinute) * 60 > trackSec + 30
            ) {
                val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
                MaterialAlertDialogBuilder(this)
                    .setTitle("Repeat required")
                    .setMessage(
                        "The " + noun() + " is " + mmss(trackSec) + " long, but the stop time is $st $sap. " +
                            "Turn on Repeat to play until the stop time, or choose an earlier stop time."
                    )
                    .setPositiveButton("Turn on Repeat") { _, _ -> b.switchLoop.isChecked = true }
                    .setNegativeButton("Edit stop time", null)
                    .show()
                return@setOnClickListener
            }
            if (!checkClash(s)) return@setOnClickListener
            if (s.extApp.isNotBlank() && s.extApp != Ext.INSTAGRAM && !Ext.listenerEnabled(this)) {
                val needed = s.loop || s.stopEnabled
                if (needed || !listenerAsked) {
                    listenerAsked = true
                    val d = MaterialAlertDialogBuilder(this)
                        .setTitle("Allow notification access")
                        .setMessage(
                            if (needed)
                                "Repeat and Stop time for Spotify and JioSaavn need Notification access, so WhenPlay can control playback. " +
                                    "Open settings, turn on WhenPlay, then come back and save."
                            else
                                "For Spotify and JioSaavn to start on their own, even when the phone is locked, WhenPlay needs Notification access. " +
                                    "Open settings, turn on WhenPlay, then come back and save."
                        )
                        .setPositiveButton("Open settings") { _, _ ->
                            startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }
                        .setNegativeButton("Cancel", null)
                    if (!needed) d.setNeutralButton("Save anyway") { _, _ -> b.btnSave.performClick() }
                    d.show()
                    return@setOnClickListener
                }
            }
            persist(s)
            Toast.makeText(
                this,
                "Scheduled • starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_LONG
            ).show()
            finish()
        }

        b.btnPlayNow.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            persist(s)
            when {
                s.extApp.isNotBlank() -> {
                    startActivity(Ext.intent(this, s))
                    if (s.extApp != Ext.INSTAGRAM) Handler(Looper.getMainLooper()).postDelayed(
                        { Ext.sendKey(applicationContext, KeyEvent.KEYCODE_MEDIA_PLAY) }, 8000L
                    )
                }
                s.ytId.isNotBlank() ->
                    startActivity(Intent(this, YtPlayerActivity::class.java).putExtra("id", s.id))
                Ext.hasVideo(this, s) ->
                    startActivity(Intent(this, VideoPlayerActivity::class.java).putExtra("id", s.id))
                else ->
                    ContextCompat.startForegroundService(
                        this, Intent(this, PlayerService::class.java).putExtra("id", s.id)
                    )
            }
            Toast.makeText(this, "Playing now (test)", Toast.LENGTH_SHORT).show()
        }

        renderTime()
        renderStop()
        renderSources()
    }

    private fun pickTime(title: String, h: Int, m: Int, done: (Int, Int) -> Unit) {
        val p = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_12H)
            .setHour(h)
            .setMinute(m)
            .setTitleText(title)
            .build()
        p.addOnPositiveButtonClickListener { done(p.hour, p.minute) }
        p.show(supportFragmentManager, "time")
    }

    private fun askLink(title: String, hint: String, ok: (String) -> Boolean, tip: Boolean = false, current: String = "", noun: String = "song", done: (String) -> Unit) {
        val et = EditText(this)
        et.hint = hint
        et.setSingleLine()
        et.setSelectAllOnFocus(true)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.LinearLayout(this)
        box.orientation = android.widget.LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et)
        if (tip) {
            val t = android.widget.TextView(this)
            t.textSize = 12.5f
            t.setPadding(0, pad / 2, 0, 0)
            box.addView(t)
            val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
            fun upd() {
                val v = et.text.toString().trim()
                val raw = Ext.cleanLink(v)
                when {
                    v.isEmpty() -> {
                        t.setTextColor(muted)
                        t.text = "Open the $noun in the app, tap Share → Copy link, then paste it here."
                    }
                    ok(raw) -> {
                        t.setTextColor(0xFF3DDC97.toInt())
                        t.text = "✔ Link detected. This exact $noun will play."
                    }
                    else -> {
                        t.setTextColor(0xFFFFB74D.toInt())
                        t.text = "⚠ Only $noun links from this app are supported."
                    }
                }
            }
            et.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = upd()
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
            upd()
        }
        et.post { et.requestFocus() }
        // Read the clipboard only once the dialog has focus (earlier Android returns an old copy).
        et.postDelayed({
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                val cl = Ext.cleanLink(clip)
                if (et.text.isEmpty() && Ext.isLink(cl) && ok(cl)) {
                    et.setText(cl)
                    et.selectAll()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, 300)
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Use") { _, _ ->
                val rawTxt = et.text.toString().trim()
                val txt = if (Ext.isLink(rawTxt)) Ext.cleanLink(rawTxt) else rawTxt
                if (!ok(txt)) {
                    Toast.makeText(this, "This link is not supported", Toast.LENGTH_SHORT).show()
                } else {
                    done(txt)
                }
            }
            .setNeutralButton("Clear", null)
            .setNegativeButton("Cancel", null)
            .show()
        // "Clear" only empties the box - the dialog stays open so a new link can be pasted right away.
        dlg.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            et.setText("")
            et.requestFocus()
        }
    }

    /** Turns the chosen song into its exact Spotify link so it plays reliably; falls back to a name search. */
    private fun pickSpotify(song: Ext.Song) {
        Toast.makeText(this, "Matching on Spotify…", Toast.LENGTH_SHORT).show()
        Thread {
            val link = Ext.spotifyLink(song.url)
            runOnUiThread {
                if (link != null) {
                    setExt(Ext.SPOTIFY, link, song.sec)
                    Toast.makeText(this, "Matched: " + song.title, Toast.LENGTH_SHORT).show()
                } else {
                    setExt(Ext.SPOTIFY, song.title + " " + song.artist, song.sec)
                }
            }
        }.start()
    }

    private fun setJio(v: String) = setExt(Ext.JIO, v, 0)

    private fun setExt(app: String, v: String, sec: Int) {
        extApp = app
        extUrl = v
        trackSec = sec
        uris.clear(); names.clear(); ytId = ""; ytUrl = ""
        renderSources()
        renderDur()
    }

    /** Looks up the song length from its link (best effort) and refreshes the warning text. */
    private fun fetchSec(kind: String, link: String) {
        Thread {
            val sec = Ext.fetchSec(kind, link)
            runOnUiThread {
                if (sec > 0) {
                    trackSec = sec
                    renderDur()
                } else if (kind == Ext.INSTAGRAM && extApp == Ext.INSTAGRAM && trackSec <= 0) {
                    askReelLength()
                }
            }
        }.start()
    }

    /** Instagram doesn't always share the reel length, so let the user type it (needed for Repeat / Stop checks). */
    private fun askReelLength() {
        val et = EditText(this)
        et.hint = "e.g. 30  or  0:45"
        et.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et)
        MaterialAlertDialogBuilder(this)
            .setTitle("Reel length")
            .setMessage("Couldn't read the reel length automatically. Enter it in seconds (or m:ss) so Repeat and Stop time can be checked.")
            .setView(box)
            .setPositiveButton("Set") { _, _ ->
                val t = et.text.toString().trim()
                val sec = if (t.contains(":")) {
                    val p = t.split(":")
                    (p[0].toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
                } else (t.toIntOrNull() ?: 0)
                if (sec > 0) {
                    trackSec = sec
                    renderDur()
                }
            }
            .setNegativeButton("Skip", null)
            .show()
    }

    private fun audio() = getSystemService(AUDIO_SERVICE) as android.media.AudioManager

    private fun sysVolPercent(): Int {
        val am = audio()
        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
        return if (max <= 0) 70 else am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) * 100 / max
    }

    private fun setSysVolPercent(p: Int) {
        try {
            val am = audio()
            val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (max * p / 100).coerceIn(0, max), 0)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // phone volume buttons -> slider
    private val volReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context?, i: Intent?) {
            if (i?.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) != android.media.AudioManager.STREAM_MUSIC) return
            val p = sysVolPercent().coerceIn(10, 100)
            if (b.volSeek.progress != p) {
                b.volSeek.progress = p
                b.volText.text = "Volume $p%"
            }
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            registerReceiver(volReceiver, android.content.IntentFilter("android.media.VOLUME_CHANGED_ACTION"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onStop() {
        try {
            unregisterReceiver(volReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onStop()
    }

    private var listenerAsked = false

    private fun renderTime() {
        val (t, ap) = Scheduler.fmt12(hour, minute)
        b.timeText.text = t
        b.ampmText.text = ap
        clashOk = false
        renderDur()
    }

    private fun noun() = if (uris.isNotEmpty()) "playlist" else if (extApp == Ext.INSTAGRAM) "reel" else "song"

    private fun mmss(sec: Int) = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')

    private fun renderDur() {
        val loopOn = b.switchLoop.isChecked
        val sb = StringBuilder()
        var warn = false
        if (trackSec > 0) sb.append(if (uris.isNotEmpty()) "Total length " else if (extApp == Ext.INSTAGRAM) "Reel length " else "Song length ").append(mmss(trackSec)).append("\n")
        if (stopEnabled) {
            val sp = Scheduler.span(hour, minute, stopHour, stopMinute)
            val runSec = sp * 60
            val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
            if (trackSec <= 0) {
                sb.append("Runs for ").append(Scheduler.fmtDur(sp))
            } else if (runSec <= trackSec + 30) {
                sb.append("Stops at ").append(st).append(" ").append(sap).append(", before it ends.")
            } else {
                val full = runSec / trackSec
                val rest = runSec % trackSec
                val plan = StringBuilder()
                plan.append(full).append(if (full == 1) " full play" else " full plays")
                if (rest > 15) plan.append(" + ").append(mmss(rest))
                if (loopOn) {
                    sb.append("Repeat: ").append(plan).append(", then stops at ").append(st).append(" ").append(sap).append(".")
                } else {
                    warn = true
                    sb.append("Plays once (").append(mmss(trackSec)).append(") and stops.\n")
                    sb.append("⚠ Stop time is later than the " + noun() + ". Turn on Repeat to play ").append(plan)
                        .append(" until ").append(st).append(" ").append(sap).append(".")
                }
            }
        } else if (trackSec > 0 && !loopOn) {
            sb.append("Plays once, then stops.")
        }
        b.durText.setTextColor(if (warn) 0xFFFFB74D.toInt() else ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8F93B8.toInt()))
        b.durText.text = sb.toString().trim()
    }

    /** Two schedules can't play together: ask to create this one after the other ends. */
    /** Two schedules can't play together: ask to create this one after the other ends. */
    private fun checkClash(s: Schedule): Boolean {
        if (clashOk) return true
        val cl = Scheduler.conflict(this, s) ?: return true
        val c = cl.other
        val (cs, cap) = Scheduler.fmt12(c.hour, c.minute)
        if (cl.otherOpen || cl.candOpen) {
            val msg = if (cl.otherOpen)
                "\u201C" + c.label + "\u201D ($cs $cap) is set to Repeat with no stop time, so it keeps playing until stopped.\n\n" +
                    "This schedule will only play if \u201C" + c.label + "\u201D ends before its start time. Add a stop time to \u201C" + c.label + "\u201D to avoid a conflict."
            else
                "This schedule is set to Repeat with no stop time, so it will keep playing into \u201C" + c.label + "\u201D ($cs $cap).\n\n" +
                    "\u201C" + c.label + "\u201D will only play if this one ends first. Add a stop time to avoid a conflict."
            MaterialAlertDialogBuilder(this)
                .setTitle("Repeat schedule overlaps")
                .setMessage(msg)
                .setPositiveButton("Save anyway") { _, _ -> clashOk = true; b.btnSave.performClick() }
                .setNegativeButton("Edit time", null)
                .show()
            return false
        }
        val ce = Scheduler.endMinutes(this, c)
        val (es, eap) = Scheduler.fmt12(ce / 60, ce % 60)
        val dm = Scheduler.durationMin(this, c)
        val len = if (dm != null) " (" + Scheduler.fmtDur(dm) + ")" else ""
        MaterialAlertDialogBuilder(this)
            .setTitle("Schedule conflict")
            .setMessage(
                "\u201C" + c.label + "\u201D plays $cs $cap \u2192 $es $eap$len.\n\n" +
                    "Two schedules can\u2019t play at the same time. Start this one after $es $eap."
            )
            .setPositiveButton("Start at $es $eap") { _, _ ->
                val keep = if (stopEnabled) Scheduler.span(hour, minute, stopHour, stopMinute) else 0
                hour = ce / 60
                minute = ce % 60
                if (stopEnabled) {
                    val e = (ce + keep) % 1440
                    stopHour = e / 60
                    stopMinute = e % 60
                }
                renderTime()
                renderStop()
                Toast.makeText(this, "Start time updated. Tap Save.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Edit time", null)
            .show()
        return false
    }

    private fun renderStop() {
        val (t, ap) = Scheduler.fmt12(stopHour, stopMinute)
        b.stopTime.text = "$t $ap"
        b.stopTime.alpha = if (stopEnabled) 1f else 0.4f
        b.stopEditIcon.alpha = if (stopEnabled) 1f else 0.4f
        renderDur()
    }

    private fun renderSources() {
        if (names.isEmpty()) {
            b.songsList.text = "No files selected"
            b.btnClearSongs.visibility = View.GONE
        } else {
            b.songsList.text = names.mapIndexed { i, n -> "${i + 1}. $n" }.joinToString("\n")
            b.btnClearSongs.visibility = View.VISIBLE
        }
        if (ytId.isBlank()) {
            b.ytText.text = "Not set"
            b.btnClearYt.visibility = View.GONE
        } else {
            b.ytText.text = ytUrl
            b.btnClearYt.visibility = View.VISIBLE
        }
        b.spotifyText.text = if (extApp == Ext.SPOTIFY) extUrl else "Not set"
        b.jioText.text = if (extApp == Ext.JIO) extUrl else "Not set"
        b.instagramText.text = if (extApp == Ext.INSTAGRAM) extUrl else "Not set"
        b.btnClearExt.visibility = if (extApp.isBlank()) View.GONE else View.VISIBLE
        if (uris.isNotEmpty()) {
            refreshLocalSec()
        } else if (ytId.isBlank() && extApp.isBlank()) {
            trackSec = 0
            renderDur()
        }
    }

    /** Reads the real length of the chosen phone files so Stop time / Repeat can be checked. */
    private fun refreshLocalSec() {
        val snap = uris.toList()
        Thread {
            val sec = Scheduler.localSec(this, snap)
            runOnUiThread {
                if (uris.isNotEmpty() && uris.toList() == snap) {
                    trackSec = sec
                    renderDur()
                }
            }
        }.start()
    }

    private fun collect(): Schedule? {
        if (uris.isEmpty() && ytId.isBlank() && extApp.isBlank()) {
            Toast.makeText(this, "Add music, a YouTube, Spotify, JioSaavn or Instagram link", Toast.LENGTH_SHORT).show()
            return null
        }
        var days = 0
        for (i in 0 until b.chipDays.childCount) {
            val c = b.chipDays.getChildAt(i)
            if (c.isSelected) days = days or (1 shl (c.tag as Int))
        }
        val id = if (editId > 0) editId else Store.nextId(this)
        val label = b.labelInput.text.toString().trim().ifBlank { "Schedule" }
        return Schedule(
            id = id,
            hour = hour,
            minute = minute,
            days = days,
            label = label,
            uris = uris.toList(),
            names = names.toList(),
            enabled = true,
            volume = b.volSeek.progress.coerceAtLeast(10),
            onceAt = 0L,
            ytId = ytId,
            ytUrl = ytUrl,
            loop = b.switchLoop.isChecked,
            stopEnabled = stopEnabled,
            stopHour = stopHour,
            stopMinute = stopMinute,
            extApp = extApp,
            extUrl = extUrl,
            trackSec = trackSec
        )
    }

    private fun persist(s: Schedule) {
        editId = s.id
        Store.upsert(this, s)
        Scheduler.cancel(this, s.id)
        Scheduler.arm(this, s)
    }
}
