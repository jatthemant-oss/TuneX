package com.tunex.app

import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.tunex.app.databinding.ActivityEditBinding
import java.util.Calendar

class EditActivity : AppCompatActivity() {

    private lateinit var b: ActivityEditBinding
    private var hour = 6
    private var minute = 0
    private var editId = -1
    private var ytId = ""
    private var ytUrl = ""
    private var extApp = ""
    private var extUrl = ""
    private var trackSec = 0
    private var clashOk = false
    private var stopEnabled = false
    private var stopHour = 7
    private var stopMinute = 0
    private var label = "" // optional name: the Name box appears once a source is set
    private var srcKey: String? = null
    private var autoTitle = ""
    private var clearedNote = false
    private val dayHost: android.view.ViewGroup get() = b.chipDays
    private val pills by lazy { LayoutStore.isPills(this) }
    // source chosen in the avatar row: "phone", "yt", or one of Ext.SPOTIFY / Ext.JIO / Ext.INSTAGRAM
    private var pendingSrc: String? = null
    private val uris = mutableListOf<String>()
    private val names = mutableListOf<String>()
    private val dayOrder = intArrayOf(1, 2, 3, 4, 5, 6, 0)
    private val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    // System file picker: works with any folder, SD card, Downloads, WhatsApp, Drive, etc.
    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
            if (list.isNotEmpty()) {
                ytId = ""; ytUrl = ""; extApp = ""; extUrl = ""
            }
            for (u in list) {
                try {
                    contentResolver.takePersistableUriPermission(
                        u, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                val s = u.toString()
                if (s !in uris) {
                    uris.add(s)
                    names.add(displayName(u))
                }
            }
            renderSources()
        }

    private fun displayName(u: android.net.Uri): String {
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "Track"
        } catch (e: Exception) {
            "Track"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityEditBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.nameInput.setHintTextColor(
            androidx.core.graphics.ColorUtils.setAlphaComponent(ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt()), 0x80)
        )
        applyStyleEdit()
        ThemeStore.styleBars(this)

        val cal = Calendar.getInstance()
        hour = cal.get(Calendar.HOUR_OF_DAY)
        minute = cal.get(Calendar.MINUTE)
        stopHour = (hour + 1) % 24
        stopMinute = minute
        var days = 0
        var vol = 70
        var loop = false

        editId = intent.getIntExtra("id", -1)
        val existing = Store.get(this, editId)
        // a new schedule starts at the phone's current media volume
        if (existing == null) vol = sysVolPercent().coerceIn(10, 100)
        if (existing != null) {
            hour = existing.hour
            minute = existing.minute
            days = existing.days
            vol = existing.volume
            loop = existing.loop
            stopEnabled = existing.stopEnabled
            if (existing.stopEnabled) {
                stopHour = existing.stopHour
                stopMinute = existing.stopMinute
            }
            ytId = existing.ytId
            ytUrl = existing.ytUrl
            extApp = existing.extApp
            extUrl = existing.extUrl
            trackSec = existing.trackSec
            label = existing.customName()
            uris.addAll(existing.uris)
            names.addAll(existing.names)
        }

        for (i in dayOrder) {
            val chip = layoutInflater.inflate(R.layout.chip_day, b.chipDays, false) as android.widget.TextView
            chip.tag = i
            chip.isSelected = ((days shr i) and 1) == 1
            chip.text = dayNames[i]
            chip.setOnClickListener { it.isSelected = !it.isSelected; clashOk = false; renderSetLabel() }
            b.chipDays.addView(chip)
        }

        b.switchLoop.isChecked = loop
        b.switchLoop.setOnCheckedChangeListener { _, c ->
            if (c && extApp == Ext.INSTAGRAM) {
                b.switchLoop.isChecked = false
                showLoopLocked()
            } else {
                clashOk = false
                renderDur()
            }
            renderLoopValue()
        }
        b.switchStop.isChecked = stopEnabled
        b.switchStop.setOnCheckedChangeListener { _, c ->
            stopEnabled = c
            renderStop()
        }

        // Loop cell: tap flips it. Instagram reels loop by themselves, so Loop stays locked there.
        b.cellLoop.setOnClickListener {
            if (extApp == Ext.INSTAGRAM) showLoopLocked()
            else b.switchLoop.isChecked = !b.switchLoop.isChecked
        }
        b.cellRepeat.setOnClickListener {
            b.daysCard.visibility = if (b.daysCard.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        b.volSeek.progress = vol
        b.volText.text = "$vol%"
        b.volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                b.volText.text = "$p%"
                // moving the slider changes the phone's media volume too
                if (fromUser) setSysVolPercent(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        b.timeCard.setOnClickListener {
            pickTime("Start time", hour, minute) { h, m ->
                hour = h
                minute = m
                renderTime()
            }
        }
        b.stopRow.setOnClickListener {
            val choose = {
                pickTime("Stop time", stopHour, stopMinute) { h, m ->
                    stopHour = h
                    stopMinute = m
                    stopEnabled = true
                    b.switchStop.isChecked = true
                    renderStop()
                }
            }
            if (!stopEnabled) {
                choose()
            } else {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Stop at")
                    .setItems(arrayOf("Change time", "Remove stop time")) { _, which ->
                        if (which == 0) choose() else {
                            stopEnabled = false
                            b.switchStop.isChecked = false
                            clashOk = false
                            renderStop()
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
        b.btnPaste.setOnClickListener { quickPaste() }
        b.linkRow.setOnClickListener { pendingSrc?.let { openSource(it) } }
        b.linkRow.setOnLongClickListener { showSourceSheet(); true }

        b.tilePhone.setOnClickListener { pendingSrc = "phone"; renderSummary(); chooseFiles() }
        b.tileYt.setOnClickListener { pendingSrc = "yt"; renderSummary() }
        b.tileIg.setOnClickListener { pendingSrc = Ext.INSTAGRAM; renderSummary() }
        b.tileSp.setOnClickListener { pendingSrc = Ext.SPOTIFY; renderSummary() }
        b.tileJio.setOnClickListener { pendingSrc = Ext.JIO; renderSummary() }

        b.btnSave.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            if (uris.isNotEmpty() && trackSec <= 0) trackSec = Scheduler.localSec(this, uris.toList())
            // Stop time longer than the song needs Repeat, otherwise it could never reach that time.
            if (s.extApp != Ext.INSTAGRAM && stopEnabled && trackSec > 0 && !b.switchLoop.isChecked &&
                Scheduler.span(hour, minute, stopHour, stopMinute) * 60 > trackSec + 30
            ) {
                val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
                MaterialAlertDialogBuilder(this)
                    .setTitle("Loop mode required")
                    .setMessage(
                        "The " + noun() + " is " + mmss(trackSec) + " long, but the stop time is $st $sap. " +
                            "Turn on Loop mode to play until the stop time, or choose an earlier stop time."
                    )
                    .setPositiveButton("Turn on Loop mode") { _, _ -> b.switchLoop.isChecked = true }
                    .setNegativeButton("Edit stop time", null)
                    .show()
                return@setOnClickListener
            }
            // Without a stop time a reel plays once, so WhenPlay must know its length
            if (s.extApp == Ext.INSTAGRAM && !stopEnabled && trackSec <= 0) {
                askReelLength(true)
                return@setOnClickListener
            }
            if (!checkClash(s)) return@setOnClickListener
            if (s.extApp.isNotBlank() && s.extApp != Ext.INSTAGRAM && !Ext.listenerEnabled(this)) {
                val needed = s.loop || s.stopEnabled
                if (needed || !listenerAsked) {
                    listenerAsked = true
                    val d = MaterialAlertDialogBuilder(this)
                        .setTitle("Allow notification access")
                        .setMessage(
                            if (needed)
                                "Loop mode and Stop time for Spotify and JioSaavn need Notification access, so WhenPlay can control playback. " +
                                    "Open settings, turn on WhenPlay, then come back and save."
                            else
                                "For Spotify and JioSaavn to start on their own, even when the phone is locked, WhenPlay needs Notification access. " +
                                    "Open settings, turn on WhenPlay, then come back and save."
                        )
                        .setPositiveButton("Open settings") { _, _ ->
                            startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }
                        .setNegativeButton("Cancel", null)
                    if (!needed) d.setNeutralButton("Save anyway") { _, _ -> b.btnSave.performClick() }
                    d.show()
                    return@setOnClickListener
                }
            }
            persist(s)
            Toast.makeText(
                this,
                "Scheduled • starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_LONG
            ).show()
            finish()
        }

        b.nameInput.setText(label)
        renderTime()
        renderStop()
        renderLoopValue()
        renderSources()
    }

    private fun pickTime(title: String, h: Int, m: Int, done: (Int, Int) -> Unit) {
        val p = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_12H)
            .setHour(h)
            .setMinute(m)
            .setTitleText(title)
            .build()
        p.addOnPositiveButtonClickListener { done(p.hour, p.minute) }
        p.show(supportFragmentManager, "time")
    }

    private fun chooseFiles() {
        picker.launch(arrayOf("audio/*", "video/*", "application/ogg", "application/octet-stream"))
    }

    private fun askYoutube() {
        askLink("Paste YouTube link", "Video or Shorts", R.drawable.ic_src_youtube, "youtube", { Yt.parseId(it) != null }, "video") { txt ->
            ytId = Yt.parseId(txt) ?: ""
            ytUrl = txt
            uris.clear(); names.clear(); extApp = ""; extUrl = ""
            trackSec = 0
            renderSources()
            fetchSec("youtube", "https://www.youtube.com/watch?v=" + ytId)
        }
    }

    private fun askSpotify() {
        askLink("Paste Spotify link", "Song link", R.drawable.ic_src_spotify, Ext.SPOTIFY, { Ext.valid(Ext.SPOTIFY, it) }, "song") { txt ->
            setExt(Ext.SPOTIFY, txt, 0)
            fetchSec(Ext.SPOTIFY, txt)
        }
    }

    private fun askJio() {
        askLink("Paste JioSaavn link", "Song link", R.drawable.ic_src_jiosaavn, Ext.JIO, { Ext.valid(Ext.JIO, it) }, "song") { txt ->
            setJio(txt)
            fetchSec(Ext.JIO, txt)
        }
    }

    private fun askInstagram() {
        askLink("Paste Instagram Reel link", "Reel or post link", R.drawable.ic_src_instagram, Ext.INSTAGRAM, { Ext.valid(Ext.INSTAGRAM, it) }, "reel") { txt ->
            setExt(Ext.INSTAGRAM, txt, 0)
            fetchSec(Ext.INSTAGRAM, txt)
        }
    }

    private fun clearSource() {
        uris.clear(); names.clear()
        ytId = ""; ytUrl = ""; extApp = ""; extUrl = ""
        trackSec = 0
        renderSources()
    }

    /** "Change" sheet: pick another source. One source per schedule, switching clears the name. */
    private fun showSourceSheet() {
        val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sb = com.tunex.app.databinding.SheetSourcesBinding.inflate(layoutInflater)
        dlg.setContentView(sb.root)
        (sb.root.parent as? View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        fun tag(v: View, on: Boolean) { v.visibility = if (on) View.VISIBLE else View.GONE }
        tag(sb.tagPhone, uris.isNotEmpty())
        tag(sb.tagYt, ytId.isNotBlank())
        tag(sb.tagIg, extApp == Ext.INSTAGRAM)
        tag(sb.tagSp, extApp == Ext.SPOTIFY)
        tag(sb.tagJio, extApp == Ext.JIO)
        sb.subPhone.text = if (uris.isNotEmpty()) "Add more files" else "Choose a file"
        sb.srcPhone.setOnClickListener { dlg.dismiss(); chooseFiles() }
        sb.srcYt.setOnClickListener { dlg.dismiss(); askYoutube() }
        sb.srcIg.setOnClickListener { dlg.dismiss(); askInstagram() }
        sb.srcSp.setOnClickListener { dlg.dismiss(); askSpotify() }
        sb.srcJio.setOnClickListener { dlg.dismiss(); askJio() }
        sb.srcRemove.setOnClickListener { dlg.dismiss(); clearSource() }
        sb.srcCancel.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
    }

    private fun replaceNote(): String {
        if (uris.isEmpty() && ytId.isBlank() && extApp.isBlank()) return ""
        val nm = b.nameInput.text.toString().trim()
        return if (nm.isNotEmpty()) "This replaces your current source. Your name \u201C" + nm + "\u201D will be cleared."
        else "This replaces your current source."
    }

    /** Bottom sheet for pasting a link: paste button, live check, title preview, "Use this link". */
    private fun askLink(title: String, sub: String, icon: Int, kind: String, ok: (String) -> Boolean, noun: String, done: (String) -> Unit) {
        val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sb = com.tunex.app.databinding.SheetLinkBinding.inflate(layoutInflater)
        dlg.setContentView(sb.root)
        (sb.root.parent as? View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        sb.sheetIcon.setImageResource(icon)
        sb.sheetTitle.text = title
        sb.sheetSub.text = sub
        val note = replaceNote()
        sb.sheetNote.text = note
        sb.sheetNote.visibility = if (note.isEmpty()) View.GONE else View.VISIBLE
        val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        var shownFor = ""
        fun upd() {
            val v = sb.sheetInput.text.toString().trim()
            val txt = if (Ext.isLink(v)) Ext.cleanLink(v) else v
            val good = v.isNotEmpty() && ok(txt)
            sb.sheetUse.isEnabled = good
            sb.sheetPaste.text = if (v.isEmpty()) "Paste" else "Clear"
            when {
                v.isEmpty() -> {
                    sb.sheetHint.setTextColor(muted)
                    sb.sheetHint.text = "Open the $noun in the app, tap Share \u2192 Copy link, then paste it here."
                }
                good -> {
                    sb.sheetHint.setTextColor(0xFF3DDC97.toInt())
                    sb.sheetHint.text = "\u2714 Link detected. This exact $noun will play."
                }
                else -> {
                    sb.sheetHint.setTextColor(0xFFFFB74D.toInt())
                    sb.sheetHint.text = "\u26A0 Only $noun links from this app are supported."
                }
            }
            if (!good) {
                sb.sheetPreview.visibility = View.GONE
                shownFor = ""
            } else if ((kind == "youtube" || kind == Ext.SPOTIFY) && shownFor != txt) {
                shownFor = txt
                sb.sheetPreview.visibility = View.GONE
                val link = if (kind == "youtube") "https://www.youtube.com/watch?v=" + (Yt.parseId(txt) ?: "") else txt
                Thread {
                    val t = Ext.fetchTitle(kind, link)
                    runOnUiThread {
                        if (dlg.isShowing && shownFor == txt && t.isNotEmpty()) {
                            sb.sheetPreview.text = t
                            sb.sheetPreview.visibility = View.VISIBLE
                        }
                    }
                }.start()
            }
        }
        sb.sheetInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = upd()
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        sb.sheetPaste.setOnClickListener {
            if (sb.sheetInput.text.isNotEmpty()) {
                sb.sheetInput.setText("")
                return@setOnClickListener
            }
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                if (clip.isBlank()) {
                    Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                } else {
                    sb.sheetInput.setText(if (Ext.isLink(clip)) Ext.cleanLink(clip) else clip.trim())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // A link copied just before opening the sheet is pasted automatically (read once the sheet has focus).
        sb.sheetInput.postDelayed({
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                val cl = Ext.cleanLink(clip)
                if (sb.sheetInput.text.isEmpty() && Ext.isLink(cl) && ok(cl)) sb.sheetInput.setText(cl)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, 300)
        sb.sheetUse.setOnClickListener {
            val rawTxt = sb.sheetInput.text.toString().trim()
            val txt = if (Ext.isLink(rawTxt)) Ext.cleanLink(rawTxt) else rawTxt
            if (!ok(txt)) {
                Toast.makeText(this, "This link is not supported", Toast.LENGTH_SHORT).show()
            } else {
                dlg.dismiss()
                done(txt)
            }
        }
        sb.sheetCancel.setOnClickListener { dlg.dismiss() }
        upd()
        dlg.show()
        dlg.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
    }

    /** Turns the chosen song into its exact Spotify link so it plays reliably; falls back to a name search. */
    private fun pickSpotify(song: Ext.Song) {
        Toast.makeText(this, "Matching on Spotify…", Toast.LENGTH_SHORT).show()
        Thread {
            val link = Ext.spotifyLink(song.url)
            runOnUiThread {
                if (link != null) {
                    setExt(Ext.SPOTIFY, link, song.sec)
                    Toast.makeText(this, "Matched: " + song.title, Toast.LENGTH_SHORT).show()
                } else {
                    setExt(Ext.SPOTIFY, song.title + " " + song.artist, song.sec)
                }
            }
        }.start()
    }

    private fun setJio(v: String) = setExt(Ext.JIO, v, 0)

    private fun setExt(app: String, v: String, sec: Int) {
        extApp = app
        extUrl = v
        trackSec = sec
        uris.clear(); names.clear(); ytId = ""; ytUrl = ""
        renderSources()
        renderDur()
    }

    /** Looks up the song length from its link (best effort) and refreshes the warning text. */
    private fun fetchSec(kind: String, link: String) {
        Thread {
            val sec = Ext.fetchSec(kind, link)
            runOnUiThread {
                // screen already closed (never show a dialog on it)
                if (isFinishing || isDestroyed) return@runOnUiThread
                // the user picked another source meanwhile: this answer belongs to the old one
                val same = if (kind == "youtube") ytId.isNotBlank() && link.contains(ytId)
                else extApp == kind && extUrl == link
                if (!same) return@runOnUiThread
                if (sec > 0) {
                    trackSec = sec
                    renderDur()
                } else if (kind == Ext.INSTAGRAM && trackSec <= 0) {
                    askReelLength()
                }
            }
        }.start()
    }

    /** Instagram doesn't always share the reel length, so let the user type it (needed for Repeat / Stop checks). */
    private fun askReelLength(required: Boolean = false) {
        val et = EditText(this)
        et.hint = "e.g. 30  or  0:45"
        et.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et)
        MaterialAlertDialogBuilder(this)
            .setTitle("Reel length")
            .setMessage(
                if (required)
                    "Without a stop time the reel plays once, so WhenPlay needs its length to stop it. " +
                        "Enter it in seconds (or m:ss), or set a stop time instead."
                else
                    "Couldn't read the reel length automatically. Enter it in seconds (or m:ss) so the stop time can be checked."
            )
            .setView(box)
            .setPositiveButton("Set") { _, _ ->
                val t = et.text.toString().trim()
                val sec = if (t.contains(":")) {
                    val p = t.split(":")
                    (p[0].toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
                } else (t.toIntOrNull() ?: 0)
                if (sec > 0) {
                    trackSec = sec
                    renderDur()
                    if (required) Toast.makeText(this, "Length saved. Tap Save again.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(if (required) "Cancel" else "Skip", null)
            .show()
    }

    private fun audio() = getSystemService(AUDIO_SERVICE) as android.media.AudioManager

    private fun sysVolPercent(): Int {
        val am = audio()
        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
        return if (max <= 0) 70 else am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) * 100 / max
    }

    private fun setSysVolPercent(p: Int) {
        try {
            val am = audio()
            val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (max * p / 100).coerceIn(0, max), 0)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // phone volume buttons -> slider
    private val volReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context?, i: Intent?) {
            if (i?.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) != android.media.AudioManager.STREAM_MUSIC) return
            val p = sysVolPercent().coerceIn(10, 100)
            if (b.volSeek.progress != p) {
                b.volSeek.progress = p
                b.volText.text = "$p%"
            }
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            registerReceiver(volReceiver, android.content.IntentFilter("android.media.VOLUME_CHANGED_ACTION"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onStop() {
        try {
            unregisterReceiver(volReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onStop()
    }

    private var listenerAsked = false

    private fun renderTime() {
        val (t, ap) = Scheduler.fmt12(hour, minute)
        b.timeText.text = t
        b.ampmText.text = ap
        clashOk = false
        renderDur()
        renderSetLabel()
    }

    /** Save button reads like "Set 11:22 AM \u00B7 Once": the time plus the repeat days. */
    private fun renderSetLabel() {
        val (t, ap) = Scheduler.fmt12(hour, minute)
        var d = 0
        for (i in 0 until dayHost.childCount) {
            val c = dayHost.getChildAt(i)
            if (c.isSelected) d = d or (1 shl (c.tag as Int))
        }
        val rep = Scheduler.repeatText(d)
        b.repeatValue.text = rep
        b.btnSave.text = "Set $t $ap \u00B7 $rep"
    }

    private fun renderLoopValue() {
        b.loopValue.text = if (b.switchLoop.isChecked) "On" else "Off"
    }

    private fun noun() = if (uris.isNotEmpty()) "playlist" else if (extApp == Ext.INSTAGRAM) "reel" else "song"

    private fun mmss(sec: Int) = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')

    /** Instagram source: Repeat greyed out and off (the reel loops by itself until the stop time). */
    private fun applyIgLocks() {
        val ig = extApp == Ext.INSTAGRAM
        b.cellLoop.alpha = if (ig) 0.4f else 1f
        if (ig && b.switchLoop.isChecked) b.switchLoop.isChecked = false
    }

    /** Duration text for an Instagram reel. */
    private fun renderIgDur() {
        var warnIg = false
        val sb = StringBuilder()
        if (trackSec > 0) sb.append("Reel length ").append(mmss(trackSec)).append("\n")
        if (!stopEnabled) {
            sb.append(if (trackSec > 0) "Plays once. Choose a stop time later than the reel to repeat it." else "Set a stop time, or enter the reel length.")
        } else {
            val runSec = Scheduler.span(hour, minute, stopHour, stopMinute) * 60
            val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
            if (trackSec <= 0) {
                sb.append("Reel loops until ").append(st).append(" ").append(sap).append(".")
            } else if (runSec <= trackSec) {
                warnIg = true
                sb.append("Stop time is within the reel\u2019s ").append(mmss(trackSec)).append(" length. Choose a later stop time to repeat it.")
            } else {
                val full = runSec / trackSec
                val rest = runSec % trackSec
                sb.append("Reel loops: ").append(full).append(if (full == 1) " full play" else " full plays")
                if (rest > 15) sb.append(" + ").append(mmss(rest))
                sb.append(", then stops at ").append(st).append(" ").append(sap).append(".")
            }
        }
        b.durText.setTextColor(if (warnIg) 0xFFFFB74D.toInt() else ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8F93B8.toInt()))
        b.durText.text = sb.toString().trim()
    }

    private fun renderDur() {
        if (extApp == Ext.INSTAGRAM) {
            renderIgDur()
            return
        }
        val loopOn = b.switchLoop.isChecked
        val sb = StringBuilder()
        var warn = false
        if (trackSec > 0) sb.append(if (uris.isNotEmpty()) "Total length " else if (extApp == Ext.INSTAGRAM) "Reel length " else "Song length ").append(mmss(trackSec)).append("\n")
        if (stopEnabled) {
            val sp = Scheduler.span(hour, minute, stopHour, stopMinute)
            val runSec = sp * 60
            val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
            if (trackSec <= 0) {
                sb.append("Runs for ").append(Scheduler.fmtDur(sp))
            } else if (runSec <= trackSec + 30) {
                sb.append("Stops at ").append(st).append(" ").append(sap).append(", before it ends.")
            } else {
                val full = runSec / trackSec
                val rest = runSec % trackSec
                val plan = StringBuilder()
                plan.append(full).append(if (full == 1) " full play" else " full plays")
                if (rest > 15) plan.append(" + ").append(mmss(rest))
                if (loopOn) {
                    sb.append("Loop mode: ").append(plan).append(", then stops at ").append(st).append(" ").append(sap).append(".")
                } else {
                    warn = true
                    sb.append("Plays once (").append(mmss(trackSec)).append(") and stops.\n")
                    sb.append("⚠ Stop time is later than the " + noun() + ". Turn on Loop mode to play ").append(plan)
                        .append(" until ").append(st).append(" ").append(sap).append(".")
                }
            }
        } else if (trackSec > 0 && !loopOn) {
            sb.append("Plays once, then stops.")
        }
        b.durText.setTextColor(if (warn) 0xFFFFB74D.toInt() else ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8F93B8.toInt()))
        b.durText.text = sb.toString().trim()
    }

    /** Two schedules can't play together: ask to create this one after the other ends. */
    /** Two schedules can't play together: ask to create this one after the other ends. */
    /** Premium card explaining why Loop mode is not available for Instagram. */
    private fun showLoopLocked() {
        val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sb = com.tunex.app.databinding.SheetInfoBinding.inflate(layoutInflater)
        dlg.setContentView(sb.root)
        (sb.root.parent as? View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        sb.infoIcon.setImageResource(R.drawable.ic_src_instagram)
        sb.infoTitle.text = "Loop is unavailable for Instagram"
        sb.infoMsg.text = (if (trackSec > 0) "Reels can\u2019t use Loop mode. This reel is " + mmss(trackSec) + " long. " else "Reels can\u2019t use Loop mode. ") +
            "Choose a stop time later than the reel\u2019s length and it will repeat until then."
        sb.infoAction.text = "Choose stop time"
        sb.infoAction.setOnClickListener { dlg.dismiss(); b.stopRow.performClick() }
        sb.infoClose.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
    }

    private fun checkClash(s: Schedule): Boolean {
        if (clashOk) return true
        val cl = Scheduler.conflict(this, s) ?: return true
        val c = cl.other
        val (cs, cap) = Scheduler.fmt12(c.hour, c.minute)
        val q = "\u201C" + c.title() + "\u201D"
        val candLater = (hour * 60 + minute) > (c.hour * 60 + c.minute)
        val ce = Scheduler.endMinutes(this, c)
        val (es, eap) = Scheduler.fmt12(ce / 60, ce % 60)

        // The schedule that starts later takes over; the earlier one stops and does not resume.
        // "After" is only possible when both have a known end and this one starts later.
        val canAfter = candLater && !cl.otherOpen && !cl.candOpen
        val nm = c.title()
        val dm = Scheduler.durationMin(this, c)
        val (ms, mp) = Scheduler.fmt12(hour, minute)
        val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sb = com.tunex.app.databinding.SheetClashBinding.inflate(layoutInflater)
        dlg.setContentView(sb.root)
        (sb.root.parent as? View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        sb.clashTitle.text = nm
        sb.clashSub.text = if (candLater) "Your $ms $mp start falls inside this schedule."
            else "This schedule runs into it at $cs $cap."

        // Name never pushes the "Already scheduled" pill out of the row.
        sb.clashPill.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val dpx = resources.displayMetrics.density
        sb.clashTitle.maxWidth = (resources.displayMetrics.widthPixels - 40 * dpx - 10 * dpx - sb.clashPill.measuredWidth).toInt()

        // "9:30 \u2013 9:42 AM \u00B7 12 min": AM small and muted, duration in accent.
        val mutedC = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        val accC = ThemeStore.attrColor(this, R.attr.txAccent, 0xFF7C5CFF.toInt())
        val sbd = android.text.SpannableStringBuilder()
        fun small(t: String) {
            val st = sbd.length
            sbd.append(t)
            sbd.setSpan(android.text.style.RelativeSizeSpan(0.72f), st, sbd.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sbd.setSpan(android.text.style.ForegroundColorSpan(mutedC), st, sbd.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        when {
            cl.otherOpen -> sbd.append("Loop from $cs").also { small(" $cap") }
            dm != null -> {
                sbd.append(cs)
                if (cap != eap) small(" $cap")
                sbd.append(" \u2013 $es")
                small(" $eap")
            }
            else -> sbd.append("Starts $cs").also { small(" $cap") }
        }
        if (dm != null && !cl.otherOpen) {
            small("  \u00B7  ")
            val st = sbd.length
            sbd.append(Scheduler.fmtDur(dm))
            sbd.setSpan(android.text.style.ForegroundColorSpan(accC), st, sbd.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sbd.setSpan(android.text.style.RelativeSizeSpan(0.82f), st, sbd.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        sb.clashRange.text = sbd

        fun clock(h: Int, m: Int): CharSequence {
            val (t, ap) = Scheduler.fmt12(h, m)
            val sp = android.text.SpannableString("$t $ap")
            sp.setSpan(android.text.style.RelativeSizeSpan(0.42f), t.length, sp.length,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            return sp
        }

        sb.tileAfter.visibility = if (canAfter) View.VISIBLE else View.GONE
        sb.tileAfterCap.text = "After"
        sb.tileAfterTime.text = clock(ce / 60, ce % 60)
        val afterDesc = "$nm plays fully, then this one starts."

        sb.tileReplaceCap.text = if (candLater) "Replace" else "Save anyway"
        sb.tileReplaceTime.text = clock(hour, minute)
        val replaceDesc = if (candLater) "$nm stops at $ms $mp and won\u2019t resume."
            else "$nm takes over at $cs $cap. This one won\u2019t resume."
        if (!canAfter) (sb.tileReplace.layoutParams as android.widget.LinearLayout.LayoutParams).marginStart = 0

        val dp = resources.displayMetrics.density
        val card = ThemeStore.attrColor(this, R.attr.txCard, 0xFF222222.toInt())
        val ink = ThemeStore.attrColor(this, R.attr.txText, 0xFF111111.toInt())
        val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        val danger = ThemeStore.attrColor(this, R.attr.txDanger, 0xFFFF5C7A.toInt())
        val tintA = ThemeStore.attrColor(this, R.attr.txAccent, 0xFF7C5CFF.toInt())
        fun tileBg(tint: Int, selected: Boolean): android.graphics.drawable.GradientDrawable {
            val gd = android.graphics.drawable.GradientDrawable()
            gd.cornerRadius = 22 * dp
            gd.setColor(androidx.core.graphics.ColorUtils.compositeColors((tint and 0x00FFFFFF) or 0x38000000, card))
            if (selected) gd.setStroke((2 * dp).toInt(), ink)
            return gd
        }

        var afterSel = canAfter
        fun applySel() {
            sb.tileAfter.background = tileBg(tintA, afterSel)
            sb.tileReplace.background = tileBg(danger, !afterSel)
            sb.tileAfter.isSelected = afterSel
            sb.tileReplace.isSelected = !afterSel
            sb.clashDesc.text = if (afterSel) afterDesc else replaceDesc
            sb.clashDesc.setTextColor(if (afterSel) muted else danger)
            val (t, ap) = if (afterSel) Scheduler.fmt12(ce / 60, ce % 60) else Scheduler.fmt12(hour, minute)
            sb.clashSave.text = "Save at $t $ap"
        }
        applySel()
        sb.tileAfter.setOnClickListener { afterSel = true; applySel() }
        sb.tileReplace.setOnClickListener { afterSel = false; applySel() }

        sb.clashSave.setOnClickListener {
            dlg.dismiss()
            if (afterSel) {
                val keep = if (stopEnabled) Scheduler.span(hour, minute, stopHour, stopMinute) else 0
                hour = ce / 60
                minute = ce % 60
                if (stopEnabled) {
                    val e2 = (ce + keep) % 1440
                    stopHour = e2 / 60
                    stopMinute = e2 % 60
                }
                renderTime()
                renderStop()
                clashOk = false
            } else {
                clashOk = true
            }
            b.btnSave.performClick()
        }
        sb.clashCancel.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
        return false
    }

    private fun renderStop() {
        val (t, ap) = Scheduler.fmt12(stopHour, stopMinute)
        b.stopTime.text = if (stopEnabled) "$t $ap" else "Set"
        renderDur()
    }

    /** Name box: shown only while a source is set; a different source clears the old name. */
    private fun syncName() {
        val key = when {
            ytId.isNotBlank() -> "yt:$ytId"
            extApp.isNotBlank() -> "ext:$extApp:$extUrl"
            uris.isNotEmpty() -> "files"
            else -> ""
        }
        if (srcKey != key) {
            val had = b.nameInput.text.toString().trim()
            if (!srcKey.isNullOrEmpty()) b.nameInput.setText("")
            clearedNote = !srcKey.isNullOrEmpty() && had.isNotEmpty()
            srcKey = key
            autoTitle = ""
            val kind = when {
                key.startsWith("yt:") -> "youtube"
                extApp == Ext.SPOTIFY -> Ext.SPOTIFY
                else -> ""
            }
            if (kind.isNotEmpty()) {
                val link = if (kind == "youtube") "https://www.youtube.com/watch?v=" + ytId else extUrl
                Thread {
                    val t = Ext.fetchTitle(kind, link)
                    runOnUiThread {
                        if (isFinishing || isDestroyed || srcKey != key) return@runOnUiThread
                        autoTitle = t
                        syncName()
                        renderSummary()
                    }
                }.start()
            }
        }
        val igNote = extApp == Ext.INSTAGRAM
        b.nameNote.visibility = if (clearedNote || igNote) View.VISIBLE else View.GONE
        b.nameNote.text = if (clearedNote) "Name cleared for the new source" else "Instagram doesn\u2019t share reel titles, so add your own name if you like."
        b.nameNote.setTextColor(
            if (clearedNote) ThemeStore.attrColor(this, R.attr.txAccent, 0xFF7C5CFF.toInt())
            else ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        )
        b.nameInput.hint = "Name (optional)"
    }

    private fun actualSrc(): String? = when {
        uris.isNotEmpty() -> "phone"
        ytId.isNotBlank() -> "yt"
        extApp.isNotBlank() -> extApp
        else -> null
    }

    private fun openSource(kind: String) {
        when (kind) {
            "phone" -> chooseFiles()
            "yt" -> askYoutube()
            Ext.SPOTIFY -> askSpotify()
            Ext.JIO -> askJio()
            Ext.INSTAGRAM -> askInstagram()
        }
    }

    /** Paste button: takes the link from the clipboard for the source picked in the header. */
    private fun quickPaste() {
        val kind = pendingSrc ?: return
        if (kind == "phone") {
            chooseFiles()
            return
        }
        val clip = try {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString() ?: ""
        } catch (e: Exception) {
            ""
        }
        if (clip.isBlank()) {
            Toast.makeText(this, "Clipboard is empty. Copy a link first.", Toast.LENGTH_SHORT).show()
            return
        }
        val txt = if (Ext.isLink(clip)) Ext.cleanLink(clip) else clip.trim()
        val ok = if (kind == "yt") Yt.parseId(txt) != null else Ext.valid(kind, txt)
        if (!ok) {
            Toast.makeText(this, "That link isn\u2019t from this app. Copy the right link and paste again.", Toast.LENGTH_LONG).show()
            return
        }
        applyLink(kind, txt)
    }

    /** Same steps the link sheet runs after "Use this link". */
    private fun applyLink(kind: String, txt: String) {
        when (kind) {
            "yt" -> {
                ytId = Yt.parseId(txt) ?: ""
                ytUrl = txt
                uris.clear(); names.clear(); extApp = ""; extUrl = ""
                trackSec = 0
                renderSources()
                fetchSec("youtube", "https://www.youtube.com/watch?v=" + ytId)
            }
            Ext.SPOTIFY -> { setExt(Ext.SPOTIFY, txt, 0); fetchSec(Ext.SPOTIFY, txt) }
            Ext.JIO -> { setJio(txt); fetchSec(Ext.JIO, txt) }
            Ext.INSTAGRAM -> { setExt(Ext.INSTAGRAM, txt, 0); fetchSec(Ext.INSTAGRAM, txt) }
        }
    }

    private fun fill(color: Int, radiusDp: Int): android.graphics.drawable.GradientDrawable {
        val gd = android.graphics.drawable.GradientDrawable()
        gd.cornerRadius = radiusDp * resources.displayMetrics.density
        gd.setColor(color)
        return gd
    }

    private fun glass(radiusDp: Int, strong: Boolean = false) =
        ScheduleAdapter.glass(this, radiusDp * resources.displayMetrics.density, strong)

    private fun withAlpha(c: Int, alpha: Int) = androidx.core.graphics.ColorUtils.setAlphaComponent(c, alpha)

    /** Header colour follows the picked app: the panel (Curve) or the glow behind it (Pills). */
    private fun srcColor(key: String?): Int = when (key) {
        "yt" -> 0xFFE0312F.toInt()
        Ext.INSTAGRAM -> 0xFFD62976.toInt()
        Ext.SPOTIFY -> 0xFF1AA34A.toInt()
        Ext.JIO -> 0xFF14A89A.toInt()
        else -> ThemeStore.attrColor(this, R.attr.txAccent, 0xFF7C5CFF.toInt())
    }

    private var headerColor = 0
    private var headerAnim: android.animation.ValueAnimator? = null

    private fun paintHeader(c: Int) {
        headerColor = c
        val glow = android.graphics.drawable.GradientDrawable()
        glow.gradientType = android.graphics.drawable.GradientDrawable.RADIAL_GRADIENT
        glow.gradientRadius = 380f * resources.displayMetrics.density
        glow.setGradientCenter(0.85f, 0.9f)
        glow.setColors(intArrayOf(withAlpha(c, 0x4D), withAlpha(c, 0x00)))
        b.formBox.background = glow
        if (pills) {
            b.headerBox.background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(withAlpha(c, 0x80), withAlpha(c, 0x00))
            )
        } else {
            val r = 30 * resources.displayMetrics.density
            val hd = android.graphics.drawable.GradientDrawable()
            hd.setColor(c)
            hd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            b.headerBox.background = hd
        }
    }

    private fun setHeader(target: Int) {
        if (target == headerColor) return
        headerAnim?.cancel()
        val an = android.animation.ValueAnimator.ofObject(android.animation.ArgbEvaluator(), headerColor, target)
        an.duration = 300
        an.addUpdateListener { paintHeader(it.animatedValue as Int) }
        headerAnim = an
        an.start()
    }

    private fun reveal(v: View, show: Boolean) {
        if (!show) {
            v.visibility = View.GONE
            return
        }
        if (v.visibility != View.VISIBLE) {
            v.alpha = 0f
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(220).start()
        }
    }

    /** Curve (curved header + 2x2 tiles) or Pills (soft rows) look for this screen. Same behaviour in both. */
    private fun applyStyleEdit() {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val ink = ThemeStore.attrColor(this, R.attr.txText, 0xFFFFFFFF.toInt())
        val inkOn = ThemeStore.attrColor(this, R.attr.txBg, 0xFF000000.toInt())
        val card = ThemeStore.attrColor(this, R.attr.txCard, 0xFF222222.toInt())
        val chip = ThemeStore.attrColor(this, R.attr.txChip, 0xFF2A2D44.toInt())
        val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())

        // header
        paintHeader(srcColor(null))
        b.screenTitle.setTextColor(if (pills) muted else withAlpha(0xFFFFFFFF.toInt(), 0xCC))

        // link + name fields
        val fr = if (pills) 27 else 13
        b.linkRow.background = glass(fr)
        b.nameRow.background = glass(fr)
        b.btnPaste.background = glass(if (pills) 18 else 10, true)
        b.nameIcon.imageTintList = android.content.res.ColorStateList.valueOf(muted)
        b.daysCard.background = glass(if (pills) 24 else 14)
        b.volRow.background = if (pills) glass(28) else null

        // Start / Repeat / Loop / Stop at: rows (Pills) or 2x2 tiles (Curve)
        val cells = listOf(b.timeCard, b.cellRepeat, b.cellLoop, b.stopRow)
        val caps = listOf("Start", "Repeat", "Loop", "Stop at")
        val orient = if (pills) android.widget.LinearLayout.VERTICAL else android.widget.LinearLayout.HORIZONTAL
        b.cellRowA.orientation = orient
        b.cellRowB.orientation = orient
        cells.forEachIndexed { i, c ->
            val icon = c.getChildAt(0)
            val label = c.getChildAt(1) as android.widget.TextView
            c.background = glass(if (pills) 28 else 13)
            if (pills) {
                c.orientation = android.widget.LinearLayout.HORIZONTAL
                c.gravity = android.view.Gravity.CENTER_VERTICAL
                c.setPadding(px(12), px(12), px(20), px(12))
                val lp = android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = px(8)
                c.layoutParams = lp
                icon.visibility = View.VISIBLE
                icon.background = ScheduleAdapter.circle(chip)
                val llp = android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                llp.marginStart = px(12)
                label.layoutParams = llp
                label.text = caps[i]
                label.textSize = 14f
                label.letterSpacing = 0f
            } else {
                c.orientation = android.widget.LinearLayout.VERTICAL
                c.gravity = android.view.Gravity.START
                c.setPadding(px(16), px(14), px(16), px(14))
                c.minimumHeight = px(72)
                val lp = android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(px(4), px(4), px(4), px(4))
                c.layoutParams = lp
                icon.visibility = View.GONE
                val llp = android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
                llp.bottomMargin = px(6)
                label.layoutParams = llp
                label.text = caps[i].uppercase()
                label.textSize = 10f
                label.letterSpacing = 0.14f
            }
        }
        val vSize = if (pills) 15f else 18f
        listOf(b.repeatValue, b.loopValue, b.stopTime, b.timeText, b.ampmText).forEach { it.textSize = vSize }

        // Save button: ink pill
        b.btnSave.backgroundTintList = android.content.res.ColorStateList.valueOf(ink)
        b.btnSave.setTextColor(inkOn)
    }

    /** Source avatars: nothing is picked at first; the picked one gets a white ring. */
    private fun styleAvatars() {
        val dp = resources.displayMetrics.density
        val ink = ThemeStore.attrColor(this, R.attr.txText, 0xFFFFFFFF.toInt())
        val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        val ring = if (pills) ink else 0xFFFFFFFF.toInt()
        val phoneDim = if (pills) srcColor("phone") else withAlpha(0xFFFFFFFF.toInt(), 0x38)
        val items = listOf(
            Triple(b.avPhone, "phone", phoneDim),
            Triple(b.avYt, "yt", 0xFF7A2038.toInt()),
            Triple(b.avIg, Ext.INSTAGRAM, 0xFFB03A6B.toInt()),
            Triple(b.avSp, Ext.SPOTIFY, 0xFF1E6B45.toInt()),
            Triple(b.avJio, Ext.JIO, 0xFF1F5F7A.toInt())
        )
        val tiles = listOf(b.tilePhone, b.tileYt, b.tileIg, b.tileSp, b.tileJio)
        items.forEachIndexed { i, (v, key, dim) ->
            val picked = pendingSrc == key
            val fillC = if (picked && !pills) withAlpha(0xFFFFFFFF.toInt(), 0x3A) else if (picked) srcColor(key) else dim
            val gd = ScheduleAdapter.circle(fillC)
            if (picked) gd.setStroke((3 * dp).toInt(), ring)
            v.background = gd
            v.setTextColor(0xFFFFFFFF.toInt())
            val lbl = tiles[i].getChildAt(1) as android.widget.TextView
            lbl.setTextColor(
                if (pills) (if (picked) ink else muted)
                else withAlpha(0xFFFFFFFF.toInt(), if (picked) 0xFF else 0x99)
            )
        }
    }

    private fun renderHeader() {
        val nm = when (pendingSrc) {
            "phone" -> "PHONE"
            "yt" -> "YOUTUBE"
            Ext.INSTAGRAM -> "INSTAGRAM"
            Ext.SPOTIFY -> "SPOTIFY"
            Ext.JIO -> "JIOSAAVN"
            else -> ""
        }
        b.screenTitle.text = if (pills) {
            if (editId > 0) "EDIT SCHEDULE" else "NEW SCHEDULE"
        } else if (nm.isEmpty()) {
            "CHOOSE A SOURCE"
        } else {
            nm + (if (editId > 0) " \u00B7 EDITING" else " \u00B7 NOW SCHEDULING")
        }
        setHeader(srcColor(pendingSrc))
    }

    /** The link row shows the current link (or title) of the picked source, otherwise a hint. */
    private fun renderLink() {
        val picked = pendingSrc != null
        reveal(b.linkRow, picked)
        reveal(b.nameCard, picked)
        val actual = actualSrc()
        val cur = actual != null && actual == pendingSrc
        val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        val ink = ThemeStore.attrColor(this, R.attr.txText, 0xFFFFFFFF.toInt())
        b.btnPaste.text = if (pendingSrc == "phone") "Browse" else "Paste"
        if (cur) {
            b.linkText.text = when (actual) {
                "phone" -> if (names.size == 1) names[0] else names.size.toString() + " files"
                "yt" -> if (autoTitle.isNotBlank()) autoTitle else ytUrl
                Ext.SPOTIFY -> if (autoTitle.isNotBlank()) autoTitle else extUrl
                else -> extUrl
            }
            b.linkText.setTextColor(ink)
        } else {
            b.linkText.text = if (pendingSrc == "phone") "Choose files" else "Paste link"
            b.linkText.setTextColor(muted)
        }
    }

    private fun renderSummary() {
        val has = actualSrc() != null
        styleAvatars()
        renderLink()
        renderHeader()
        b.btnSave.isEnabled = has
        b.btnSave.alpha = if (has) 1f else 0.5f
    }

    private fun renderSources() {
        actualSrc()?.let { pendingSrc = it }
        syncName()
        renderSummary()
        if (uris.isNotEmpty()) {
            refreshLocalSec()
        } else if (ytId.isBlank() && extApp.isBlank()) {
            trackSec = 0
            renderDur()
        }
        applyIgLocks()
    }

    /** Reads the real length of the chosen phone files so Stop time / Repeat can be checked. */
    private fun refreshLocalSec() {
        val snap = uris.toList()
        Thread {
            val sec = Scheduler.localSec(this, snap)
            runOnUiThread {
                if (uris.isNotEmpty() && uris.toList() == snap) {
                    trackSec = sec
                    renderDur()
                }
            }
        }.start()
    }

    private fun collect(): Schedule? {
        if (uris.isEmpty() && ytId.isBlank() && extApp.isBlank()) {
            Toast.makeText(this, "Add music, a YouTube, Spotify, JioSaavn or Instagram link", Toast.LENGTH_SHORT).show()
            return null
        }
        var days = 0
        for (i in 0 until dayHost.childCount) {
            val c = dayHost.getChildAt(i)
            if (c.isSelected) days = days or (1 shl (c.tag as Int))
        }
        label = b.nameInput.text.toString().trim()
        val id = if (editId > 0) editId else Store.nextId(this)
        return Schedule(
            id = id,
            hour = hour,
            minute = minute,
            days = days,
            label = label,
            uris = uris.toList(),
            names = names.toList(),
            enabled = true,
            volume = b.volSeek.progress.coerceAtLeast(10),
            onceAt = 0L,
            ytId = ytId,
            ytUrl = ytUrl,
            loop = b.switchLoop.isChecked,
            stopEnabled = stopEnabled,
            stopHour = stopHour,
            stopMinute = stopMinute,
            extApp = extApp,
            extUrl = extUrl,
            trackSec = trackSec
        )
    }

    private fun persist(s: Schedule) {
        editId = s.id
        Store.upsert(this, s)
        Scheduler.cancel(this, s.id)
        Scheduler.arm(this, s)
    }
}
