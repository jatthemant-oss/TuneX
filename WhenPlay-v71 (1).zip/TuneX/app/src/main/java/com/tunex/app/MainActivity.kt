package com.tunex.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tunex.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private var ticks = 0
    private var userSeeking = false

    private val adapter = ScheduleAdapter(
        onToggle = { s, on -> onToggle(s, on) },
        onEdit = { s ->
            startActivity(Intent(this, EditActivity::class.java).putExtra("id", s.id))
        },
        onDelete = { s -> onDelete(s) }
    )

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            showBatteryPrompt()
        }

    private val tick = object : Runnable {
        override fun run() {
            refreshNow()
            ticks++
            if (ticks % 60 == 0) refreshList()
            handler.postDelayed(this, 500)
        }
    }

    private fun applyLayout() {
        val dp = resources.displayMetrics.density
        val pills = LayoutStore.isPills(this)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.setPadding(0, (4 * dp).toInt(), 0, (12 * dp).toInt())
        adapter.style = if (pills) 1 else 0

        val acc = ThemeStore.attrColor(this, R.attr.txAccent, 0xFF7C5CFF.toInt())
        val on = ThemeStore.attrColor(this, R.attr.txOnAccent, 0xFFFFFFFF.toInt())
        val ink = ThemeStore.attrColor(this, R.attr.txText, 0xFFFFFFFF.toInt())
        val inkOn = ThemeStore.attrColor(this, R.attr.txBg, 0xFF000000.toInt())
        val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        fun a(c: Int, alpha: Int) = androidx.core.graphics.ColorUtils.setAlphaComponent(c, alpha)

        if (pills) {
            b.headerBox.background = null
            b.hdrTitle.setTextColor(ink)
            b.hdrSub.setTextColor(muted)
            b.btnMenu.setBackgroundResource(R.drawable.input_bg)
            b.btnMenu.imageTintList = null
            b.nextCard.visibility = View.GONE
        } else {
            val r = 34 * dp
            val hd = android.graphics.drawable.GradientDrawable()
            hd.setColor(acc)
            hd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            b.headerBox.background = hd
            b.hdrTitle.setTextColor(on)
            b.hdrSub.setTextColor(a(on, 0xB3))
            val mb = android.graphics.drawable.GradientDrawable()
            mb.shape = android.graphics.drawable.GradientDrawable.OVAL
            mb.setColor(a(on, 0x2E))
            mb.setStroke(dp.toInt().coerceAtLeast(1), a(on, 0x45))
            b.btnMenu.background = mb
            b.btnMenu.imageTintList = android.content.res.ColorStateList.valueOf(on)
            val nb = android.graphics.drawable.GradientDrawable()
            nb.cornerRadius = 22 * dp
            nb.setColor(a(on, 0x2E))
            nb.setStroke(dp.toInt().coerceAtLeast(1), a(on, 0x45))
            b.nextCard.background = nb
            b.nextCap.setTextColor(a(on, 0xB3))
            b.nextTime.setTextColor(on)
            b.nextAmpm.setTextColor(on)
            b.nextTag.setTextColor(a(on, 0xCC))
            b.nextAvatar.setTextColor(on)
            b.nextAvatar.background = ScheduleAdapter.squircle(a(on, 0x38), 13 * dp)
        }

        // "New schedule" button: ink pill in both styles
        val pillBg = 0xFFF1EEFF.toInt()
        val pillFg = 0xFF14141F.toInt()
        b.fab.backgroundTintList = android.content.res.ColorStateList.valueOf(pillBg)
        b.fab.setTextColor(pillFg)
        b.fab.iconTint = android.content.res.ColorStateList.valueOf(pillFg)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ThemeStore.styleBars(this)

        b.list.adapter = adapter
        applyLayout()

        b.fab.setOnClickListener {
            startActivity(Intent(this, EditActivity::class.java))
        }
        b.btnStop.setOnClickListener {
            startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_STOP))
        }
        b.btnPlay.setOnClickListener { PlayerService.instance?.togglePause() }
        b.btnPrev.setOnClickListener { PlayerService.instance?.prev() }
        b.btnNext.setOnClickListener { PlayerService.instance?.next() }
        b.btnBack.setOnClickListener { PlayerService.instance?.seekBy(-10000) }
        b.btnFwd.setOnClickListener { PlayerService.instance?.seekBy(10000) }
        b.nowSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) b.nowPos.text = fmtMs(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                PlayerService.instance?.seekTo(sb?.progress ?: 0)
                userSeeking = false
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            showBatteryPrompt()
        }

        // Make sure every enabled schedule is armed
        Scheduler.rescheduleAll(this)
    }

    private fun showBatteryPrompt() {
        val prefs = getSharedPreferences("tunex_ui", MODE_PRIVATE)
        if (prefs.getBoolean("asked", false)) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked", true).apply()
        MaterialAlertDialogBuilder(this)
            .setTitle("Make playback rock-solid")
            .setMessage("One time only: tap Allow on the next screen so Android never limits WhenPlay in the background.")
            .setPositiveButton("Continue") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            .setNegativeButton("Skip", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun refreshList() {
        val all = Store.all(this).sortedWith(compareBy({ it.hour }, { it.minute }))
        val pills = LayoutStore.isPills(this)
        val active = all.count { it.enabled }
        b.hdrSub.text = if (all.isEmpty()) "Schedule your music" else
            all.size.toString() + (if (all.size == 1) " schedule" else " schedules") + " \u00B7 " + active + " active"
        val next = all.filter { it.enabled }.minByOrNull { Scheduler.nextTrigger(it) }
        if (!pills && next != null) {
            val sr = ScheduleAdapter.src(this, next)
            val (t, ap) = Scheduler.fmt12(next.hour, next.minute)
            b.nextAvatar.text = sr.ini
            b.nextTime.text = t
            b.nextAmpm.text = ap
            b.nextTag.text = next.customName().ifEmpty { sr.label.lowercase() }
            b.nextCard.visibility = View.VISIBLE
            b.nextCard.setOnClickListener {
                startActivity(Intent(this, EditActivity::class.java).putExtra("id", next.id))
            }
            b.nextCard.setOnLongClickListener { onDelete(next); true }
            adapter.submit(all.filter { it.id != next.id })
        } else {
            b.nextCard.visibility = View.GONE
            adapter.submit(all)
        }
        b.empty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun fmtMs(ms: Int): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }

    private fun refreshNow() {
        val svc = PlayerService.instance
        if (PlayerService.isPlaying && svc != null) {
            b.nowCard.visibility = View.VISIBLE
            b.nowLabel.text = PlayerService.nowTitle
            b.nowTrack.text = PlayerService.nowTrack.ifBlank { "Starting…" }
            val d = svc.duration()
            val p = svc.position()
            if (!userSeeking) {
                b.nowSeek.max = if (d > 0) d else 1
                b.nowSeek.progress = p
                b.nowPos.text = fmtMs(p)
            }
            b.nowDur.text = fmtMs(d)
            b.btnPlay.setImageResource(if (svc.isPaused()) R.drawable.ic_play_dark else R.drawable.ic_pause_dark)
        } else {
            b.nowCard.visibility = View.GONE
        }
    }

    private fun onToggle(s: Schedule, on: Boolean) {
        s.enabled = on
        if (on) {
            s.onceAt = 0L
            Scheduler.arm(this, s)
            Toast.makeText(
                this,
                "Starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Scheduler.cancel(this, s.id)
        }
        Store.upsert(this, s)
        handler.post { refreshList() }
    }

    private fun onDelete(s: Schedule) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete schedule?")
            .setMessage(s.title())
            .setPositiveButton("Delete") { _, _ ->
                Scheduler.cancel(this, s.id)
                Store.delete(this, s.id)
                refreshList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
