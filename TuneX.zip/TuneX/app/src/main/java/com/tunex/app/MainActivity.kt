package com.tunex.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tunex.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private var ticks = 0

    private val adapter = ScheduleAdapter(
        onToggle = { s, on -> onToggle(s, on) },
        onEdit = { s ->
            startActivity(Intent(this, EditActivity::class.java).putExtra("id", s.id))
        },
        onDelete = { s -> onDelete(s) }
    )

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            showBatteryPrompt()
        }

    private val tick = object : Runnable {
        override fun run() {
            refreshNow()
            ticks++
            if (ticks % 30 == 0) refreshList()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter

        b.fab.setOnClickListener {
            startActivity(Intent(this, EditActivity::class.java))
        }
        b.btnStop.setOnClickListener {
            startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_STOP))
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            showBatteryPrompt()
        }

        // Make sure every enabled schedule is armed
        Scheduler.rescheduleAll(this)
    }

    private fun showBatteryPrompt() {
        val prefs = getSharedPreferences("tunex_ui", MODE_PRIVATE)
        if (prefs.getBoolean("asked", false)) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked", true).apply()
        MaterialAlertDialogBuilder(this)
            .setTitle("Make playback rock-solid")
            .setMessage("One time only: tap Allow on the next screen so Android never limits TuneX in the background.")
            .setPositiveButton("Continue") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            .setNegativeButton("Skip", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun refreshList() {
        val l = Store.all(this).sortedWith(compareBy({ it.hour }, { it.minute }))
        adapter.submit(l)
        b.empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun refreshNow() {
        if (PlayerService.isPlaying) {
            b.nowCard.visibility = View.VISIBLE
            b.nowLabel.text = PlayerService.nowTitle
            b.nowTrack.text = PlayerService.nowTrack.ifBlank { "Starting…" }
        } else {
            b.nowCard.visibility = View.GONE
        }
    }

    private fun onToggle(s: Schedule, on: Boolean) {
        s.enabled = on
        if (on) {
            s.onceAt = 0L
            Scheduler.arm(this, s)
            Toast.makeText(
                this,
                "Starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Scheduler.cancel(this, s.id)
        }
        Store.upsert(this, s)
        handler.post { refreshList() }
    }

    private fun onDelete(s: Schedule) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete schedule?")
            .setMessage(s.label)
            .setPositiveButton("Delete") { _, _ ->
                Scheduler.cancel(this, s.id)
                Store.delete(this, s.id)
                refreshList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
