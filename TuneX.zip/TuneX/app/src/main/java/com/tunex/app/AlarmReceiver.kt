package com.tunex.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val s = Store.get(ctx, id) ?: return
        if (!s.enabled) return

        // Re-arm first so the next occurrence is never lost
        if (s.days == 0) {
            s.enabled = false
            Store.upsert(ctx, s)
        } else {
            Scheduler.arm(ctx, s)
        }

        val svc = Intent(ctx, PlayerService::class.java).putExtra("id", id)
        try {
            ContextCompat.startForegroundService(ctx, svc)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
