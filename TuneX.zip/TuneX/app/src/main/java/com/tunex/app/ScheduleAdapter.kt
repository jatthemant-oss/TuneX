package com.tunex.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tunex.app.databinding.ItemScheduleBinding

class ScheduleAdapter(
    private val onToggle: (Schedule, Boolean) -> Unit,
    private val onEdit: (Schedule) -> Unit,
    private val onDelete: (Schedule) -> Unit
) : RecyclerView.Adapter<ScheduleAdapter.VH>() {

    private var items: List<Schedule> = emptyList()

    fun submit(l: List<Schedule>) {
        items = l
        notifyDataSetChanged()
    }

    class VH(val b: ItemScheduleBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemScheduleBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val s = items[position]
        val (t, ap) = Scheduler.fmt12(s.hour, s.minute)
        h.b.time.text = t
        h.b.ampm.text = ap
        h.b.label.text = s.label
        val n = s.uris.size
        h.b.info.text = Scheduler.dayLabel(s.days) + "  •  " + n + (if (n == 1) " track" else " tracks")
        h.b.next.text = if (s.enabled)
            "Starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis())
        else "Off"
        h.b.toggle.setOnCheckedChangeListener(null)
        h.b.toggle.isChecked = s.enabled
        h.b.toggle.setOnCheckedChangeListener { _, c -> onToggle(s, c) }
        h.b.root.setOnClickListener { onEdit(s) }
        h.b.delete.setOnClickListener { onDelete(s) }
    }
}
