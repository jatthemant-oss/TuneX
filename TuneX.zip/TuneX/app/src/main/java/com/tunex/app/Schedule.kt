package com.tunex.app

import org.json.JSONArray
import org.json.JSONObject

/** days: bitmask, bit0 = Sunday ... bit6 = Saturday. 0 = play once. */
data class Schedule(
    val id: Int,
    var hour: Int,
    var minute: Int,
    var days: Int,
    var label: String,
    var uris: List<String>,
    var names: List<String>,
    var enabled: Boolean,
    var volume: Int,
    var onceAt: Long = 0L
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("hour", hour)
        put("minute", minute)
        put("days", days)
        put("label", label)
        put("uris", JSONArray(uris))
        put("names", JSONArray(names))
        put("enabled", enabled)
        put("volume", volume)
        put("onceAt", onceAt)
    }

    companion object {
        fun fromJson(o: JSONObject): Schedule {
            val u = o.getJSONArray("uris")
            val n = o.getJSONArray("names")
            return Schedule(
                id = o.getInt("id"),
                hour = o.getInt("hour"),
                minute = o.getInt("minute"),
                days = o.getInt("days"),
                label = o.getString("label"),
                uris = List(u.length()) { u.getString(it) },
                names = List(n.length()) { n.getString(it) },
                enabled = o.getBoolean("enabled"),
                volume = o.optInt("volume", 70),
                onceAt = o.optLong("onceAt", 0L)
            )
        }
    }
}
