package com.tunex.app

import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.chip.Chip
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.tunex.app.databinding.ActivityEditBinding
import java.util.Calendar

class EditActivity : AppCompatActivity() {

    private lateinit var b: ActivityEditBinding
    private var hour = 6
    private var minute = 0
    private var editId = -1
    private val uris = mutableListOf<String>()
    private val names = mutableListOf<String>()
    private val dayOrder = intArrayOf(1, 2, 3, 4, 5, 6, 0)
    private val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
            for (u in list) {
                try {
                    contentResolver.takePersistableUriPermission(
                        u, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                val s = u.toString()
                if (s !in uris) {
                    uris.add(s)
                    names.add(displayName(u))
                }
            }
            renderSongs()
        }

    private fun displayName(u: android.net.Uri): String {
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "Track"
        } catch (e: Exception) {
            "Track"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityEditBinding.inflate(layoutInflater)
        setContentView(b.root)

        val cal = Calendar.getInstance()
        hour = cal.get(Calendar.HOUR_OF_DAY)
        minute = cal.get(Calendar.MINUTE)
        var days = 0
        var vol = 70

        editId = intent.getIntExtra("id", -1)
        val existing = Store.get(this, editId)
        if (existing != null) {
            hour = existing.hour
            minute = existing.minute
            days = existing.days
            vol = existing.volume
            b.labelInput.setText(existing.label)
            uris.addAll(existing.uris)
            names.addAll(existing.names)
            b.screenTitle.text = "Edit schedule"
        }

        for (i in dayOrder) {
            val chip = layoutInflater.inflate(R.layout.chip_day, b.chipDays, false) as Chip
            chip.text = dayNames[i]
            chip.tag = i
            chip.isChecked = ((days shr i) and 1) == 1
            b.chipDays.addView(chip)
        }

        b.volSeek.progress = vol
        b.volText.text = "Volume $vol%"
        b.volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                b.volText.text = "Volume $p%"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        b.timeCard.setOnClickListener {
            val p = MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(hour)
                .setMinute(minute)
                .setTitleText("Start time")
                .build()
            p.addOnPositiveButtonClickListener {
                hour = p.hour
                minute = p.minute
                renderTime()
            }
            p.show(supportFragmentManager, "time")
        }

        b.btnAddSongs.setOnClickListener { picker.launch(arrayOf("audio/*")) }
        b.btnClearSongs.setOnClickListener {
            uris.clear()
            names.clear()
            renderSongs()
        }

        b.btnSave.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            persist(s)
            Toast.makeText(
                this,
                "Scheduled • starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_LONG
            ).show()
            finish()
        }

        b.btnPlayNow.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            persist(s)
            ContextCompat.startForegroundService(
                this, Intent(this, PlayerService::class.java).putExtra("id", s.id)
            )
            Toast.makeText(this, "Playing now (test)", Toast.LENGTH_SHORT).show()
        }

        renderTime()
        renderSongs()
    }

    private fun renderTime() {
        val (t, ap) = Scheduler.fmt12(hour, minute)
        b.timeText.text = t
        b.ampmText.text = ap
    }

    private fun renderSongs() {
        if (names.isEmpty()) {
            b.songsList.text = "No tracks selected yet"
            b.btnClearSongs.visibility = View.GONE
        } else {
            b.songsList.text = names.mapIndexed { i, n -> "${i + 1}. $n" }.joinToString("\n")
            b.btnClearSongs.visibility = View.VISIBLE
        }
    }

    private fun collect(): Schedule? {
        if (uris.isEmpty()) {
            Toast.makeText(this, "Please add at least one track", Toast.LENGTH_SHORT).show()
            return null
        }
        var days = 0
        for (i in 0 until b.chipDays.childCount) {
            val c = b.chipDays.getChildAt(i) as Chip
            if (c.isChecked) days = days or (1 shl (c.tag as Int))
        }
        val id = if (editId > 0) editId else Store.nextId(this)
        val label = b.labelInput.text.toString().trim().ifBlank { "My schedule" }
        return Schedule(
            id, hour, minute, days, label,
            uris.toList(), names.toList(), true,
            b.volSeek.progress.coerceAtLeast(10), 0L
        )
    }

    private fun persist(s: Schedule) {
        editId = s.id
        Store.upsert(this, s)
        Scheduler.cancel(this, s.id)
        Scheduler.arm(this, s)
    }
}
