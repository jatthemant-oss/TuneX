package com.tunex.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class PlayerService : Service() {

    companion object {
        const val ACTION_STOP = "com.tunex.app.STOP"
        const val ACTION_TOGGLE = "com.tunex.app.TOGGLE"
        const val CHANNEL = "tunex_play"
        @Volatile var isPlaying = false
        @Volatile var nowTitle = ""
        @Volatile var nowTrack = ""
    }

    private var mp: MediaPlayer? = null
    private var uris: List<String> = emptyList()
    private var names: List<String> = emptyList()
    private var index = 0
    private var label = "TuneX"
    private var wl: PowerManager.WakeLock? = null
    private var afr: AudioFocusRequest? = null
    private var pausedByFocus = false
    private var userPaused = false
    private val main = Handler(Looper.getMainLooper())

    private val attrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        try {
            when (change) {
                AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                    val p = mp
                    if (p != null && p.isPlaying) {
                        p.pause()
                        pausedByFocus = true
                    }
                }
                AudioManager.AUDIOFOCUS_GAIN -> {
                    if (pausedByFocus) {
                        mp?.start()
                        pausedByFocus = false
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAll()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_TOGGLE) {
            togglePause()
            return START_NOT_STICKY
        }
        createChannel()
        userPaused = false
        val s = Store.get(this, intent?.getIntExtra("id", -1) ?: -1)
        label = s?.label ?: "TuneX"
        nowTrack = ""
        ServiceCompat.startForeground(this, 1, buildNotif(), fgType())

        if (s == null || s.uris.isEmpty()) {
            stopAll()
            return START_NOT_STICKY
        }
        uris = s.uris
        names = s.names
        index = 0
        acquireLock()
        setVolume(s.volume)
        requestFocus()
        isPlaying = true
        nowTitle = label
        playCurrent()
        return START_NOT_STICKY
    }

    private fun togglePause() {
        try {
            val p = mp ?: return
            if (userPaused) {
                p.start()
                userPaused = false
            } else if (p.isPlaying) {
                p.pause()
                userPaused = true
            }
            updateNotif()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun fgType(): Int =
        if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0

    private fun acquireLock() {
        try {
            wl?.let { if (it.isHeld) it.release() }
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TuneX:play").apply {
                setReferenceCounted(false)
                acquire(24L * 60L * 60L * 1000L)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setVolume(percent: Int) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val v = (max * percent / 100).coerceIn(1, max)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun requestFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            afr = r
            am.requestAudioFocus(r)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun playCurrent() {
        releasePlayer()
        if (index >= uris.size) {
            stopAll()
            return
        }
        nowTrack = names.getOrElse(index) { "Track ${index + 1}" }
        updateNotif()
        try {
            val p = MediaPlayer()
            mp = p
            p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            p.setAudioAttributes(attrs)
            p.setDataSource(applicationContext, Uri.parse(uris[index]))
            p.setOnPreparedListener { it.start() }
            p.setOnCompletionListener {
                main.post {
                    index++
                    playCurrent()
                }
            }
            p.setOnErrorListener { _, _, _ ->
                main.post {
                    index++
                    playCurrent()
                }
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            e.printStackTrace()
            index++
            playCurrent()
        }
    }

    private fun releasePlayer() {
        val p = mp ?: return
        mp = null
        try {
            p.setOnCompletionListener(null)
            p.setOnErrorListener(null)
            p.setOnPreparedListener(null)
            p.reset()
            p.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "TuneX playback", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)
    }

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, PlayerService::class.java).setAction(ACTION_STOP)
        val stop = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE)
        val toggleIntent = Intent(this, PlayerService::class.java).setAction(ACTION_TOGGLE)
        val toggle = PendingIntent.getService(this, 2, toggleIntent, PendingIntent.FLAG_IMMUTABLE)

        val total = uris.size
        val track = if (nowTrack.isBlank()) "Starting…" else nowTrack
        val line = if (total > 1) "${index + 1}/$total • $track" else track

        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_music)
            .setContentTitle(if (userPaused) "TuneX • $label (Paused)" else "TuneX • $label")
            .setContentText(line)
            .setStyle(NotificationCompat.BigTextStyle().bigText(line))
            .setContentIntent(open)
            .addAction(0, if (userPaused) "Resume" else "Pause", toggle)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotif() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotif())
    }

    // App swiped from recents: keep playing (foreground service survives this)
    override fun onTaskRemoved(rootIntent: Intent?) {
        // intentionally do nothing
    }

    private fun stopAll() {
        releasePlayer()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releasePlayer()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            afr?.let { am.abandonAudioFocusRequest(it) }
            wl?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        isPlaying = false
        nowTrack = ""
        super.onDestroy()
    }
}
