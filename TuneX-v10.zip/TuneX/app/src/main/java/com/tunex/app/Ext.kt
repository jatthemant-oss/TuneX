package com.tunex.app

import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.core.app.NotificationManagerCompat
import android.net.Uri
import android.provider.MediaStore
import android.view.KeyEvent

/** Spotify / JioSaavn launcher. Tries "play from search" (what voice assistants use) first. */
object Ext {
    const val SPOTIFY = "spotify"
    const val JIO = "jiosaavn"

    fun pkg(app: String): String =
        if (app == SPOTIFY) "com.spotify.music" else "com.jio.media.jiobeats"

    fun title(app: String): String =
        if (app == SPOTIFY) "Spotify" else "JioSaavn"

    fun isLink(t: String): Boolean {
        val u = t.trim().lowercase()
        return u.startsWith("http") || u.startsWith("spotify:") || u.contains(".com/")
    }

    /** Accepts a link of the right app, or plain text (song name). */
    fun valid(app: String, text: String): Boolean {
        val t = text.trim()
        if (t.length < 2) return false
        if (!isLink(t)) return true
        val u = t.lowercase()
        return if (app == SPOTIFY) {
            u.startsWith("spotify:") || u.contains("spotify.com/")
        } else {
            u.contains("jiosaavn.com") || u.contains("saavn.com")
        }
    }

    /** open.spotify.com/track/ID -> spotify:track:ID so the app opens that exact item. */
    private fun spotifyUri(raw: String): Uri {
        if (raw.lowercase().startsWith("spotify:")) return Uri.parse(raw)
        return try {
            val u = Uri.parse(raw)
            val seg = u.pathSegments.filter { !it.startsWith("intl-") }
            if (seg.size >= 2) Uri.parse("spotify:" + seg[0] + ":" + seg[1]) else u
        } catch (e: Exception) {
            Uri.parse(raw)
        }
    }

    fun intent(ctx: Context, s: Schedule): Intent {
        val raw = s.extUrl.trim()
        val pkg = pkg(s.extApp)
        val pm = ctx.packageManager

        // 1) A pasted link: open EXACTLY that link in the app (never re-search it).
        if (isLink(raw)) {
            val uri = if (s.extApp == SPOTIFY) spotifyUri(raw) else Uri.parse(raw)
            val v = Intent(Intent.ACTION_VIEW, uri)
            v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            v.setPackage(pkg)
            if (v.resolveActivity(pm) == null) v.setPackage(null)
            return v
        }

        // 2) Plain song name: ask for a SONG (not radio / artist / playlist)
        if (raw.isNotBlank()) {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            i.setPackage(pkg)
            i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio")
            i.putExtra(MediaStore.EXTRA_MEDIA_TITLE, raw)
            i.putExtra(SearchManager.QUERY, raw)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(pm) != null) return i
        }
        val launch = pm.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return launch
        }
        return Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(raw)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    data class Hit(val title: String, val sub: String, val url: String)

    private fun clean(t: String): String =
        android.text.Html.fromHtml(t, android.text.Html.FROM_HTML_MODE_LEGACY).toString().trim()

    private fun norm(t: String): String = words(clean(t)).joinToString(" ")

    /**
     * JioSaavn: find songs whose TITLE is exactly what was typed (not albums / radios).
     * Must run off the main thread. Empty list = nothing found / no network.
     */
    fun searchJio(query: String): List<Hit> {
        return try {
            val u = java.net.URL(
                "https://www.jiosaavn.com/api.php?__call=autocomplete.get&_format=json&_marker=0&cc=in&includeMetaTags=1&query=" +
                    java.net.URLEncoder.encode(query, "UTF-8")
            )
            val c = u.openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val arr = org.json.JSONObject(body).getJSONObject("songs").getJSONArray("data")
            val q = norm(query)
            val exact = ArrayList<Hit>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val link = o.optString("url").ifBlank { o.optString("perma_url") }
                if (link.isBlank()) continue
                val title = clean(o.optString("title"))
                if (norm(title) != q) continue
                val sub = clean(o.optString("album").ifBlank { o.optString("description") })
                exact.add(Hit(title, sub, link))
            }
            exact
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun listenerEnabled(ctx: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    /** Direct play/pause on the app's own media session (needs Notification access). */
    fun control(ctx: Context, pkg: String, key: Int): Boolean {
        return try {
            val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(ctx, TuneXListener::class.java))
            val c = list.firstOrNull { it.packageName == pkg } ?: return false
            if (key == KeyEvent.KEYCODE_MEDIA_PAUSE) c.transportControls.pause() else c.transportControls.play()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun session(ctx: Context, pkg: String): MediaController? = try {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        msm.getActiveSessions(ComponentName(ctx, TuneXListener::class.java)).firstOrNull { it.packageName == pkg }
    } catch (e: Exception) {
        null
    }

    private fun words(t: String): Set<String> =
        t.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotBlank() }.toSet()

    /** Song title we expect (from JioSaavn link slug or typed name). Blank = unknown. */
    private fun wantedTitle(s: Schedule): String {
        val raw = s.extUrl.trim()
        if (!isLink(raw)) return if (raw.startsWith("spotify:", true)) "" else raw
        return try {
            val seg = Uri.parse(raw).pathSegments
            val i = seg.indexOf("song")
            if (s.extApp != SPOTIFY && i >= 0 && i + 1 < seg.size) seg[i + 1].replace("-", " ") else ""
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Start OUR song, never just resume whatever was paused before.
     * Returns false when the app's media session isn't up yet (try again later).
     */
    fun startTrack(ctx: Context, s: Schedule): Boolean {
        val pkg = pkg(s.extApp)
        val c = session(ctx, pkg) ?: return false
        val raw = s.extUrl.trim()
        val want = wantedTitle(s)
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val mediaId = md?.getString(MediaMetadata.METADATA_KEY_MEDIA_ID) ?: ""
        val isSpotifyLink = s.extApp == SPOTIFY && isLink(raw)
        val wantUri = if (isSpotifyLink) spotifyUri(raw).toString() else ""
        val matches = when {
            isSpotifyLink -> mediaId.equals(wantUri, true)
            want.isNotBlank() && title.isNotBlank() -> {
                val w = words(want)
                val t = words(title)
                w.isNotEmpty() && w.intersect(t).size >= Math.max(1, Math.ceil(w.size * 0.6).toInt())
            }
            else -> false
        }
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        if (matches) {
            if (!playing) c.transportControls.play()
            return true
        }
        // Playing something unrelated started before us? leave it only if we have no target at all
        if (playing && want.isBlank() && !isSpotifyLink) return true
        // wrong / old track: ask the app for ours
        val tc = c.transportControls
        if (isSpotifyLink) {
            tc.playFromUri(Uri.parse(wantUri), null)
        } else {
            val q = if (want.isNotBlank()) want else raw
            val ex = android.os.Bundle()
            ex.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio")
            ex.putString(MediaStore.EXTRA_MEDIA_TITLE, q)
            tc.playFromSearch(q, ex)
        }
        return true
    }

    fun sendKey(ctx: Context, key: Int, pkg: String? = null) {
        if (!pkg.isNullOrBlank()) control(ctx, pkg, key)
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        // also hand the key straight to that app's own media-button receiver
        if (!pkg.isNullOrBlank()) {
            try {
                for (act in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
                    val i = Intent(Intent.ACTION_MEDIA_BUTTON).setPackage(pkg)
                    i.putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(act, key))
                    ctx.sendBroadcast(i)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
