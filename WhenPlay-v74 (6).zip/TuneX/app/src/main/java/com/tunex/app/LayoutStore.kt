package com.tunex.app

import android.content.Context

/** One look only (glass cards, curved source window). Kept as a tiny object so the screens can ask for it. */
object LayoutStore {
    fun index(@Suppress("UNUSED_PARAMETER") ctx: Context): Int = 0
    fun isPills(@Suppress("UNUSED_PARAMETER") ctx: Context): Boolean = false
}
