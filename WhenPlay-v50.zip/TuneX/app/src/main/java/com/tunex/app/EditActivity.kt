package com.tunex.app

import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.tunex.app.databinding.ActivityEditBinding
import java.util.Calendar

class EditActivity : AppCompatActivity() {

    private lateinit var b: ActivityEditBinding
    private var hour = 6
    private var minute = 0
    private var editId = -1
    private var ytId = ""
    private var ytUrl = ""
    private var extApp = ""
    private var extUrl = ""
    private var trackSec = 0
    private var clashOk = false
    private var stopEnabled = false
    private var stopHour = 7
    private var stopMinute = 0
    private var label = "" // optional name: the Name box appears once a source is set
    private var srcKey: String? = null
    private var autoTitle = ""
    private var clearedNote = false
    private val bento by lazy { LayoutStore.isBento(this) }
    private val bentoTiles by lazy { listOf(b.tilePhone, b.tileYt, b.tileIg, b.tileSp, b.tileJio) }
    private val tileColors = intArrayOf(0xFF7C5CFF.toInt(), 0xFFFF3D3D.toInt(), 0xFFE1306C.toInt(), 0xFF1DB954.toInt(), 0xFF2BC5B4.toInt())
    private val uris = mutableListOf<String>()
    private val names = mutableListOf<String>()
    private val dayOrder = intArrayOf(1, 2, 3, 4, 5, 6, 0)
    private val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    // System file picker: works with any folder, SD card, Downloads, WhatsApp, Drive, etc.
    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
            if (list.isNotEmpty()) {
                ytId = ""; ytUrl = ""; extApp = ""; extUrl = ""
            }
            for (u in list) {
                try {
                    contentResolver.takePersistableUriPermission(
                        u, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                val s = u.toString()
                if (s !in uris) {
                    uris.add(s)
                    names.add(displayName(u))
                }
            }
            renderSources()
        }

    private fun displayName(u: android.net.Uri): String {
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "Track"
        } catch (e: Exception) {
            "Track"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeStore.apply(this)
        super.onCreate(savedInstanceState)
        b = ActivityEditBinding.inflate(layoutInflater)
        setContentView(b.root)
        if (bento) applyBentoEdit()
        ThemeStore.styleBars(this)

        val cal = Calendar.getInstance()
        hour = cal.get(Calendar.HOUR_OF_DAY)
        minute = cal.get(Calendar.MINUTE)
        stopHour = (hour + 1) % 24
        stopMinute = minute
        var days = 0
        var vol = 70
        var loop = false

        editId = intent.getIntExtra("id", -1)
        val existing = Store.get(this, editId)
        // a new schedule starts at the phone's current media volume
        if (existing == null) vol = sysVolPercent().coerceIn(10, 100)
        if (existing != null) {
            hour = existing.hour
            minute = existing.minute
            days = existing.days
            vol = existing.volume
            loop = existing.loop
            stopEnabled = existing.stopEnabled
            if (existing.stopEnabled) {
                stopHour = existing.stopHour
                stopMinute = existing.stopMinute
            }
            ytId = existing.ytId
            ytUrl = existing.ytUrl
            extApp = existing.extApp
            extUrl = existing.extUrl
            trackSec = existing.trackSec
            label = existing.customName()
            uris.addAll(existing.uris)
            names.addAll(existing.names)
            b.screenTitle.text = "Edit schedule"
            b.screenSub.text = "Change anything, or just the name."
        }

        for (i in dayOrder) {
            val chip = layoutInflater.inflate(R.layout.chip_day, b.chipDays, false) as android.widget.TextView
            chip.text = dayNames[i]
            chip.tag = i
            chip.isSelected = ((days shr i) and 1) == 1
            chip.setOnClickListener { it.isSelected = !it.isSelected; clashOk = false }
            b.chipDays.addView(chip)
        }

        b.switchLoop.isChecked = loop
        b.switchLoop.setOnCheckedChangeListener { _, _ -> clashOk = false; renderDur() }
        b.switchStop.isChecked = stopEnabled
        b.switchStop.setOnCheckedChangeListener { _, c ->
            stopEnabled = c
            renderStop()
        }

        // Instagram reels loop by themselves: Repeat stays off, the stop time decides how long they loop
        b.switchLoop.setOnTouchListener { _, ev ->
            if (extApp == Ext.INSTAGRAM) {
                if (ev.action == android.view.MotionEvent.ACTION_UP) {
                    Toast.makeText(
                        this,
                        "Reels loop by themselves. For a loop, set the stop time later than the reel's length.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                true
            } else false
        }

        b.volSeek.progress = vol
        b.volText.text = "Volume $vol%"
        b.volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                b.volText.text = "Volume $p%"
                // moving the slider changes the phone's media volume too
                if (fromUser) setSysVolPercent(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        b.timeCard.setOnClickListener {
            pickTime("Start time", hour, minute) { h, m ->
                hour = h
                minute = m
                renderTime()
            }
        }
        b.stopRow.setOnClickListener {
            pickTime("Stop time", stopHour, stopMinute) { h, m ->
                stopHour = h
                stopMinute = m
                stopEnabled = true
                b.switchStop.isChecked = true
                renderStop()
            }
        }

        b.tilePhone.setOnClickListener { chooseFiles() }
        b.tileYt.setOnClickListener { askYoutube() }
        b.tileIg.setOnClickListener { askInstagram() }
        b.tileSp.setOnClickListener { askSpotify() }
        b.tileJio.setOnClickListener { askJio() }
        b.btnChange.setOnClickListener { showSourceSheet() }

        b.btnSave.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            if (uris.isNotEmpty() && trackSec <= 0) trackSec = Scheduler.localSec(this, uris.toList())
            // Stop time longer than the song needs Repeat, otherwise it could never reach that time.
            if (s.extApp != Ext.INSTAGRAM && stopEnabled && trackSec > 0 && !b.switchLoop.isChecked &&
                Scheduler.span(hour, minute, stopHour, stopMinute) * 60 > trackSec + 30
            ) {
                val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
                MaterialAlertDialogBuilder(this)
                    .setTitle("Loop mode required")
                    .setMessage(
                        "The " + noun() + " is " + mmss(trackSec) + " long, but the stop time is $st $sap. " +
                            "Turn on Loop mode to play until the stop time, or choose an earlier stop time."
                    )
                    .setPositiveButton("Turn on Loop mode") { _, _ -> b.switchLoop.isChecked = true }
                    .setNegativeButton("Edit stop time", null)
                    .show()
                return@setOnClickListener
            }
            // Without a stop time a reel plays once, so WhenPlay must know its length
            if (s.extApp == Ext.INSTAGRAM && !stopEnabled && trackSec <= 0) {
                askReelLength(true)
                return@setOnClickListener
            }
            if (!checkClash(s)) return@setOnClickListener
            if (s.extApp.isNotBlank() && s.extApp != Ext.INSTAGRAM && !Ext.listenerEnabled(this)) {
                val needed = s.loop || s.stopEnabled
                if (needed || !listenerAsked) {
                    listenerAsked = true
                    val d = MaterialAlertDialogBuilder(this)
                        .setTitle("Allow notification access")
                        .setMessage(
                            if (needed)
                                "Loop mode and Stop time for Spotify and JioSaavn need Notification access, so WhenPlay can control playback. " +
                                    "Open settings, turn on WhenPlay, then come back and save."
                            else
                                "For Spotify and JioSaavn to start on their own, even when the phone is locked, WhenPlay needs Notification access. " +
                                    "Open settings, turn on WhenPlay, then come back and save."
                        )
                        .setPositiveButton("Open settings") { _, _ ->
                            startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        }
                        .setNegativeButton("Cancel", null)
                    if (!needed) d.setNeutralButton("Save anyway") { _, _ -> b.btnSave.performClick() }
                    d.show()
                    return@setOnClickListener
                }
            }
            persist(s)
            Toast.makeText(
                this,
                "Scheduled • starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_LONG
            ).show()
            finish()
        }

        b.nameInput.setText(label)
        renderTime()
        renderStop()
        renderSources()
    }

    private fun pickTime(title: String, h: Int, m: Int, done: (Int, Int) -> Unit) {
        val p = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_12H)
            .setHour(h)
            .setMinute(m)
            .setTitleText(title)
            .build()
        p.addOnPositiveButtonClickListener { done(p.hour, p.minute) }
        p.show(supportFragmentManager, "time")
    }

    private fun chooseFiles() {
        picker.launch(arrayOf("audio/*", "video/*", "application/ogg", "application/octet-stream"))
    }

    private fun askYoutube() {
        askLink("Paste YouTube link", "Video or Shorts", R.drawable.ic_src_youtube, "youtube", { Yt.parseId(it) != null }, "video") { txt ->
            ytId = Yt.parseId(txt) ?: ""
            ytUrl = txt
            uris.clear(); names.clear(); extApp = ""; extUrl = ""
            trackSec = 0
            renderSources()
            fetchSec("youtube", "https://www.youtube.com/watch?v=" + ytId)
        }
    }

    private fun askSpotify() {
        askLink("Paste Spotify link", "Song link", R.drawable.ic_src_spotify, Ext.SPOTIFY, { Ext.valid(Ext.SPOTIFY, it) }, "song") { txt ->
            setExt(Ext.SPOTIFY, txt, 0)
            fetchSec(Ext.SPOTIFY, txt)
        }
    }

    private fun askJio() {
        askLink("Paste JioSaavn link", "Song link", R.drawable.ic_src_jiosaavn, Ext.JIO, { Ext.valid(Ext.JIO, it) }, "song") { txt ->
            setJio(txt)
            fetchSec(Ext.JIO, txt)
        }
    }

    private fun askInstagram() {
        askLink("Paste Instagram Reel link", "Reel or post link", R.drawable.ic_src_instagram, Ext.INSTAGRAM, { Ext.valid(Ext.INSTAGRAM, it) }, "reel") { txt ->
            setExt(Ext.INSTAGRAM, txt, 0)
            fetchSec(Ext.INSTAGRAM, txt)
        }
    }

    private fun clearSource() {
        uris.clear(); names.clear()
        ytId = ""; ytUrl = ""; extApp = ""; extUrl = ""
        trackSec = 0
        renderSources()
    }

    /** "Change" sheet: pick another source. One source per schedule, switching clears the name. */
    private fun showSourceSheet() {
        val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sb = com.tunex.app.databinding.SheetSourcesBinding.inflate(layoutInflater)
        dlg.setContentView(sb.root)
        (sb.root.parent as? View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        fun tag(v: View, on: Boolean) { v.visibility = if (on) View.VISIBLE else View.GONE }
        tag(sb.tagPhone, uris.isNotEmpty())
        tag(sb.tagYt, ytId.isNotBlank())
        tag(sb.tagIg, extApp == Ext.INSTAGRAM)
        tag(sb.tagSp, extApp == Ext.SPOTIFY)
        tag(sb.tagJio, extApp == Ext.JIO)
        sb.subPhone.text = if (uris.isNotEmpty()) "Add more files" else "Choose a file"
        sb.srcPhone.setOnClickListener { dlg.dismiss(); chooseFiles() }
        sb.srcYt.setOnClickListener { dlg.dismiss(); askYoutube() }
        sb.srcIg.setOnClickListener { dlg.dismiss(); askInstagram() }
        sb.srcSp.setOnClickListener { dlg.dismiss(); askSpotify() }
        sb.srcJio.setOnClickListener { dlg.dismiss(); askJio() }
        sb.srcRemove.setOnClickListener { dlg.dismiss(); clearSource() }
        sb.srcCancel.setOnClickListener { dlg.dismiss() }
        dlg.show()
        dlg.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
    }

    private fun replaceNote(): String {
        if (uris.isEmpty() && ytId.isBlank() && extApp.isBlank()) return ""
        val nm = b.nameInput.text.toString().trim()
        return if (nm.isNotEmpty()) "This replaces your current source. Your name \u201C" + nm + "\u201D will be cleared."
        else "This replaces your current source."
    }

    /** Bottom sheet for pasting a link: paste button, live check, title preview, "Use this link". */
    private fun askLink(title: String, sub: String, icon: Int, kind: String, ok: (String) -> Boolean, noun: String, done: (String) -> Unit) {
        val dlg = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val sb = com.tunex.app.databinding.SheetLinkBinding.inflate(layoutInflater)
        dlg.setContentView(sb.root)
        (sb.root.parent as? View)?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        sb.sheetIcon.setImageResource(icon)
        sb.sheetTitle.text = title
        sb.sheetSub.text = sub
        val note = replaceNote()
        sb.sheetNote.text = note
        sb.sheetNote.visibility = if (note.isEmpty()) View.GONE else View.VISIBLE
        val muted = ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        var shownFor = ""
        fun upd() {
            val v = sb.sheetInput.text.toString().trim()
            val txt = if (Ext.isLink(v)) Ext.cleanLink(v) else v
            val good = v.isNotEmpty() && ok(txt)
            sb.sheetUse.isEnabled = good
            when {
                v.isEmpty() -> {
                    sb.sheetHint.setTextColor(muted)
                    sb.sheetHint.text = "Open the $noun in the app, tap Share \u2192 Copy link, then paste it here."
                }
                good -> {
                    sb.sheetHint.setTextColor(0xFF3DDC97.toInt())
                    sb.sheetHint.text = "\u2714 Link detected. This exact $noun will play."
                }
                else -> {
                    sb.sheetHint.setTextColor(0xFFFFB74D.toInt())
                    sb.sheetHint.text = "\u26A0 Only $noun links from this app are supported."
                }
            }
            if (!good) {
                sb.sheetPreview.visibility = View.GONE
                shownFor = ""
            } else if ((kind == "youtube" || kind == Ext.SPOTIFY) && shownFor != txt) {
                shownFor = txt
                sb.sheetPreview.visibility = View.GONE
                val link = if (kind == "youtube") "https://www.youtube.com/watch?v=" + (Yt.parseId(txt) ?: "") else txt
                Thread {
                    val t = Ext.fetchTitle(kind, link)
                    runOnUiThread {
                        if (dlg.isShowing && shownFor == txt && t.isNotEmpty()) {
                            sb.sheetPreview.text = t
                            sb.sheetPreview.visibility = View.VISIBLE
                        }
                    }
                }.start()
            }
        }
        sb.sheetInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = upd()
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        sb.sheetPaste.setOnClickListener {
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                if (clip.isBlank()) {
                    Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                } else {
                    sb.sheetInput.setText(if (Ext.isLink(clip)) Ext.cleanLink(clip) else clip.trim())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // A link copied just before opening the sheet is pasted automatically (read once the sheet has focus).
        sb.sheetInput.postDelayed({
            try {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                val cl = Ext.cleanLink(clip)
                if (sb.sheetInput.text.isEmpty() && Ext.isLink(cl) && ok(cl)) sb.sheetInput.setText(cl)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, 300)
        sb.sheetUse.setOnClickListener {
            val rawTxt = sb.sheetInput.text.toString().trim()
            val txt = if (Ext.isLink(rawTxt)) Ext.cleanLink(rawTxt) else rawTxt
            if (!ok(txt)) {
                Toast.makeText(this, "This link is not supported", Toast.LENGTH_SHORT).show()
            } else {
                dlg.dismiss()
                done(txt)
            }
        }
        sb.sheetCancel.setOnClickListener { dlg.dismiss() }
        upd()
        dlg.show()
        dlg.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
    }

    /** Turns the chosen song into its exact Spotify link so it plays reliably; falls back to a name search. */
    private fun pickSpotify(song: Ext.Song) {
        Toast.makeText(this, "Matching on Spotify…", Toast.LENGTH_SHORT).show()
        Thread {
            val link = Ext.spotifyLink(song.url)
            runOnUiThread {
                if (link != null) {
                    setExt(Ext.SPOTIFY, link, song.sec)
                    Toast.makeText(this, "Matched: " + song.title, Toast.LENGTH_SHORT).show()
                } else {
                    setExt(Ext.SPOTIFY, song.title + " " + song.artist, song.sec)
                }
            }
        }.start()
    }

    private fun setJio(v: String) = setExt(Ext.JIO, v, 0)

    private fun setExt(app: String, v: String, sec: Int) {
        extApp = app
        extUrl = v
        trackSec = sec
        uris.clear(); names.clear(); ytId = ""; ytUrl = ""
        renderSources()
        renderDur()
    }

    /** Looks up the song length from its link (best effort) and refreshes the warning text. */
    private fun fetchSec(kind: String, link: String) {
        Thread {
            val sec = Ext.fetchSec(kind, link)
            runOnUiThread {
                // screen already closed (never show a dialog on it)
                if (isFinishing || isDestroyed) return@runOnUiThread
                // the user picked another source meanwhile: this answer belongs to the old one
                val same = if (kind == "youtube") ytId.isNotBlank() && link.contains(ytId)
                else extApp == kind && extUrl == link
                if (!same) return@runOnUiThread
                if (sec > 0) {
                    trackSec = sec
                    renderDur()
                } else if (kind == Ext.INSTAGRAM && trackSec <= 0) {
                    askReelLength()
                }
            }
        }.start()
    }

    /** Instagram doesn't always share the reel length, so let the user type it (needed for Repeat / Stop checks). */
    private fun askReelLength(required: Boolean = false) {
        val et = EditText(this)
        et.hint = "e.g. 30  or  0:45"
        et.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et)
        MaterialAlertDialogBuilder(this)
            .setTitle("Reel length")
            .setMessage(
                if (required)
                    "Without a stop time the reel plays once, so WhenPlay needs its length to stop it. " +
                        "Enter it in seconds (or m:ss), or set a stop time instead."
                else
                    "Couldn't read the reel length automatically. Enter it in seconds (or m:ss) so the stop time can be checked."
            )
            .setView(box)
            .setPositiveButton("Set") { _, _ ->
                val t = et.text.toString().trim()
                val sec = if (t.contains(":")) {
                    val p = t.split(":")
                    (p[0].toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
                } else (t.toIntOrNull() ?: 0)
                if (sec > 0) {
                    trackSec = sec
                    renderDur()
                    if (required) Toast.makeText(this, "Length saved. Tap Save again.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(if (required) "Cancel" else "Skip", null)
            .show()
    }

    private fun audio() = getSystemService(AUDIO_SERVICE) as android.media.AudioManager

    private fun sysVolPercent(): Int {
        val am = audio()
        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
        return if (max <= 0) 70 else am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) * 100 / max
    }

    private fun setSysVolPercent(p: Int) {
        try {
            val am = audio()
            val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (max * p / 100).coerceIn(0, max), 0)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // phone volume buttons -> slider
    private val volReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context?, i: Intent?) {
            if (i?.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) != android.media.AudioManager.STREAM_MUSIC) return
            val p = sysVolPercent().coerceIn(10, 100)
            if (b.volSeek.progress != p) {
                b.volSeek.progress = p
                b.volText.text = "Volume $p%"
            }
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            registerReceiver(volReceiver, android.content.IntentFilter("android.media.VOLUME_CHANGED_ACTION"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onStop() {
        try {
            unregisterReceiver(volReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onStop()
    }

    private var listenerAsked = false

    private fun renderTime() {
        val (t, ap) = Scheduler.fmt12(hour, minute)
        b.timeText.text = t
        b.ampmText.text = ap
        clashOk = false
        renderDur()
    }

    private fun noun() = if (uris.isNotEmpty()) "playlist" else if (extApp == Ext.INSTAGRAM) "reel" else "song"

    private fun mmss(sec: Int) = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')

    /** Instagram source: Repeat greyed out and off (the reel loops by itself until the stop time). */
    private fun applyIgLocks() {
        val ig = extApp == Ext.INSTAGRAM
        b.switchLoop.alpha = if (ig) 0.4f else 1f
        if (ig && b.switchLoop.isChecked) b.switchLoop.isChecked = false
    }

    /** Duration text for an Instagram reel. */
    private fun renderIgDur() {
        val sb = StringBuilder()
        if (trackSec > 0) sb.append("Reel length ").append(mmss(trackSec)).append("\n")
        if (!stopEnabled) {
            sb.append(if (trackSec > 0) "Plays once, then stops. Set a stop time to loop it." else "Set a stop time, or enter the reel length.")
        } else {
            val runSec = Scheduler.span(hour, minute, stopHour, stopMinute) * 60
            val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
            if (trackSec <= 0) {
                sb.append("Reel loops until ").append(st).append(" ").append(sap).append(".")
            } else if (runSec < trackSec) {
                sb.append("Stops at ").append(st).append(" ").append(sap).append(", before the reel ends.")
            } else {
                val full = runSec / trackSec
                val rest = runSec % trackSec
                sb.append("Reel loops: ").append(full).append(if (full == 1) " full play" else " full plays")
                if (rest > 15) sb.append(" + ").append(mmss(rest))
                sb.append(", then stops at ").append(st).append(" ").append(sap).append(".")
            }
        }
        b.durText.setTextColor(ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8F93B8.toInt()))
        b.durText.text = sb.toString().trim()
    }

    private fun renderDur() {
        if (extApp == Ext.INSTAGRAM) {
            renderIgDur()
            return
        }
        val loopOn = b.switchLoop.isChecked
        val sb = StringBuilder()
        var warn = false
        if (trackSec > 0) sb.append(if (uris.isNotEmpty()) "Total length " else if (extApp == Ext.INSTAGRAM) "Reel length " else "Song length ").append(mmss(trackSec)).append("\n")
        if (stopEnabled) {
            val sp = Scheduler.span(hour, minute, stopHour, stopMinute)
            val runSec = sp * 60
            val (st, sap) = Scheduler.fmt12(stopHour, stopMinute)
            if (trackSec <= 0) {
                sb.append("Runs for ").append(Scheduler.fmtDur(sp))
            } else if (runSec <= trackSec + 30) {
                sb.append("Stops at ").append(st).append(" ").append(sap).append(", before it ends.")
            } else {
                val full = runSec / trackSec
                val rest = runSec % trackSec
                val plan = StringBuilder()
                plan.append(full).append(if (full == 1) " full play" else " full plays")
                if (rest > 15) plan.append(" + ").append(mmss(rest))
                if (loopOn) {
                    sb.append("Loop mode: ").append(plan).append(", then stops at ").append(st).append(" ").append(sap).append(".")
                } else {
                    warn = true
                    sb.append("Plays once (").append(mmss(trackSec)).append(") and stops.\n")
                    sb.append("⚠ Stop time is later than the " + noun() + ". Turn on Loop mode to play ").append(plan)
                        .append(" until ").append(st).append(" ").append(sap).append(".")
                }
            }
        } else if (trackSec > 0 && !loopOn) {
            sb.append("Plays once, then stops.")
        }
        b.durText.setTextColor(if (warn) 0xFFFFB74D.toInt() else ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8F93B8.toInt()))
        b.durText.text = sb.toString().trim()
    }

    /** Two schedules can't play together: ask to create this one after the other ends. */
    /** Two schedules can't play together: ask to create this one after the other ends. */
    private fun checkClash(s: Schedule): Boolean {
        if (clashOk) return true
        val cl = Scheduler.conflict(this, s) ?: return true
        val c = cl.other
        val (cs, cap) = Scheduler.fmt12(c.hour, c.minute)
        val q = "\u201C" + c.title() + "\u201D"
        val candLater = (hour * 60 + minute) > (c.hour * 60 + c.minute)
        val ce = Scheduler.endMinutes(this, c)
        val (es, eap) = Scheduler.fmt12(ce / 60, ce % 60)

        // Which schedule has priority: the one that starts later takes over; the other one steps aside
        // and comes back afterwards if its own stop time has not passed.
        val msg: String
        var canMove = false
        if (cl.otherOpen && candLater) {
            msg = "$q ($cs $cap) is in Loop mode.\n\nThis schedule has priority: when its time comes, $q will stop " +
                "and will not come back."
        } else if (cl.otherOpen) {
            msg = "$q ($cs $cap) is in Loop mode and starts after this schedule.\n\nWhen $q starts it takes priority and keeps looping, " +
                "so this schedule will not continue after that point."
        } else if (cl.candOpen) {
            msg = "This schedule is in Loop mode.\n\nWhen $q ($cs $cap) starts, it takes priority and this one stops " +
                "and will not come back."
        } else {
            val dm = Scheduler.durationMin(this, c)
            val len = if (dm != null) " (" + Scheduler.fmtDur(dm) + ")" else ""
            canMove = true
            msg = if (candLater)
                "$q plays $cs $cap \u2192 $es $eap$len.\n\nIf you save, this schedule takes priority at its start time. " +
                    "$q will stop and will not come back."
            else
                "$q starts at $cs $cap, while this schedule is still running.\n\nIf you save, $q takes priority when it starts. " +
                    "This schedule will stop and will not come back."
        }
        val d = MaterialAlertDialogBuilder(this)
            .setTitle("Schedules overlap")
            .setMessage(msg)
            .setPositiveButton("Save") { _, _ -> clashOk = true; b.btnSave.performClick() }
            .setNegativeButton("Cancel", null)
        if (canMove && candLater) {
            d.setNeutralButton("Start at $es $eap") { _, _ ->
                val keep = if (stopEnabled) Scheduler.span(hour, minute, stopHour, stopMinute) else 0
                hour = ce / 60
                minute = ce % 60
                if (stopEnabled) {
                    val e = (ce + keep) % 1440
                    stopHour = e / 60
                    stopMinute = e % 60
                }
                renderTime()
                renderStop()
                Toast.makeText(this, "Start time updated. Tap Save.", Toast.LENGTH_SHORT).show()
            }
        }
        d.show()
        return false
    }

    private fun renderStop() {
        val (t, ap) = Scheduler.fmt12(stopHour, stopMinute)
        b.stopTime.text = "$t $ap"
        b.stopTime.alpha = if (stopEnabled) 1f else 0.4f
        b.stopEditIcon.alpha = if (stopEnabled) 1f else 0.4f
        renderDur()
    }

    /** Name box: shown only while a source is set; a different source clears the old name. */
    private fun syncName() {
        val key = when {
            ytId.isNotBlank() -> "yt:$ytId"
            extApp.isNotBlank() -> "ext:$extApp:$extUrl"
            uris.isNotEmpty() -> "files"
            else -> ""
        }
        if (srcKey != key) {
            val had = b.nameInput.text.toString().trim()
            if (srcKey != null) b.nameInput.setText("")
            clearedNote = srcKey != null && had.isNotEmpty()
            srcKey = key
            autoTitle = ""
            val kind = when {
                key.startsWith("yt:") -> "youtube"
                extApp == Ext.SPOTIFY -> Ext.SPOTIFY
                else -> ""
            }
            if (kind.isNotEmpty()) {
                val link = if (kind == "youtube") "https://www.youtube.com/watch?v=" + ytId else extUrl
                Thread {
                    val t = Ext.fetchTitle(kind, link)
                    runOnUiThread {
                        if (isFinishing || isDestroyed || srcKey != key) return@runOnUiThread
                        autoTitle = t
                        syncName()
                        renderSummary()
                    }
                }.start()
            }
        }
        b.nameCard.visibility = if (key.isEmpty()) View.GONE else View.VISIBLE
        val igNote = extApp == Ext.INSTAGRAM
        b.nameNote.visibility = if (clearedNote || igNote) View.VISIBLE else View.GONE
        b.nameNote.text = if (clearedNote) "Name cleared for the new source" else "Instagram doesn\u2019t share reel titles, so add your own name if you like."
        b.nameNote.setTextColor(
            if (clearedNote) ThemeStore.attrColor(this, R.attr.txAccent, 0xFF7C5CFF.toInt())
            else ThemeStore.attrColor(this, R.attr.txMuted, 0xFF8B92B5.toInt())
        )
        b.nameInput.hint = when {
            uris.isNotEmpty() -> names.firstOrNull()?.substringBeforeLast('.')?.ifBlank { null } ?: "Name (optional)"
            autoTitle.isNotBlank() -> autoTitle
            else -> "Name (optional)"
        }
    }

    /** Bento look for this screen: bold type, 3-column colour source tiles, ink "Done". */
    private fun applyBentoEdit() {
        val dp = resources.displayMetrics.density
        val black = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
        b.screenTitle.typeface = black
        b.timeText.typeface = black
        b.timeText.textSize = 52f
        b.timeCard.gravity = android.view.Gravity.START
        b.timeCard.setPadding((22 * dp).toInt(), (20 * dp).toInt(), (22 * dp).toInt(), (18 * dp).toInt())
        val labels = listOf("Phone", "YouTube", "Instagram", "Spotify", "JioSaavn")
        bentoTiles.forEachIndexed { i, t ->
            (t.parent as? android.view.ViewGroup)?.removeView(t)
            t.gravity = android.view.Gravity.CENTER_HORIZONTAL
            t.setPadding((6 * dp).toInt(), (14 * dp).toInt(), (6 * dp).toInt(), (14 * dp).toInt())
            (t.getChildAt(1) as? android.widget.TextView)?.apply {
                text = labels[i]
                textSize = 12f
                typeface = black
            }
            t.getChildAt(2)?.visibility = View.GONE
        }
        b.tilesGrid.removeAllViews()
        val m = (5 * dp).toInt()
        bentoTiles.chunked(3).forEach { chunk ->
            val row = android.widget.LinearLayout(this)
            row.orientation = android.widget.LinearLayout.HORIZONTAL
            chunk.forEach { t ->
                val lp = android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                lp.setMargins(m, m, m, m)
                row.addView(t, lp)
            }
            repeat(3 - chunk.size) {
                val lp = android.widget.LinearLayout.LayoutParams(0, 1, 1f)
                lp.setMargins(m, 0, m, 0)
                row.addView(View(this), lp)
            }
            b.tilesGrid.addView(
                row,
                android.widget.LinearLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        b.btnChange.visibility = View.GONE
        b.btnSave.backgroundTintList = android.content.res.ColorStateList.valueOf(
            ThemeStore.attrColor(this, R.attr.txText, 0xFF111111.toInt())
        )
        b.btnSave.setTextColor(ThemeStore.attrColor(this, R.attr.txBg, 0xFFFFFFFF.toInt()))
    }

    /** Source tiles are tinted with their brand colour; the one in use gets an ink outline. */
    private fun styleBentoTiles() {
        val dp = resources.displayMetrics.density
        val card = ThemeStore.attrColor(this, R.attr.txCard, 0xFF222222.toInt())
        val ink = ThemeStore.attrColor(this, R.attr.txText, 0xFF111111.toInt())
        val sel = booleanArrayOf(uris.isNotEmpty(), ytId.isNotBlank(), extApp == Ext.INSTAGRAM, extApp == Ext.SPOTIFY, extApp == Ext.JIO)
        bentoTiles.forEachIndexed { i, t ->
            val gd = android.graphics.drawable.GradientDrawable()
            gd.cornerRadius = 22 * dp
            gd.setColor(androidx.core.graphics.ColorUtils.compositeColors((tileColors[i] and 0x00FFFFFF) or 0x38000000, card))
            if (sel[i]) gd.setStroke((2 * dp).toInt(), ink)
            t.background = gd
        }
    }

    /** Tiles while nothing is chosen; a summary card (source, Change, Name box) once a source is set. */
    private fun renderSummary() {
        val has = uris.isNotEmpty() || ytId.isNotBlank() || extApp.isNotBlank()
        b.tilesGrid.visibility = if (has && !bento) View.GONE else View.VISIBLE
        if (bento) styleBentoTiles()
        b.summaryCard.visibility = if (has) View.VISIBLE else View.GONE
        b.btnSave.isEnabled = has
        b.btnSave.alpha = if (has) 1f else 0.5f
        if (!has) return
        when {
            uris.isNotEmpty() -> {
                b.sumIcon.setImageResource(R.drawable.ic_src_phone)
                b.sumTitle.text = if (names.size == 1) names[0] else names.size.toString() + " files"
                b.sumSub.text = if (names.size == 1) "Phone music"
                else names.mapIndexed { i, n -> (i + 1).toString() + ". " + n }.joinToString("\n")
            }
            ytId.isNotBlank() -> {
                b.sumIcon.setImageResource(R.drawable.ic_src_youtube)
                b.sumTitle.text = if (autoTitle.isNotBlank()) autoTitle else "YouTube"
                b.sumSub.text = "YouTube \u00B7 " + ytUrl
            }
            extApp == Ext.SPOTIFY -> {
                b.sumIcon.setImageResource(R.drawable.ic_src_spotify)
                b.sumTitle.text = if (autoTitle.isNotBlank()) autoTitle else "Spotify"
                b.sumSub.text = "Spotify \u00B7 " + extUrl
            }
            extApp == Ext.JIO -> {
                b.sumIcon.setImageResource(R.drawable.ic_src_jiosaavn)
                b.sumTitle.text = "JioSaavn"
                b.sumSub.text = extUrl
            }
            else -> {
                b.sumIcon.setImageResource(R.drawable.ic_src_instagram)
                b.sumTitle.text = "Instagram Reel"
                b.sumSub.text = extUrl
            }
        }
    }

    private fun renderSources() {
        syncName()
        renderSummary()
        if (uris.isNotEmpty()) {
            refreshLocalSec()
        } else if (ytId.isBlank() && extApp.isBlank()) {
            trackSec = 0
            renderDur()
        }
        applyIgLocks()
    }

    /** Reads the real length of the chosen phone files so Stop time / Repeat can be checked. */
    private fun refreshLocalSec() {
        val snap = uris.toList()
        Thread {
            val sec = Scheduler.localSec(this, snap)
            runOnUiThread {
                if (uris.isNotEmpty() && uris.toList() == snap) {
                    trackSec = sec
                    renderDur()
                }
            }
        }.start()
    }

    private fun collect(): Schedule? {
        if (uris.isEmpty() && ytId.isBlank() && extApp.isBlank()) {
            Toast.makeText(this, "Add music, a YouTube, Spotify, JioSaavn or Instagram link", Toast.LENGTH_SHORT).show()
            return null
        }
        var days = 0
        for (i in 0 until b.chipDays.childCount) {
            val c = b.chipDays.getChildAt(i)
            if (c.isSelected) days = days or (1 shl (c.tag as Int))
        }
        label = b.nameInput.text.toString().trim()
        val id = if (editId > 0) editId else Store.nextId(this)
        return Schedule(
            id = id,
            hour = hour,
            minute = minute,
            days = days,
            label = label,
            uris = uris.toList(),
            names = names.toList(),
            enabled = true,
            volume = b.volSeek.progress.coerceAtLeast(10),
            onceAt = 0L,
            ytId = ytId,
            ytUrl = ytUrl,
            loop = b.switchLoop.isChecked,
            stopEnabled = stopEnabled,
            stopHour = stopHour,
            stopMinute = stopMinute,
            extApp = extApp,
            extUrl = extUrl,
            trackSec = trackSec
        )
    }

    private fun persist(s: Schedule) {
        editId = s.id
        Store.upsert(this, s)
        Scheduler.cancel(this, s.id)
        Scheduler.arm(this, s)
    }
}
