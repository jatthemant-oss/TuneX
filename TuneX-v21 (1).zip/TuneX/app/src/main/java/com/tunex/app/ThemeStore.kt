package com.tunex.app

import android.app.Activity
import android.content.Context
import android.util.TypedValue
import androidx.core.view.WindowCompat

/** Colour themes. Only look & feel - no behaviour is touched. */
object ThemeStore {
    data class T(val name: String, val style: Int, val bg: Int, val card: Int, val accent: Int, val light: Boolean)

    val all = listOf(
        T("Midnight", R.style.Theme_TuneX_Midnight, 0xFF0B0D17.toInt(), 0xFF151929.toInt(), 0xFF7C5CFF.toInt(), false),
        T("Graphite", R.style.Theme_TuneX_Graphite, 0xFF0E0F11.toInt(), 0xFF17181B.toInt(), 0xFFE4E4E7.toInt(), false),
        T("AMOLED", R.style.Theme_TuneX_Amoled, 0xFF000000.toInt(), 0xFF0C0E0D.toInt(), 0xFF34D399.toInt(), false),
        T("Ivory", R.style.Theme_TuneX_Ivory, 0xFFF5F5F8.toInt(), 0xFFFFFFFF.toInt(), 0xFF5B47E0.toInt(), true),
        T("Rose", R.style.Theme_TuneX_Rose, 0xFF0F0A0D.toInt(), 0xFF1A1218.toInt(), 0xFFF43F6E.toInt(), false)
    )

    fun index(ctx: Context): Int =
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).getInt("theme", 0).coerceIn(0, all.size - 1)

    fun set(ctx: Context, i: Int) {
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
    }

    /** Call BEFORE super.onCreate(). */
    fun apply(a: Activity) = a.setTheme(all[index(a)].style)

    /** Call AFTER setContentView(): dark/light status & navigation icons. */
    fun styleBars(a: Activity) {
        val light = all[index(a)].light
        val c = WindowCompat.getInsetsController(a.window, a.window.decorView)
        c.isAppearanceLightStatusBars = light
        c.isAppearanceLightNavigationBars = light
    }

    fun attrColor(ctx: Context, attr: Int, def: Int): Int {
        val tv = TypedValue()
        return if (ctx.theme.resolveAttribute(attr, tv, true)) tv.data else def
    }
}
