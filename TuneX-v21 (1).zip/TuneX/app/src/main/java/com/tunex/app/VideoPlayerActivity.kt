package com.tunex.app

import android.app.NotificationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.tunex.app.databinding.ActivityVideoBinding

/** Plays videos (and audio files) from the phone full-screen. Screen turns on and stays on. */
class VideoPlayerActivity : AppCompatActivity() {

    private lateinit var b: ActivityVideoBinding
    private val handler = Handler(Looper.getMainLooper())
    private var sched: Schedule? = null
    private var list: List<Uri> = emptyList()
    private var idx = 0
    private var errors = 0
    private var closing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b = ActivityVideoBinding.inflate(layoutInflater)
        setContentView(b.root)

        val id = intent.getIntExtra("id", -1)
        val s = Store.get(this, id)
        if (s == null || s.uris.isEmpty()) {
            finish()
            return
        }
        sched = s
        list = s.uris.map { Uri.parse(it) }
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2000 + id)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (intent.getBooleanExtra("alarm", false)) {
            getSharedPreferences("tunex_ui", MODE_PRIVATE).edit()
                .putLong("lastStart", System.currentTimeMillis()).apply()
        }

        b.vidTitle.text = s.label
        b.vidStop.setOnClickListener { finishPlayback() }
        Scheduler.applyVolume(this, s.volume)

        val dl = Scheduler.stopDeadline(s)
        if (dl > 0L) {
            handler.postDelayed({ finishPlayback() }, (dl - System.currentTimeMillis()).coerceAtLeast(1000L))
        }

        b.vidView.setOnPreparedListener {
            errors = 0
            b.vidStatus.text = "Playing " + (idx + 1) + " of " + list.size
            it.start()
        }
        b.vidView.setOnCompletionListener { next() }
        b.vidView.setOnErrorListener { _, _, _ ->
            errors++
            if (errors >= list.size) {
                b.vidStatus.text = "This file can't be played"
                handler.postDelayed({ finishPlayback() }, 2500)
            } else {
                next()
            }
            true
        }
        playCurrent()
    }

    private fun playCurrent() {
        if (closing) return
        b.vidStatus.text = "Loading…"
        try {
            b.vidView.setVideoURI(list[idx])
        } catch (e: Exception) {
            e.printStackTrace()
            next()
        }
    }

    private fun next() {
        if (closing) return
        idx++
        if (idx >= list.size) {
            if (sched?.loop == true) {
                idx = 0
            } else {
                finishPlayback()
                return
            }
        }
        playCurrent()
    }

    private fun finishPlayback() {
        if (closing) return
        closing = true
        try {
            b.vidView.stopPlayback()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            b.vidView.stopPlayback()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
