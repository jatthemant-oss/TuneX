package com.tunex.app

/** Instagram reel / post links. */
object Ig {
    private val rx = Regex("instagram\\.com/(?:[A-Za-z0-9_.]+/)?(?:reel|reels|p|tv)/([A-Za-z0-9_-]{5,})")

    fun parseCode(text: String): String? = rx.find(text.trim())?.groupValues?.get(1)

    fun canonical(code: String) = "https://www.instagram.com/reel/$code/"

    fun embed(code: String) = "https://www.instagram.com/p/$code/embed/"
}
