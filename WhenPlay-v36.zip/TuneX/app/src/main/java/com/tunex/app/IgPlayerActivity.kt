package com.tunex.app

import android.app.NotificationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.tunex.app.databinding.ActivityIgBinding

/**
 * Plays an Instagram reel full-screen.
 * 1) Preferred: the reel's own video address is played in a clean native player.
 * 2) Fallback: Instagram's public embed page, with all page chrome hidden.
 * Needs internet; screen stays on.
 */
class IgPlayerActivity : AppCompatActivity() {

    private lateinit var b: ActivityIgBinding
    private val handler = Handler(Looper.getMainLooper())
    private var sched: Schedule? = null
    private var code = ""
    private var closing = false
    private var started = false
    private var nativeMode = false
    private var userSeeking = false
    private var controlsShown = true
    private var playing = false
    private var syntheticTap = false
    private var webTaps = 0

    private val ticker = object : Runnable {
        override fun run() {
            poll()
            handler.postDelayed(this, 600)
        }
    }
    private val hideRunnable = Runnable { hideControls() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b = ActivityIgBinding.inflate(layoutInflater)
        setContentView(b.root)

        val id = intent.getIntExtra("id", -1)
        val s = Store.get(this, id)
        val c = if (s != null) Ig.parseCode(s.igUrl) else null
        if (s == null || c == null) {
            finish()
            return
        }
        sched = s
        code = c
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2000 + id)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (intent.getBooleanExtra("alarm", false)) {
            getSharedPreferences("tunex_ui", MODE_PRIVATE).edit()
                .putLong("lastStart", System.currentTimeMillis()).apply()
        }

        b.igTitle.text = s.label
        b.igStop.setOnClickListener { finishPlayback() }
        Scheduler.applyVolume(this, s.volume)

        val dl = Scheduler.stopDeadline(s)
        if (dl > 0L) {
            handler.postDelayed({ finishPlayback() }, (dl - System.currentTimeMillis()).coerceAtLeast(1000L))
        }

        // tap anywhere on the video = show / hide controls
        val touch = View.OnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP && !syntheticTap) toggleControls()
            nativeMode
        }
        b.igVideo.setOnTouchListener(touch)
        b.igWeb.setOnTouchListener { v, ev -> touch.onTouch(v, ev); false }

        b.igSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) b.igPos.text = fmt(p)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                userSeeking = true
                showControls()
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                seekToMs(sb?.progress ?: 0)
                userSeeking = false
                showControls()
            }
        })
        b.igPlay.setOnClickListener {
            showControls()
            togglePlay()
        }
        b.igBack.setOnClickListener {
            showControls()
            seekToMs((curPos() - 10_000).coerceAtLeast(0))
        }
        b.igFwd.setOnClickListener {
            showControls()
            val d = curDur()
            seekToMs((curPos() + 10_000).let { if (d > 0) minOf(it, d - 500) else it })
        }

        startWhenOnline()
        showControls()
    }

    // ---------------------------------------------------------------- start

    private fun startWhenOnline() {
        if (started || closing) return
        if (Yt.online(this)) {
            started = true
            b.igStatus.text = "Loading…"
            Thread {
                val url = Ext.fetchIgVideoUrl(code)
                runOnUiThread {
                    if (closing) return@runOnUiThread
                    if (url != null) startNative(url) else startWeb()
                }
            }.start()
        } else {
            b.igStatus.text = "Waiting for internet…"
            handler.postDelayed({ startWhenOnline() }, 4000)
        }
    }

    private fun startNative(url: String) {
        nativeMode = true
        b.igWeb.visibility = View.GONE
        b.igVideo.visibility = View.VISIBLE
        b.igVideo.setOnPreparedListener {
            it.setVolume(1f, 1f)
            it.start()
        }
        b.igVideo.setOnCompletionListener {
            if (sched?.loop == true) {
                b.igVideo.seekTo(0)
                b.igVideo.start()
            } else {
                finishPlayback()
            }
        }
        b.igVideo.setOnErrorListener { _, _, _ ->
            // direct address did not work: use the embed page instead
            if (!closing && nativeMode) {
                nativeMode = false
                b.igVideo.visibility = View.GONE
                b.igWeb.visibility = View.VISIBLE
                startWeb()
            }
            true
        }
        try {
            b.igVideo.setVideoURI(Uri.parse(url))
        } catch (e: Exception) {
            e.printStackTrace()
            b.igVideo.visibility = View.GONE
            nativeMode = false
            startWeb()
            return
        }
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun startWeb() {
        nativeMode = false
        b.igWeb.visibility = View.VISIBLE
        val w = b.igWeb
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.setBackgroundColor(0xFF000000.toInt())
        w.webChromeClient = WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true

            override fun onPageFinished(view: WebView?, url: String?) {
                hidePageChrome()
            }
        }
        w.loadUrl(Ig.embed(code))
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 1500)
    }

    /** Hides Instagram's header, caption, footer and "Watch on Instagram" so only the reel shows. */
    private fun hidePageChrome() {
        val css = "html,body{background:#000!important;margin:0!important}" +
            "[class*=Header],[class*=Footer],[class*=Caption],[class*=WatchOn],[class*=Follow],[class*=Profile]," +
            "a[href*='/accounts/'],a[href*='/explore/']{display:none!important}" +
            "video{width:100%!important;height:100%!important;object-fit:contain!important;background:#000}"
        b.igWeb.evaluateJavascript(
            "(function(){var s=document.createElement('style');s.innerHTML=\"$css\";document.head.appendChild(s);})()",
            null
        )
    }

    /** The embed page only creates its video after a tap - so tap the middle of the screen for the user. */
    private fun tapCenter() {
        val w = b.igWeb
        if (w.width == 0) return
        val x = w.width / 2f
        val y = w.height / 2f
        val t = SystemClock.uptimeMillis()
        syntheticTap = true
        val d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
        val u = MotionEvent.obtain(t, t + 60, MotionEvent.ACTION_UP, x, y, 0)
        w.dispatchTouchEvent(d)
        w.dispatchTouchEvent(u)
        d.recycle()
        u.recycle()
        syntheticTap = false
    }

    // ---------------------------------------------------------------- controls

    private fun fmt(ms: Int): String {
        val t = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d", t / 60, t % 60)
    }

    private var webPos = 0
    private var webDur = 0

    private fun curPos(): Int = if (nativeMode) b.igVideo.currentPosition else webPos
    private fun curDur(): Int = if (nativeMode) b.igVideo.duration else webDur

    /** Runs a snippet against the page's <video>; does nothing when there is none yet. */
    private fun js(body: String) {
        if (closing) return
        b.igWeb.evaluateJavascript("(function(){var v=document.querySelector('video');if(!v)return;$body})()", null)
    }

    private fun seekToMs(ms: Int) {
        if (nativeMode) b.igVideo.seekTo(ms) else js("v.currentTime=" + (ms / 1000.0) + ";")
    }

    private fun togglePlay() {
        if (nativeMode) {
            if (b.igVideo.isPlaying) b.igVideo.pause() else b.igVideo.start()
        } else {
            if (playing) js("window.__wpPaused=true;v.pause();") else js("window.__wpPaused=false;v.play();")
        }
    }

    private fun render(pos: Int, dur: Int, isPlaying: Boolean, paused: Boolean) {
        playing = isPlaying
        b.igStatus.text = if (isPlaying) "Playing…" else if (paused) "Paused" else "Loading…"
        if (dur > 0) {
            b.igSeek.max = dur
            b.igDur.text = fmt(dur)
            if (!userSeeking) b.igSeek.progress = pos
        }
        if (!userSeeking) b.igPos.text = fmt(pos)
        b.igPlay.setImageResource(if (isPlaying) R.drawable.ic_pause_dark else R.drawable.ic_play_dark)
    }

    private fun poll() {
        if (closing) return
        val s = sched ?: return
        if (nativeMode) {
            val d = b.igVideo.duration
            val p = b.igVideo.currentPosition
            val pl = b.igVideo.isPlaying
            render(p, if (d > 0) d else 0, pl, !pl && d > 0)
            return
        }
        val loop = if (s.loop) "true" else "false"
        val script = """(function(){var v=document.querySelector('video');
if(!v){return '';}
v.muted=false;v.loop=$loop;v.setAttribute('playsinline','');
if(v.paused&&!window.__wpPaused&&!v.ended){var r=v.play();if(r&&r.catch){r.catch(function(){});}}
return v.currentTime+'|'+(v.duration||0)+'|'+(v.paused?1:0)+'|'+(v.ended?1:0);})()"""
        b.igWeb.evaluateJavascript(script) { res ->
            if (closing || nativeMode) return@evaluateJavascript
            val parts = (res?.trim('"') ?: "").split("|")
            if (parts.size < 4) {
                // no video yet: tap the page's play button for the user (a few tries)
                if (webTaps < 6) {
                    webTaps++
                    tapCenter()
                }
                render(0, 0, false, false)
                return@evaluateJavascript
            }
            val pos = ((parts[0].toDoubleOrNull() ?: 0.0) * 1000).toInt()
            val d = (parts[1].toDoubleOrNull() ?: 0.0) * 1000
            val dur = if (d > 0 && d < 1e9) d.toInt() else 0
            val paused = parts[2] == "1"
            val ended = parts[3] == "1"
            webPos = pos
            webDur = dur
            render(pos, dur, !paused && !ended, paused)
            if (ended && !s.loop) finishPlayback()
        }
    }

    private fun showControls() {
        if (closing) return
        controlsShown = true
        for (v in listOf(b.igTop, b.igControls)) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(180).start()
        }
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 3500)
    }

    private fun hideControls() {
        if (closing) return
        if (userSeeking || !playing) {
            handler.postDelayed(hideRunnable, 2000)
            return
        }
        controlsShown = false
        for (v in listOf(b.igTop, b.igControls)) {
            v.animate().alpha(0f).setDuration(220).withEndAction { v.visibility = View.INVISIBLE }.start()
        }
    }

    private fun toggleControls() {
        if (controlsShown) {
            handler.removeCallbacks(hideRunnable)
            hideControls()
            if (!playing) showControls()
        } else {
            showControls()
        }
    }

    private fun finishPlayback() {
        if (closing) return
        closing = true
        try {
            b.igVideo.stopPlayback()
            b.igWeb.loadUrl("about:blank")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            b.igWeb.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
