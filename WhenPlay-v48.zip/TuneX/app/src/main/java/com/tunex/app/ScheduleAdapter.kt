package com.tunex.app

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tunex.app.databinding.ItemScheduleBinding

class ScheduleAdapter(
    private val onToggle: (Schedule, Boolean) -> Unit,
    private val onEdit: (Schedule) -> Unit,
    private val onDelete: (Schedule) -> Unit
) : RecyclerView.Adapter<ScheduleAdapter.VH>() {

    private var items: List<Schedule> = emptyList()

    fun submit(l: List<Schedule>) {
        items = l
        notifyDataSetChanged()
    }

    class VH(val b: ItemScheduleBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemScheduleBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val s = items[position]
        val (t, ap) = Scheduler.fmt12(s.hour, s.minute)
        h.b.time.text = t
        h.b.ampm.text = ap
        // The badge already says which source plays, so a name is shown only when somebody typed one.
        val shownName = s.customName()
        h.b.label.text = shownName
        h.b.label.visibility = if (shownName.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE

        val isExt = s.extApp.isNotBlank()
        val isYt = s.ytId.isNotBlank()
        val badge: Pair<String, Int> = when {
            s.extApp == Ext.SPOTIFY -> Pair("SPOTIFY", 0xFF1DB954.toInt())
            s.extApp == Ext.JIO -> Pair("JIOSAAVN", 0xFF2BC5B4.toInt())
            s.extApp == Ext.INSTAGRAM -> Pair("INSTAGRAM", 0xFFE1306C.toInt())
            isYt -> Pair("YOUTUBE", 0xFFFF3D3D.toInt())
            Ext.hasVideo(h.b.root.context, s) -> Pair("VIDEO", 0xFFF59E0B.toInt())
            else -> Pair("MUSIC", 0xFF7C5CFF.toInt())
        }
        h.b.badge.text = badge.first
        h.b.srcIcon.setImageResource(
            when {
                s.extApp == Ext.SPOTIFY -> R.drawable.ic_src_spotify
                s.extApp == Ext.JIO -> R.drawable.ic_src_jiosaavn
                s.extApp == Ext.INSTAGRAM -> R.drawable.ic_src_instagram
                isYt -> R.drawable.ic_src_youtube
                else -> R.drawable.ic_src_phone
            }
        )
        val gd = GradientDrawable()
        gd.cornerRadius = 60f
        gd.setColor((badge.second and 0x00FFFFFF) or 0x26000000)
        h.b.pill.background = gd

        val parts = mutableListOf(Scheduler.dayLabel(s.days))
        if (!isExt && !isYt) {
            val n = s.uris.size
            val vid = Ext.hasVideo(h.b.root.context, s)
            parts.add(n.toString() + (if (vid) (if (n == 1) " file" else " files") else (if (n == 1) " track" else " tracks")))
        }
        val dm = Scheduler.durationMin(h.b.root.context, s)
        parts.add(
            when {
                dm != null -> Scheduler.fmtDur(dm)
                s.loop && !isExt -> "Loops"
                else -> "Until stopped"
            }
        )
        h.b.info.text = parts.joinToString(" \u00B7 ")

        h.b.next.text = if (s.enabled)
            "Starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis())
        else "Off"
        h.b.root.alpha = if (s.enabled) 1f else 0.55f

        h.b.toggle.setOnCheckedChangeListener(null)
        h.b.toggle.isChecked = s.enabled
        h.b.toggle.setOnCheckedChangeListener { _, c -> onToggle(s, c) }
        h.b.root.setOnClickListener { onEdit(s) }
        h.b.delete.setOnClickListener { onDelete(s) }
    }
}
