package com.tunex.app

import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.tunex.app.databinding.ActivityIgBinding

/** Plays an Instagram reel through Instagram's public embed page. Needs internet; screen stays on. */
class IgPlayerActivity : AppCompatActivity() {

    private lateinit var b: ActivityIgBinding
    private val handler = Handler(Looper.getMainLooper())
    private var sched: Schedule? = null
    private var closing = false
    private var loaded = false
    private var userSeeking = false
    private var userPaused = false
    private var controlsShown = true
    private var playing = false

    private val ticker = object : Runnable {
        override fun run() {
            poll()
            handler.postDelayed(this, 700)
        }
    }
    private val hideRunnable = Runnable { hideControls() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b = ActivityIgBinding.inflate(layoutInflater)
        setContentView(b.root)

        val id = intent.getIntExtra("id", -1)
        val s = Store.get(this, id)
        val code = if (s != null) Ig.parseCode(s.igUrl) else null
        if (s == null || code == null) {
            finish()
            return
        }
        sched = s
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2000 + id)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (intent.getBooleanExtra("alarm", false)) {
            getSharedPreferences("tunex_ui", MODE_PRIVATE).edit()
                .putLong("lastStart", System.currentTimeMillis()).apply()
        }

        b.igTitle.text = s.label
        b.igStop.setOnClickListener { finishPlayback() }
        Scheduler.applyVolume(this, s.volume)

        val dl = Scheduler.stopDeadline(s)
        if (dl > 0L) {
            handler.postDelayed({ finishPlayback() }, (dl - System.currentTimeMillis()).coerceAtLeast(1000L))
        }

        val w = b.igWeb
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webChromeClient = WebChromeClient()
        w.webViewClient = WebViewClient()
        w.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP) toggleControls()
            false
        }

        b.igSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) b.igPos.text = fmt(p)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                userSeeking = true
                showControls()
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                js("v.currentTime=" + ((sb?.progress ?: 0) / 1000.0) + ";")
                userSeeking = false
                showControls()
            }
        })
        b.igPlay.setOnClickListener {
            showControls()
            userPaused = playing
            if (userPaused) js("window.__wpPaused=true;v.pause();") else js("window.__wpPaused=false;v.play();")
        }
        b.igBack.setOnClickListener {
            showControls()
            js("v.currentTime=Math.max(0,v.currentTime-10);")
        }
        b.igFwd.setOnClickListener {
            showControls()
            js("v.currentTime=Math.min((v.duration||1e9)-0.5,v.currentTime+10);")
        }

        tryStart(code)
        showControls()
    }

    private fun tryStart(code: String) {
        if (loaded || closing) return
        if (Yt.online(this)) {
            loaded = true
            b.igStatus.text = "Loading…"
            b.igWeb.loadUrl(Ig.embed(code))
            handler.postDelayed(ticker, 1500)
        } else {
            b.igStatus.text = "Waiting for internet…"
            handler.postDelayed({ tryStart(code) }, 4000)
        }
    }

    private fun fmt(ms: Int): String {
        val t = (ms / 1000).coerceAtLeast(0)
        return String.format("%d:%02d", t / 60, t % 60)
    }

    /** Runs a snippet against the page's <video>; does nothing when there is none yet. */
    private fun js(body: String) {
        if (closing) return
        b.igWeb.evaluateJavascript("(function(){var v=document.querySelector('video');if(!v)return;$body})()", null)
    }

    private fun poll() {
        if (closing) return
        val s = sched ?: return
        val loop = if (s.loop) "true" else "false"
        val script = """(function(){var v=document.querySelector('video');
if(!v){var p=document.querySelector('.videoSpritePlayButton,.PlayButton,[aria-label="Play"]');if(p){p.click();}return '';}
v.muted=false;v.loop=$loop;v.setAttribute('playsinline','');
if(v.paused&&!window.__wpPaused&&!v.ended){var r=v.play();if(r&&r.catch){r.catch(function(){});}}
return v.currentTime+'|'+(v.duration||0)+'|'+(v.paused?1:0)+'|'+(v.ended?1:0);})()"""
        b.igWeb.evaluateJavascript(script) { res ->
            if (closing) return@evaluateJavascript
            val t = res?.trim('"') ?: ""
            val parts = t.split("|")
            if (parts.size < 4) return@evaluateJavascript
            val pos = (parts[0].toDoubleOrNull() ?: 0.0) * 1000
            val dur = (parts[1].toDoubleOrNull() ?: 0.0) * 1000
            val paused = parts[2] == "1"
            val ended = parts[3] == "1"
            playing = !paused && !ended
            b.igStatus.text = if (playing) "Playing…" else if (paused) "Paused" else ""
            if (dur > 0 && dur < 1e9) {
                b.igSeek.max = dur.toInt()
                b.igDur.text = fmt(dur.toInt())
                if (!userSeeking) b.igSeek.progress = pos.toInt()
            }
            if (!userSeeking) b.igPos.text = fmt(pos.toInt())
            b.igPlay.setImageResource(if (playing) R.drawable.ic_pause_dark else R.drawable.ic_play_dark)
            if (ended && !s.loop) finishPlayback()
        }
    }

    private fun showControls() {
        if (closing) return
        controlsShown = true
        for (v in listOf(b.igTop, b.igControls)) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(180).start()
        }
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 3500)
    }

    private fun hideControls() {
        if (closing) return
        if (userSeeking || !playing) {
            handler.postDelayed(hideRunnable, 2000)
            return
        }
        controlsShown = false
        for (v in listOf(b.igTop, b.igControls)) {
            v.animate().alpha(0f).setDuration(220).withEndAction { v.visibility = View.INVISIBLE }.start()
        }
    }

    private fun toggleControls() {
        if (controlsShown) {
            handler.removeCallbacks(hideRunnable)
            hideControls()
            if (!playing) showControls()
        } else {
            showControls()
        }
    }

    private fun finishPlayback() {
        if (closing) return
        closing = true
        try {
            b.igWeb.loadUrl("about:blank")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            b.igWeb.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
