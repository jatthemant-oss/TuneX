package com.tunex.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.tunex.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private var ticks = 0
    private var userSeeking = false

    private val adapter = ScheduleAdapter(
        onToggle = { s, on -> onToggle(s, on) },
        onEdit = { s ->
            startActivity(Intent(this, EditActivity::class.java).putExtra("id", s.id))
        },
        onDelete = { s -> onDelete(s) }
    )

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            showBatteryPrompt()
        }

    private val tick = object : Runnable {
        override fun run() {
            refreshNow()
            ticks++
            if (ticks % 60 == 0) refreshList()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter

        b.fab.setOnClickListener {
            startActivity(Intent(this, EditActivity::class.java))
        }
        b.btnStop.setOnClickListener {
            startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_STOP))
        }
        b.btnPlay.setOnClickListener { PlayerService.instance?.togglePause() }
        b.btnPrev.setOnClickListener { PlayerService.instance?.prev() }
        b.btnNext.setOnClickListener { PlayerService.instance?.next() }
        b.btnBack.setOnClickListener { PlayerService.instance?.seekBy(-10000) }
        b.btnFwd.setOnClickListener { PlayerService.instance?.seekBy(10000) }
        b.nowSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) b.nowPos.text = fmtMs(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                PlayerService.instance?.seekTo(sb?.progress ?: 0)
                userSeeking = false
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            showBatteryPrompt()
        }

        // Make sure every enabled schedule is armed
        Scheduler.rescheduleAll(this)
    }

    private fun showBatteryPrompt() {
        val prefs = getSharedPreferences("tunex_ui", MODE_PRIVATE)
        if (prefs.getBoolean("asked", false)) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("asked", true).apply()
        MaterialAlertDialogBuilder(this)
            .setTitle("Make playback rock-solid")
            .setMessage("One time only: tap Allow on the next screen so Android never limits TuneX in the background.")
            .setPositiveButton("Continue") { _, _ ->
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            .setNegativeButton("Skip", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun updateLastRun() {
        val prefs = getSharedPreferences("tunex_ui", MODE_PRIVATE)
        val fire = prefs.getLong("lastFire", 0L)
        val start = prefs.getLong("lastStart", 0L)
        if (fire == 0L) {
            b.lastRun.visibility = View.GONE
            return
        }
        val f = java.text.SimpleDateFormat("h:mm:ss a", java.util.Locale.getDefault())
        val txt = if (start > 0L)
            "Last auto-start: alarm " + f.format(java.util.Date(fire)) + " → playing " + f.format(java.util.Date(start))
        else
            "Last auto-start: alarm " + f.format(java.util.Date(fire)) + " → not started"
        b.lastRun.text = txt
        b.lastRun.visibility = View.VISIBLE
    }

    private fun refreshList() {
        updateLastRun()
        val l = Store.all(this).sortedWith(compareBy({ it.hour }, { it.minute }))
        adapter.submit(l)
        b.empty.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun fmtMs(ms: Int): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }

    private fun refreshNow() {
        val svc = PlayerService.instance
        if (PlayerService.isPlaying && svc != null) {
            b.nowCard.visibility = View.VISIBLE
            b.nowLabel.text = PlayerService.nowTitle
            b.nowTrack.text = PlayerService.nowTrack.ifBlank { "Starting…" }
            val d = svc.duration()
            val p = svc.position()
            if (!userSeeking) {
                b.nowSeek.max = if (d > 0) d else 1
                b.nowSeek.progress = p
                b.nowPos.text = fmtMs(p)
            }
            b.nowDur.text = fmtMs(d)
            b.btnPlay.setImageResource(if (svc.isPaused()) R.drawable.ic_play_dark else R.drawable.ic_pause_dark)
        } else {
            b.nowCard.visibility = View.GONE
        }
    }

    private fun onToggle(s: Schedule, on: Boolean) {
        s.enabled = on
        if (on) {
            s.onceAt = 0L
            Scheduler.arm(this, s)
            Toast.makeText(
                this,
                "Starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Scheduler.cancel(this, s.id)
        }
        Store.upsert(this, s)
        handler.post { refreshList() }
    }

    private fun onDelete(s: Schedule) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete schedule?")
            .setMessage(s.label)
            .setPositiveButton("Delete") { _, _ ->
                Scheduler.cancel(this, s.id)
                Store.delete(this, s.id)
                refreshList()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
