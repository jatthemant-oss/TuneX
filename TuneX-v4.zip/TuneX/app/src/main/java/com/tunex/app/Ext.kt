package com.tunex.app

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.MediaStore
import android.view.KeyEvent

/** Spotify / JioSaavn launcher. Tries "play from search" (what voice assistants use) first. */
object Ext {
    const val SPOTIFY = "spotify"
    const val JIO = "jiosaavn"

    fun pkg(app: String): String =
        if (app == SPOTIFY) "com.spotify.music" else "com.jio.media.jiobeats"

    fun title(app: String): String =
        if (app == SPOTIFY) "Spotify" else "JioSaavn"

    private fun isLink(t: String): Boolean {
        val u = t.trim().lowercase()
        return u.startsWith("http") || u.startsWith("spotify:") || u.contains(".com/")
    }

    /** Accepts a link of the right app, or plain text (song name). */
    fun valid(app: String, text: String): Boolean {
        val t = text.trim()
        if (t.length < 2) return false
        if (!isLink(t)) return true
        val u = t.lowercase()
        return if (app == SPOTIFY) {
            u.startsWith("spotify:") || u.contains("spotify.com/")
        } else {
            u.contains("jiosaavn.com") || u.contains("saavn.com")
        }
    }

    /** JioSaavn links contain the song name: jiosaavn.com/song/<name>/<id> */
    private fun queryFromLink(link: String): String {
        return try {
            val seg = Uri.parse(link).pathSegments
            if (seg.size >= 2 && link.contains("saavn")) {
                seg[1].replace('-', ' ').replace('_', ' ').trim()
            } else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun intent(ctx: Context, s: Schedule): Intent {
        val raw = s.extUrl.trim()
        val pkg = pkg(s.extApp)
        val pm = ctx.packageManager
        val link = isLink(raw)
        val query = if (link) queryFromLink(raw) else raw

        if (query.isNotBlank()) {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            i.setPackage(pkg)
            i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            i.putExtra(SearchManager.QUERY, query)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(pm) != null) return i
        }
        if (link) {
            val v = Intent(Intent.ACTION_VIEW, Uri.parse(raw))
            v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            v.setPackage(pkg)
            if (v.resolveActivity(pm) == null) v.setPackage(null)
            return v
        }
        val launch = pm.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return launch
        }
        return Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(raw)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun sendKey(ctx: Context, key: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
