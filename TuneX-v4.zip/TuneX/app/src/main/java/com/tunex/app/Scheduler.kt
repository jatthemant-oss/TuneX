package com.tunex.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import java.util.Calendar

object Scheduler {

    private val SUN_FIRST = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    fun nextTrigger(s: Schedule, now: Long = System.currentTimeMillis()): Long {
        if (s.days == 0 && s.onceAt > now) return s.onceAt
        for (d in 0..7) {
            val c = Calendar.getInstance()
            c.timeInMillis = now
            c.add(Calendar.DAY_OF_YEAR, d)
            c.set(Calendar.HOUR_OF_DAY, s.hour)
            c.set(Calendar.MINUTE, s.minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= now) continue
            val bit = (s.days shr (c.get(Calendar.DAY_OF_WEEK) - 1)) and 1
            if (s.days == 0 || bit == 1) return c.timeInMillis
        }
        return now + 24L * 3600L * 1000L
    }

    private fun firePi(ctx: Context, id: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
        i.action = "com.tunex.app.FIRE"
        i.putExtra("id", id)
        return PendingIntent.getBroadcast(
            ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showPi(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Uses setAlarmClock: exact, works in Doze, exempt from battery optimisation. */
    fun arm(ctx: Context, s: Schedule) {
        val t = nextTrigger(s)
        if (s.days == 0) {
            s.onceAt = t
            Store.upsert(ctx, s)
        }
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAlarmClock(AlarmManager.AlarmClockInfo(t, showPi(ctx)), firePi(ctx, s.id))
    }

    fun cancel(ctx: Context, id: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(firePi(ctx, id))
    }

    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        for (s in Store.all(ctx)) {
            if (!s.enabled) continue
            if (s.days == 0 && s.onceAt in 1..now) {
                s.enabled = false // missed one-time schedule
                Store.upsert(ctx, s)
                continue
            }
            arm(ctx, s)
        }
    }

    /** Next time (after "from") the stop-time occurs, or 0 if stop-time is off. */
    fun stopDeadline(s: Schedule, from: Long = System.currentTimeMillis()): Long {
        if (!s.stopEnabled) return 0L
        val c = Calendar.getInstance()
        c.timeInMillis = from
        c.set(Calendar.HOUR_OF_DAY, s.stopHour)
        c.set(Calendar.MINUTE, s.stopMinute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= from) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun applyVolume(ctx: Context, percent: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * percent / 100).coerceIn(1, max), 0)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun fmt12(h: Int, m: Int): Pair<String, String> {
        val hh = if (h % 12 == 0) 12 else h % 12
        return Pair(String.format("%d:%02d", hh, m), if (h < 12) "AM" else "PM")
    }

    fun dayLabel(days: Int): String {
        if (days == 0) return "Once"
        if (days == 127) return "Every day"
        if (days == 62) return "Mon–Fri"
        val order = intArrayOf(1, 2, 3, 4, 5, 6, 0)
        return order.filter { (days shr it) and 1 == 1 }.joinToString(", ") { SUN_FIRST[it] }
    }

    fun untilText(ms: Long): String {
        val m = ms / 60000
        return when {
            m < 1 -> "in under a minute"
            m < 60 -> "in ${m}m"
            m < 1440 -> "in ${m / 60}h ${m % 60}m"
            else -> "in ${m / 1440}d ${(m % 1440) / 60}h"
        }
    }
}
