package com.tunex.app

import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.tunex.app.databinding.ActivityEditBinding
import java.util.Calendar

class EditActivity : AppCompatActivity() {

    private lateinit var b: ActivityEditBinding
    private var hour = 6
    private var minute = 0
    private var editId = -1
    private var ytId = ""
    private var ytUrl = ""
    private var extApp = ""
    private var extUrl = ""
    private var stopEnabled = false
    private var stopHour = 7
    private var stopMinute = 0
    private val uris = mutableListOf<String>()
    private val names = mutableListOf<String>()
    private val dayOrder = intArrayOf(1, 2, 3, 4, 5, 6, 0)
    private val dayNames = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    // System file picker: works with any folder, SD card, Downloads, WhatsApp, Drive, etc.
    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
            if (list.isNotEmpty()) {
                ytId = ""; ytUrl = ""; extApp = ""; extUrl = ""
            }
            for (u in list) {
                try {
                    contentResolver.takePersistableUriPermission(
                        u, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                val s = u.toString()
                if (s !in uris) {
                    uris.add(s)
                    names.add(displayName(u))
                }
            }
            renderSources()
        }

    private fun displayName(u: android.net.Uri): String {
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                ?: "Track"
        } catch (e: Exception) {
            "Track"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityEditBinding.inflate(layoutInflater)
        setContentView(b.root)

        val cal = Calendar.getInstance()
        hour = cal.get(Calendar.HOUR_OF_DAY)
        minute = cal.get(Calendar.MINUTE)
        stopHour = (hour + 1) % 24
        stopMinute = minute
        var days = 0
        var vol = 70
        var loop = false

        editId = intent.getIntExtra("id", -1)
        val existing = Store.get(this, editId)
        if (existing != null) {
            hour = existing.hour
            minute = existing.minute
            days = existing.days
            vol = existing.volume
            loop = existing.loop
            stopEnabled = existing.stopEnabled
            if (existing.stopEnabled) {
                stopHour = existing.stopHour
                stopMinute = existing.stopMinute
            }
            ytId = existing.ytId
            ytUrl = existing.ytUrl
            extApp = existing.extApp
            extUrl = existing.extUrl
            b.labelInput.setText(existing.label)
            uris.addAll(existing.uris)
            names.addAll(existing.names)
            b.screenTitle.text = "Edit schedule"
        }

        for (i in dayOrder) {
            val chip = layoutInflater.inflate(R.layout.chip_day, b.chipDays, false) as Chip
            chip.text = dayNames[i]
            chip.tag = i
            chip.isChecked = ((days shr i) and 1) == 1
            b.chipDays.addView(chip)
        }

        b.switchLoop.isChecked = loop
        b.switchStop.isChecked = stopEnabled
        b.switchStop.setOnCheckedChangeListener { _, c ->
            stopEnabled = c
            renderStop()
        }

        b.volSeek.progress = vol
        b.volText.text = "Volume $vol%"
        b.volSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                b.volText.text = "Volume $p%"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        b.timeCard.setOnClickListener {
            pickTime("Start time", hour, minute) { h, m ->
                hour = h
                minute = m
                renderTime()
            }
        }
        b.stopRow.setOnClickListener {
            pickTime("Stop time", stopHour, stopMinute) { h, m ->
                stopHour = h
                stopMinute = m
                stopEnabled = true
                b.switchStop.isChecked = true
                renderStop()
            }
        }

        b.btnAddSongs.setOnClickListener {
            picker.launch(arrayOf("audio/*", "application/ogg", "application/octet-stream"))
        }
        b.btnClearSongs.setOnClickListener {
            uris.clear()
            names.clear()
            renderSources()
        }

        b.btnYoutube.setOnClickListener {
            askLink("YouTube link", "https://youtu.be/...", { Yt.parseId(it) != null }) { txt ->
                ytId = Yt.parseId(txt) ?: ""
                ytUrl = txt
                uris.clear(); names.clear(); extApp = ""; extUrl = ""
                renderSources()
            }
        }
        b.btnClearYt.setOnClickListener {
            ytId = ""; ytUrl = ""
            renderSources()
        }

        b.btnSpotify.setOnClickListener {
            askLink("Spotify link or song name", "Link or song name", { Ext.valid(Ext.SPOTIFY, it) }) { txt ->
                extApp = Ext.SPOTIFY
                extUrl = txt
                uris.clear(); names.clear(); ytId = ""; ytUrl = ""
                renderSources()
            }
        }
        b.btnJio.setOnClickListener {
            askLink("JioSaavn link or song name", "Link or song name", { Ext.valid(Ext.JIO, it) }) { txt ->
                extApp = Ext.JIO
                extUrl = txt
                uris.clear(); names.clear(); ytId = ""; ytUrl = ""
                renderSources()
            }
        }
        b.btnClearExt.setOnClickListener {
            extApp = ""; extUrl = ""
            renderSources()
        }

        b.btnSave.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            if (!checkClash(s)) return@setOnClickListener
            persist(s)
            Toast.makeText(
                this,
                "Scheduled • starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis()),
                Toast.LENGTH_LONG
            ).show()
            finish()
        }

        b.btnPlayNow.setOnClickListener {
            val s = collect() ?: return@setOnClickListener
            persist(s)
            when {
                s.extApp.isNotBlank() -> {
                    startActivity(Ext.intent(this, s))
                    Handler(Looper.getMainLooper()).postDelayed(
                        { Ext.sendKey(applicationContext, KeyEvent.KEYCODE_MEDIA_PLAY) }, 8000L
                    )
                }
                s.ytId.isNotBlank() ->
                    startActivity(Intent(this, YtPlayerActivity::class.java).putExtra("id", s.id))
                else ->
                    ContextCompat.startForegroundService(
                        this, Intent(this, PlayerService::class.java).putExtra("id", s.id)
                    )
            }
            Toast.makeText(this, "Playing now (test)", Toast.LENGTH_SHORT).show()
        }

        renderTime()
        renderStop()
        renderSources()
    }

    private fun pickTime(title: String, h: Int, m: Int, done: (Int, Int) -> Unit) {
        val p = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_12H)
            .setHour(h)
            .setMinute(m)
            .setTitleText(title)
            .build()
        p.addOnPositiveButtonClickListener { done(p.hour, p.minute) }
        p.show(supportFragmentManager, "time")
    }

    private fun askLink(title: String, hint: String, ok: (String) -> Boolean, done: (String) -> Unit) {
        val et = EditText(this)
        et.hint = hint
        et.setSingleLine()
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip?.getItemAt(0)?.text?.toString()
            val c = clip?.trim()?.lowercase() ?: ""
            val looksLikeLink = c.startsWith("http") || c.startsWith("spotify:")
            if (clip != null && looksLikeLink && ok(clip.trim())) et.setText(clip.trim())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(et)
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Use") { _, _ ->
                val txt = et.text.toString().trim()
                if (!ok(txt)) {
                    Toast.makeText(this, "Not recognised", Toast.LENGTH_SHORT).show()
                } else {
                    done(txt)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun renderTime() {
        val (t, ap) = Scheduler.fmt12(hour, minute)
        b.timeText.text = t
        b.ampmText.text = ap
        renderDur()
    }

    private fun renderDur() {
        b.durText.text = if (stopEnabled)
            "Duration " + Scheduler.fmtDur(Scheduler.span(hour, minute, stopHour, stopMinute))
        else ""
    }

    /** Two schedules can't play together: ask to create this one after the other ends. */
    private fun checkClash(s: Schedule): Boolean {
        val c = Scheduler.conflict(this, s) ?: return true
        val (cs, cap) = Scheduler.fmt12(c.hour, c.minute)
        val ce = Scheduler.endMinutes(this, c)
        val (es, eap) = Scheduler.fmt12(ce / 60, ce % 60)
        val dm = Scheduler.durationMin(this, c)
        val len = if (dm != null) " (" + Scheduler.fmtDur(dm) + ")" else ""
        MaterialAlertDialogBuilder(this)
            .setTitle("Schedules clash")
            .setMessage(
                "\"" + c.label + "\" plays $cs $cap → $es $eap$len.\n\n" +
                    "Two schedules can't play at the same time. Please create this one after $es $eap."
            )
            .setPositiveButton("Start at $es $eap") { _, _ ->
                val keep = if (stopEnabled) Scheduler.span(hour, minute, stopHour, stopMinute) else 0
                hour = ce / 60
                minute = ce % 60
                if (stopEnabled) {
                    val e = (ce + keep) % 1440
                    stopHour = e / 60
                    stopMinute = e % 60
                }
                renderTime()
                renderStop()
                Toast.makeText(this, "Time moved - tap Save", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Change time", null)
            .show()
        return false
    }

    private fun renderStop() {
        val (t, ap) = Scheduler.fmt12(stopHour, stopMinute)
        b.stopTime.text = "$t $ap"
        b.stopTime.alpha = if (stopEnabled) 1f else 0.4f
        b.stopEditIcon.alpha = if (stopEnabled) 1f else 0.4f
        renderDur()
    }

    private fun renderSources() {
        if (names.isEmpty()) {
            b.songsList.text = "No files selected"
            b.btnClearSongs.visibility = View.GONE
        } else {
            b.songsList.text = names.mapIndexed { i, n -> "${i + 1}. $n" }.joinToString("\n")
            b.btnClearSongs.visibility = View.VISIBLE
        }
        if (ytId.isBlank()) {
            b.ytText.text = "No video selected"
            b.btnClearYt.visibility = View.GONE
        } else {
            b.ytText.text = ytUrl
            b.btnClearYt.visibility = View.VISIBLE
        }
        b.spotifyText.text = if (extApp == Ext.SPOTIFY) extUrl else "Not set"
        b.jioText.text = if (extApp == Ext.JIO) extUrl else "Not set"
        b.btnClearExt.visibility = if (extApp.isBlank()) View.GONE else View.VISIBLE
    }

    private fun collect(): Schedule? {
        if (uris.isEmpty() && ytId.isBlank() && extApp.isBlank()) {
            Toast.makeText(this, "Add music, a YouTube, Spotify or JioSaavn link", Toast.LENGTH_SHORT).show()
            return null
        }
        var days = 0
        for (i in 0 until b.chipDays.childCount) {
            val c = b.chipDays.getChildAt(i) as Chip
            if (c.isChecked) days = days or (1 shl (c.tag as Int))
        }
        val id = if (editId > 0) editId else Store.nextId(this)
        val label = b.labelInput.text.toString().trim().ifBlank { "The Music" }
        return Schedule(
            id = id,
            hour = hour,
            minute = minute,
            days = days,
            label = label,
            uris = uris.toList(),
            names = names.toList(),
            enabled = true,
            volume = b.volSeek.progress.coerceAtLeast(10),
            onceAt = 0L,
            ytId = ytId,
            ytUrl = ytUrl,
            loop = b.switchLoop.isChecked,
            stopEnabled = stopEnabled,
            stopHour = stopHour,
            stopMinute = stopMinute,
            extApp = extApp,
            extUrl = extUrl
        )
    }

    private fun persist(s: Schedule) {
        editId = s.id
        Store.upsert(this, s)
        Scheduler.cancel(this, s.id)
        Scheduler.arm(this, s)
    }
}
