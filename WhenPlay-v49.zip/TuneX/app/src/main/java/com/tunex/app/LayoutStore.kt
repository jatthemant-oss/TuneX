package com.tunex.app

import android.content.Context

/** How the schedule list looks. Only look & feel - no behaviour is touched. */
object LayoutStore {
    val names = listOf("Cards", "Bento")
    val hints = listOf("Full cards with a source pill", "Big next-up tile and colour tiles")

    fun index(ctx: Context): Int =
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).getInt("layout", 0).coerceIn(0, names.size - 1)

    fun set(ctx: Context, i: Int) {
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).edit().putInt("layout", i).apply()
    }

    fun isBento(ctx: Context): Boolean = index(ctx) == 1
}
