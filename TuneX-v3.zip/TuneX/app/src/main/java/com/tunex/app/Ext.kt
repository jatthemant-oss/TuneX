package com.tunex.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent

/** Helpers for opening Spotify / JioSaavn at the scheduled time. Playback happens inside that app. */
object Ext {
    const val SPOTIFY = "spotify"
    const val JIO = "jiosaavn"

    fun pkg(app: String): String =
        if (app == SPOTIFY) "com.spotify.music" else "com.jio.media.jiobeats"

    fun title(app: String): String =
        if (app == SPOTIFY) "Spotify" else "JioSaavn"

    fun valid(app: String, url: String): Boolean {
        val u = url.trim().lowercase()
        if (u.isEmpty()) return false
        return if (app == SPOTIFY) {
            u.startsWith("spotify:") || u.contains("spotify.com/")
        } else {
            u.contains("jiosaavn.com") || u.contains("saavn.com")
        }
    }

    fun intent(ctx: Context, s: Schedule): Intent {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(s.extUrl.trim()))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.setPackage(pkg(s.extApp))
        if (i.resolveActivity(ctx.packageManager) == null) {
            i.setPackage(null) // app not installed: fall back to browser
        }
        return i
    }

    fun sendKey(ctx: Context, key: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
