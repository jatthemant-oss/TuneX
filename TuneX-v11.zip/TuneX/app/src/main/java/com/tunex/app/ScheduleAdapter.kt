package com.tunex.app

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.tunex.app.databinding.ItemScheduleBinding

class ScheduleAdapter(
    private val onToggle: (Schedule, Boolean) -> Unit,
    private val onEdit: (Schedule) -> Unit,
    private val onDelete: (Schedule) -> Unit
) : RecyclerView.Adapter<ScheduleAdapter.VH>() {

    private var items: List<Schedule> = emptyList()

    fun submit(l: List<Schedule>) {
        items = l
        notifyDataSetChanged()
    }

    class VH(val b: ItemScheduleBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemScheduleBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val s = items[position]
        val (t, ap) = Scheduler.fmt12(s.hour, s.minute)
        h.b.time.text = t
        h.b.ampm.text = ap
        h.b.label.text = s.label

        val isExt = s.extApp.isNotBlank()
        val isYt = s.ytId.isNotBlank()
        val badge: Pair<String, Int> = when {
            s.extApp == Ext.SPOTIFY -> Pair("SPOTIFY", 0xFF1DB954.toInt())
            s.extApp == Ext.JIO -> Pair("JIOSAAVN", 0xFF2BC5B4.toInt())
            isYt -> Pair("YOUTUBE", 0xFFFF3D3D.toInt())
            else -> Pair("MUSIC", 0xFF7C5CFF.toInt())
        }
        h.b.badge.text = badge.first
        val gd = GradientDrawable()
        gd.cornerRadius = 60f
        gd.setColor(badge.second)
        h.b.badge.background = gd

        val parts = mutableListOf(Scheduler.dayLabel(s.days))
        if (!isExt && !isYt) {
            val n = s.uris.size
            parts.add(n.toString() + (if (n == 1) " track" else " tracks"))
        }
        if (s.loop && !isExt) parts.add("🔁 Repeat")
        h.b.info.text = parts.joinToString("  •  ")

        val dm = Scheduler.durationMin(h.b.root.context, s)
        h.b.dur.text = when {
            dm != null && s.stopEnabled -> {
                val (st, sap) = Scheduler.fmt12(s.stopHour, s.stopMinute)
                "⏱ Duration " + Scheduler.fmtDur(dm) + "  •  Stops $st $sap"
            }
            dm != null -> "⏱ Duration " + Scheduler.fmtDur(dm)
            s.loop && !isExt -> "⏱ Repeats until stopped"
            else -> "⏱ Until stopped (no stop time)"
        }

        h.b.next.text = if (s.enabled)
            "Starts " + Scheduler.untilText(Scheduler.nextTrigger(s) - System.currentTimeMillis())
        else "Off"
        h.b.root.alpha = if (s.enabled) 1f else 0.55f

        h.b.toggle.setOnCheckedChangeListener(null)
        h.b.toggle.isChecked = s.enabled
        h.b.toggle.setOnCheckedChangeListener { _, c -> onToggle(s, c) }
        h.b.root.setOnClickListener { onEdit(s) }
        h.b.delete.setOnClickListener { onDelete(s) }
    }
}
