package com.tunex.app

import android.app.Activity
import android.content.Context
import android.util.TypedValue
import androidx.core.view.WindowCompat

/** Colour themes. Only look & feel - no behaviour is touched. */
object ThemeStore {
    data class T(val name: String, val style: Int, val top: Int, val bg: Int, val accent: Int, val light: Boolean)

    val all = listOf(
        T("Midnight", R.style.Theme_TuneX_Midnight, 0xFF15183A.toInt(), 0xFF0B0D17.toInt(), 0xFF7C5CFF.toInt(), false),
        T("Aurora", R.style.Theme_TuneX_Aurora, 0xFF0A3040.toInt(), 0xFF2B0F4C.toInt(), 0xFF5EEAD4.toInt(), false),
        T("Sunset", R.style.Theme_TuneX_Sunset, 0xFF2A1033.toInt(), 0xFF7A2616.toInt(), 0xFFFFB36B.toInt(), false),
        T("Ocean", R.style.Theme_TuneX_Ocean, 0xFF06202E.toInt(), 0xFF04141F.toInt(), 0xFF38BDF8.toInt(), false),
        T("Noir Gold", R.style.Theme_TuneX_NoirGold, 0xFF141414.toInt(), 0xFF000000.toInt(), 0xFFD4AF37.toInt(), false),
        T("Emerald", R.style.Theme_TuneX_Emerald, 0xFF05261D.toInt(), 0xFF03120D.toInt(), 0xFF34D399.toInt(), false),
        T("Ivory", R.style.Theme_TuneX_Ivory, 0xFFFFFFFF.toInt(), 0xFFECEBF7.toInt(), 0xFF5B47E0.toInt(), true),
        T("Blush", R.style.Theme_TuneX_Blush, 0xFFFFF1F5.toInt(), 0xFFEDE9FE.toInt(), 0xFFDB2777.toInt(), true)
    )

    fun index(ctx: Context): Int =
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).getInt("theme", 0).coerceIn(0, all.size - 1)

    fun set(ctx: Context, i: Int) {
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
    }

    /** Call BEFORE super.onCreate(). */
    fun apply(a: Activity) = a.setTheme(all[index(a)].style)

    /** Call AFTER setContentView(): dark/light status & navigation icons. */
    fun styleBars(a: Activity) {
        val light = all[index(a)].light
        val c = WindowCompat.getInsetsController(a.window, a.window.decorView)
        c.isAppearanceLightStatusBars = light
        c.isAppearanceLightNavigationBars = light
    }

    fun attrColor(ctx: Context, attr: Int, def: Int): Int {
        val tv = TypedValue()
        return if (ctx.theme.resolveAttribute(attr, tv, true)) tv.data else def
    }
}
