package com.tunex.app

import android.app.Activity
import android.content.Context
import android.util.TypedValue
import androidx.core.view.WindowCompat

/** Colour themes. Only look & feel - no behaviour is touched. */
object ThemeStore {
    data class T(val name: String, val style: Int, val bg: Int, val card: Int, val accent: Int, val light: Boolean)

    val all = listOf(
        T("Light", R.style.Theme_TuneX_Ivory, 0xFFF2F2F7.toInt(), 0xFFFFFFFF.toInt(), 0xFF007AFF.toInt(), true),
        T("Dark", R.style.Theme_TuneX_Graphite, 0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFF0A84FF.toInt(), false),
        T("Midnight", R.style.Theme_TuneX_Midnight, 0xFF0A0A0F.toInt(), 0xFF16161F.toInt(), 0xFF5E5CE6.toInt(), false),
        T("AMOLED", R.style.Theme_TuneX_Amoled, 0xFF000000.toInt(), 0xFF111111.toInt(), 0xFF30D158.toInt(), false),
        T("Rose", R.style.Theme_TuneX_Rose, 0xFF0C0A0B.toInt(), 0xFF1C1719.toInt(), 0xFFFF2D55.toInt(), false)
    )

    fun index(ctx: Context): Int =
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).getInt("theme", 0).coerceIn(0, all.size - 1)

    fun set(ctx: Context, i: Int) {
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
    }

    /** Call BEFORE super.onCreate(). */
    fun apply(a: Activity) = a.setTheme(all[index(a)].style)

    /** Call AFTER setContentView(): dark/light status & navigation icons. */
    fun styleBars(a: Activity) {
        val light = all[index(a)].light
        val c = WindowCompat.getInsetsController(a.window, a.window.decorView)
        c.isAppearanceLightStatusBars = light
        c.isAppearanceLightNavigationBars = light
    }

    fun attrColor(ctx: Context, attr: Int, def: Int): Int {
        val tv = TypedValue()
        return if (ctx.theme.resolveAttribute(attr, tv, true)) tv.data else def
    }
}
