package com.tunex.app

import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.tunex.app.databinding.ActivityYtBinding

/** Plays a YouTube video with the official embedded player. Needs internet; screen stays on. */
class YtPlayerActivity : AppCompatActivity() {

    companion object {
        @Volatile var running = false
    }

    private var takeRx: android.content.BroadcastReceiver? = null
    private var startSec = 0

    private lateinit var b: ActivityYtBinding
    private val handler = Handler(Looper.getMainLooper())
    private var sched: Schedule? = null
    private var loaded = false
    private var closing = false
    inner class Bridge {
        @JavascriptInterface
        fun onEnded() {
            runOnUiThread { finishPlayback() }
        }

        @JavascriptInterface
        fun onError(code: Int) {
            runOnUiThread {
                b.ytStatus.text = "This video can't be played here (error $code)"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b = ActivityYtBinding.inflate(layoutInflater)
        setContentView(b.root)

        val id = intent.getIntExtra("id", -1)
        val s = Store.get(this, id)
        if (s == null || s.ytId.isBlank()) {
            finish()
            return
        }
        sched = s
        running = true
        takeRx = Takeover.listen(this, s.id) { stepAside() }
        startSec = if (intent.getBooleanExtra("resume", false))
            ((Takeover.takePosition(this, s.id)?.second ?: 0L) / 1000L).toInt()
        else {
            Takeover.forgetPosition(this, s.id)
            0
        }
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2000 + id)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        b.ytTitle.text = s.label
        b.ytStop.setOnClickListener { finishPlayback(true) }
        Scheduler.applyVolume(this, s.volume)

        val dl = Scheduler.stopDeadline(s)
        if (dl > 0L) {
            handler.postDelayed({ finishPlayback() }, (dl - System.currentTimeMillis()).coerceAtLeast(1000L))
        }

        val w = b.ytWeb
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webChromeClient = WebChromeClient()
        w.addJavascriptInterface(Bridge(), "Android")

        tryStart()
    }

    private fun tryStart() {
        if (loaded || closing) return
        val s = sched ?: return
        if (Yt.online(this)) {
            loaded = true
            b.ytStatus.text = "Playing…"
            if (intent.getBooleanExtra("alarm", false)) {
                getSharedPreferences("tunex_ui", MODE_PRIVATE).edit()
                    .putLong("lastStart", System.currentTimeMillis()).apply()
            }
            val loopJs = if (s.loop) "true" else "false"
            val vid = s.ytId
            val html = """<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;height:100%;background:#000}#player{position:absolute;top:0;left:0;width:100%;height:100%}</style></head><body><div id="player"></div><script>var LOOP=$loopJs;var tag=document.createElement('script');tag.src='https://www.youtube.com/iframe_api';document.head.appendChild(tag);var player;function onYouTubeIframeAPIReady(){player=new YT.Player('player',{width:'100%',height:'100%',videoId:'$vid',playerVars:{autoplay:1,playsinline:1,rel:0,start:$startSec,origin:'https://tunex.app'},events:{onReady:function(e){e.target.playVideo();},onStateChange:function(e){if(e.data===0){if(LOOP){player.seekTo(0);player.playVideo();}else{Android.onEnded();}}},onError:function(e){Android.onError(e.data);}}});}</script></body></html>"""
            b.ytWeb.loadDataWithBaseURL("https://tunex.app", html, "text/html", "utf-8", null)
        } else {
            b.ytStatus.text = "Waiting for internet…"
            handler.postDelayed({ tryStart() }, 4000)
        }
    }

    /** A newer schedule took over: close quietly. This schedule does not come back. */
    private fun stepAside() {
        if (closing) return
        closing = true
        try {
            b.ytWeb.loadUrl("about:blank")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        finish()
    }

    private fun finishPlayback(manual: Boolean = false) {
        if (closing) return
        closing = true
        val id = sched?.id ?: -1
        if (manual) Takeover.onManualStop(this, id) else Takeover.onEnded(this, id)
        try {
            b.ytWeb.loadUrl("about:blank")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        finish()
    }

    override fun onDestroy() {
        running = false
        try {
            takeRx?.let { unregisterReceiver(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        handler.removeCallbacksAndMessages(null)
        try {
            b.ytWeb.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
