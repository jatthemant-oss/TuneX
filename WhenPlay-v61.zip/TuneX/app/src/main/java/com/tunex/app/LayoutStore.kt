package com.tunex.app

import android.content.Context

/** Which look the list and the schedule screen use. Only look & feel - no behaviour is touched. */
object LayoutStore {
    val names = listOf("Curve", "Pills")
    val hints = listOf(
        "Curved header with an up-next card",
        "Soft rounded rows, clean and compact"
    )

    fun index(ctx: Context): Int =
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).getInt("style", 0).coerceIn(0, names.size - 1)

    fun set(ctx: Context, i: Int) {
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).edit().putInt("style", i).apply()
    }

    fun isPills(ctx: Context): Boolean = index(ctx) == 1
}
