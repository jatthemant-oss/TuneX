# WhenPlay 3.0.2 (v76)
- Phone audio: screen is woken at alarm time and the player is re-checked at +6s / +14s, so it starts by itself.
- Mixed playlists: video files play only on the video screen, audio files only on the audio screen; they hand over to each other.
- Name box: short auto name (Instagram -> "Instagram Reel"), pencil icon to edit, empty = auto name is kept.
- START / PLAYS / STOP / DAYS labels bold; values smaller and regular.
