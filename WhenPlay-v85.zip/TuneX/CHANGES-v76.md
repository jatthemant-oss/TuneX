# WhenPlay 3.0.2 (v76)
- Phone audio: screen is woken at alarm time and the player is re-checked at +6s / +14s, so it starts by itself.
- Mixed playlists: video files play only on the video screen, audio files only on the audio screen; they hand over to each other.
- Name box: short auto name (Instagram -> "Instagram Reel"), pencil icon to edit, empty = auto name is kept.
- START / PLAYS / STOP / DAYS labels bold; values smaller and regular.

# v77 (3.0.3)
- versionCode follows the GitHub run number so every build installs over the previous one.
- Same simple workflow as before.
# v84
- Source window (icon window) only: Spotlight Lens design. Five tiles until a source is picked; then one spotlight row (icon, title, sub, Paste/Browse/Clear/+Add button) and a SWITCH SOURCE dock with the other four. Caption shows READY / NOW SCHEDULING and the length tag. Nothing below the window changed.

# v85
- Source window: copied-link banner (COPIED X LINK READY · Use →) when the app opens / regains focus with a supported link on the clipboard; one tap picks the source and takes the link.
- Link / Choose-file box under the window removed (the spotlight button does Paste / Browse / Clear / Add).
- Name box: no 'optional' text.
