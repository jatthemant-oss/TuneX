package com.tunex.app

import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.tunex.app.databinding.ActivityYtBinding

/**
 * Plays an Instagram reel inside WhenPlay (like the YouTube player), so Stop time simply
 * closes it. Needs internet; screen stays on. If the reel can't start here, falls back to the
 * Instagram app.
 */
class IgPlayerActivity : AppCompatActivity() {

    private lateinit var b: ActivityYtBinding
    private val handler = Handler(Looper.getMainLooper())
    private var sched: Schedule? = null
    private var loaded = false
    private var playing = false
    private var closing = false
    private var tries = 0

    // starts the reel, keeps it looping, and reports "playing" / "paused" / "novideo"
    private val kick = """(function(){
        var v=document.querySelector('video');
        if(!v){
            var b=document.querySelector('[aria-label*="Play"],[aria-label*="play"],.videoSpritePlayButton');
            if(b){b.click();}
            return 'novideo';
        }
        v.loop=true; v.muted=false; v.setAttribute('playsinline','');
        try{v.play();}catch(e){}
        return v.paused?'paused':'playing';
    })()"""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b = ActivityYtBinding.inflate(layoutInflater)
        setContentView(b.root)

        val id = intent.getIntExtra("id", -1)
        val s = Store.get(this, id)
        if (s == null || s.extApp != Ext.INSTAGRAM || s.extUrl.isBlank()) {
            finish()
            return
        }
        sched = s
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2000 + id)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        b.ytTitle.text = s.label
        b.ytStop.setOnClickListener { finishPlayback() }
        Scheduler.applyVolume(this, s.volume)

        val dl = Scheduler.stopDeadline(s)
        if (dl > 0L) {
            handler.postDelayed({ finishPlayback() }, (dl - System.currentTimeMillis()).coerceAtLeast(1000L))
        }

        val w = b.ytWeb
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webChromeClient = WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            // stay on the embed page (never wander off into Instagram's site)
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return true
                return !(u.contains("instagram.com") && u.contains("/embed"))
            }
        }

        tryStart()
    }

    /** https://www.instagram.com/reel/CODE/  ->  CODE */
    private fun embedUrl(link: String): String? {
        val m = Regex("""instagram\.com/(reels?|p|tv)/([A-Za-z0-9_-]+)""").find(link)
            ?: Regex("""instagr\.am/(reels?|p|tv)/([A-Za-z0-9_-]+)""").find(link)
            ?: return null
        val kind = if (m.groupValues[1].startsWith("reel")) "reel" else m.groupValues[1]
        return "https://www.instagram.com/" + kind + "/" + m.groupValues[2] + "/embed/"
    }

    private fun tryStart() {
        if (loaded || closing) return
        val s = sched ?: return
        if (!Yt.online(this)) {
            b.ytStatus.text = "Waiting for internet…"
            handler.postDelayed({ tryStart() }, 4000)
            return
        }
        val url = embedUrl(s.extUrl)
        if (url == null) {
            openInApp()
            return
        }
        loaded = true
        b.ytStatus.text = "Loading reel…"
        if (intent.getBooleanExtra("alarm", false)) {
            getSharedPreferences("tunex_ui", MODE_PRIVATE).edit()
                .putLong("lastStart", System.currentTimeMillis()).apply()
        }
        b.ytWeb.loadUrl(url)
        handler.postDelayed({ poll() }, 2500)
    }

    /** Keeps nudging the page until the reel is really playing. */
    private fun poll() {
        if (closing || playing) return
        tries++
        try {
            b.ytWeb.evaluateJavascript(kick) { r ->
                if (closing) return@evaluateJavascript
                if (r != null && r.contains("playing")) {
                    playing = true
                    b.ytStatus.text = "Playing…"
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (tries >= 14 && !playing) {
            openInApp()
        } else if (!playing) {
            handler.postDelayed({ poll() }, 1200)
        }
    }

    /** Last resort: the reel would not start here, so open it in the Instagram app. */
    private fun openInApp() {
        if (closing) return
        val s = sched ?: return
        b.ytStatus.text = "Opening in Instagram…"
        try {
            startActivity(Ext.intent(this, s))
        } catch (e: Exception) {
            e.printStackTrace()
            b.ytStatus.text = "This reel can't be played here"
        }
    }

    private fun finishPlayback() {
        if (closing) return
        closing = true
        try {
            b.ytWeb.evaluateJavascript("document.querySelectorAll('video').forEach(function(v){v.pause();})", null)
            b.ytWeb.loadUrl("about:blank")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            b.ytWeb.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
