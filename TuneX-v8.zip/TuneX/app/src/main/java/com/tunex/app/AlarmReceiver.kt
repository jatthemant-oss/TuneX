package com.tunex.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_KEY = "com.tunex.app.KEY"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        // Delayed "press play / pause" for Spotify & JioSaavn
        if (intent.action == ACTION_KEY) {
            Ext.sendKey(ctx, intent.getIntExtra("key", KeyEvent.KEYCODE_MEDIA_PLAY), intent.getStringExtra("pkg"))
            return
        }

        // Keep CPU awake until playback has taken over
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TuneX:fire").acquire(60_000L)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val id = intent.getIntExtra("id", -1)
        val s = Store.get(ctx, id) ?: return
        if (!s.enabled) return

        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).edit()
            .putLong("lastFire", System.currentTimeMillis())
            .putLong("lastStart", 0L)
            .commit()

        // Re-arm first so the next occurrence is never lost
        if (s.days == 0) {
            s.enabled = false
            Store.upsert(ctx, s)
        } else {
            Scheduler.arm(ctx, s)
        }

        if (s.extApp.isNotBlank()) {
            launchExternal(ctx, s)
            return
        }
        if (s.ytId.isNotBlank()) {
            val i = Intent(ctx, YtPlayerActivity::class.java)
                .putExtra("id", s.id)
                .putExtra("alarm", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            openScreen(ctx, s, i, "Tap to play YouTube video")
            return
        }

        val svc = Intent(ctx, PlayerService::class.java)
            .putExtra("id", id)
            .putExtra("alarm", true)
        try {
            ContextCompat.startForegroundService(ctx, svc)
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                ctx.startService(svc)
            } catch (e2: Exception) {
                e2.printStackTrace()
            }
        }
    }

    private fun launchExternal(ctx: Context, s: Schedule) {
        // wake the screen (works even when the phone is locked / screen off)
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            @Suppress("DEPRECATION")
            pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "TuneX:wake"
            ).acquire(40_000L)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val i = Intent(ctx, LockLaunchActivity::class.java)
            .putExtra("id", s.id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        openScreen(ctx, s, i, "Tap to open " + Ext.title(s.extApp))
        val now = System.currentTimeMillis()
        ctx.getSharedPreferences("tunex_ui", Context.MODE_PRIVATE).edit()
            .putLong("lastStart", now).apply()
        // nudge "play" several times (play is idempotent) once the app is up
        val pkg = Ext.pkg(s.extApp)
        keyAlarm(ctx, s.id, 7300, now + 5000L, KeyEvent.KEYCODE_MEDIA_PLAY, pkg)
        keyAlarm(ctx, s.id, 7000, now + 9000L, KeyEvent.KEYCODE_MEDIA_PLAY, pkg)
        keyAlarm(ctx, s.id, 7100, now + 15000L, KeyEvent.KEYCODE_MEDIA_PLAY, pkg)
        keyAlarm(ctx, s.id, 7200, now + 24000L, KeyEvent.KEYCODE_MEDIA_PLAY, pkg)
        // optional stop time -> "pause"
        val stop = Scheduler.stopDeadline(s)
        if (stop > 0L) keyAlarm(ctx, s.id, 7500, stop, KeyEvent.KEYCODE_MEDIA_PAUSE, pkg)
    }

    private fun keyAlarm(ctx: Context, id: Int, base: Int, at: Long, key: Int, pkg: String) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, base + id,
                Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_KEY).putExtra("key", key).putExtra("pkg", pkg),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Open a screen at alarm time: direct start (some phones) + full-screen notification (lockscreen). */
    private fun openScreen(ctx: Context, s: Schedule, i: Intent, text: String) {
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel("tunex_alarm", "TuneX alarms", NotificationManager.IMPORTANCE_HIGH)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
            val pi = PendingIntent.getActivity(
                ctx, 100 + s.id, i,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(ctx, "tunex_alarm")
                .setSmallIcon(R.drawable.ic_stat_music)
                .setContentTitle("TuneX • " + s.label)
                .setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .build()
            nm.notify(2000 + s.id, n)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
